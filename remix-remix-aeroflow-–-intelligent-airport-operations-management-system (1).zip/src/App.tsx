import React, { useState } from 'react';
import {
  Flight,
  Gate,
  PassengerAircraft,
  CargoAircraft,
  Passenger,
  Staff,
  Ticket,
  Baggage,
  FlightBaggageManifest,
  FlightNotification,
  EmergencyIncident,
  EmergencyType,
  EmergencyDeclarerRole,
  SeatClass,
  PaymentMethod,
  DutyStatus,
  BaggageStatus,
  FlightStatus,
  UserRole,
} from './types/aeroflow';
import {
  INITIAL_FLIGHTS,
  INITIAL_GATES,
  INITIAL_AIRCRAFT_PASSENGER,
  INITIAL_AIRCRAFT_CARGO,
  INITIAL_PASSENGERS,
  INITIAL_STAFF,
  INITIAL_TICKETS,
  INITIAL_BAGGAGE,
  INITIAL_BAGGAGE_MANIFESTS,
  INITIAL_NOTIFICATIONS,
  INITIAL_EMERGENCY,
  EMERGENCY_TYPE_RULES,
} from './data/mockAirportData';

import {
  Navbar,
  OpeningHub,
  ActiveTab,
  ROLE_MENU_MAP,
  USER_ROLES,
} from './components/Navbar';
import { TicketBookingView } from './components/TicketBookingView';
import { PassengerFlightDetailsView } from './components/PassengerFlightDetailsView';
import { PassengerTicketsView } from './components/PassengerTicketsView';
import { PilotAssignedFlightsView } from './components/PilotAssignedFlightsView';
import { ManagementHubView } from './components/ManagementHubView';
import { FlightBoard } from './components/FlightBoard';
import { BookingModal } from './components/BookingModal';
import { BoardingPassModal } from './components/BoardingPassModal';
import { GateManager } from './components/GateManager';
import { BaggageTracker } from './components/BaggageTracker';
import { FleetManager } from './components/FleetManager';
import { CrewManager } from './components/CrewManager';
import { BoardingQueueSimulator } from './components/BoardingQueueSimulator';
import { EmergencyCenter } from './components/EmergencyCenter';
import { AnalyticsDashboard } from './components/AnalyticsDashboard';
import { OopArchitectureLab } from './components/OopArchitectureLab';
import { SpringBootDeploymentHub } from './components/SpringBootDeploymentHub';
import { AlertTriangle, Home, LogOut, Wrench, Lock, ShieldAlert, ArrowRight } from 'lucide-react';

export default function App() {
  // Check if ?autostart=1 is present to skip opening page when needed
  const hasAutostart =
    typeof window !== 'undefined' &&
    new URLSearchParams(window.location.search).get('autostart') === '1';

  const [isOpeningHubOpen, setIsOpeningHubOpen] = useState<boolean>(!hasAutostart);
  const [isExited, setIsExited] = useState<boolean>(false);
  const [currentUserRole, setCurrentUserRole] = useState<UserRole>('PASSENGER');
  const [activeTab, setActiveTab] = useState<ActiveTab>('booking');

  // Core Operations State
  const [flights, setFlights] = useState<Flight[]>(INITIAL_FLIGHTS);
  const [gates, setGates] = useState<Gate[]>(INITIAL_GATES);
  const [passengerFleet, setPassengerFleet] = useState<PassengerAircraft[]>(
    INITIAL_AIRCRAFT_PASSENGER
  );
  const [cargoFleet, setCargoFleet] = useState<CargoAircraft[]>(INITIAL_AIRCRAFT_CARGO);
  const [passengers] = useState<Passenger[]>(INITIAL_PASSENGERS);
  const [staff, setStaff] = useState<Staff[]>(INITIAL_STAFF);
  const [tickets, setTickets] = useState<Ticket[]>(INITIAL_TICKETS);
  const [baggage, setBaggage] = useState<Baggage[]>(INITIAL_BAGGAGE);
  const [baggageManifests, setBaggageManifests] = useState<FlightBaggageManifest[]>(
    INITIAL_BAGGAGE_MANIFESTS
  );
  const [notifications, setNotifications] = useState<FlightNotification[]>(
    INITIAL_NOTIFICATIONS
  );
  const [incidents, setIncidents] = useState<EmergencyIncident[]>([INITIAL_EMERGENCY]);

  // Modals & Navigation Helpers
  const [bookingModalFlight, setBookingModalFlight] = useState<Flight | null>(null);
  const [preSelectedFlightId, setPreSelectedFlightId] = useState<string | undefined>(
    undefined
  );
  const [activeBoardingPassTicket, setActiveBoardingPassTicket] = useState<Ticket | null>(
    null
  );
  const [isEmergencyModalOpen, setIsEmergencyModalOpen] = useState(false);

  const activeIncidents = incidents.filter((i) => i.status === 'ACTIVE');
  const hasActiveEmergency = activeIncidents.length > 0;

  // Role Switcher Handler: ensure activeTab matches new role
  const handleRoleChange = (newRole: UserRole) => {
    setCurrentUserRole(newRole);
    const authorizedList = ROLE_MENU_MAP[newRole] || [];
    const isCurrentTabValid = authorizedList.some((m) => m.id === activeTab);
    if (!isCurrentTabValid && authorizedList.length > 0) {
      setActiveTab(authorizedList[0].id);
    }
  };

  // Select first bookable (non-landed) passenger flight for Quick Book
  const firstBookableFlight =
    flights.find(
      (f) =>
        f.aircraftCategory === 'PASSENGER' &&
        f.status !== 'LANDED' &&
        f.status !== 'DEPARTED' &&
        f.status !== 'CANCELLED'
    ) || flights[0];

  // Multiple-Seat Booking Confirmation Handler
  const handleConfirmMultiBooking = (
    flight: Flight,
    seatAssignments: {
      seatNumber: string;
      seatClass: SeatClass;
      passengerName: string;
      passengerId?: string;
    }[],
    totalPrice: number,
    _paymentMethod: PaymentMethod
  ) => {
    if (
      flight.status === 'LANDED' ||
      flight.status === 'DEPARTED' ||
      flight.status === 'CANCELLED'
    )
      return;

    const newTickets: Ticket[] = [];
    const newBags: Baggage[] = [];

    seatAssignments.forEach((assign) => {
      const pnr = `AF${Math.floor(100 + Math.random() * 900)}${String.fromCharCode(
        65 + Math.floor(Math.random() * 26)
      )}`;

      const singlePrice = Math.round(totalPrice / seatAssignments.length);

      const tkt: Ticket = {
        id: `tkt-${Date.now()}-${assign.seatNumber}`,
        pnr,
        flightId: flight.id,
        flightNumber: flight.flightNumber,
        passengerId: assign.passengerId || `psg-${Date.now()}`,
        passengerName: assign.passengerName,
        seatNumber: assign.seatNumber,
        travelClass: assign.seatClass,
        price: singlePrice,
        bookingTimestamp: new Date().toISOString(),
        status: 'CONFIRMED',
        paymentId: `pay-${Date.now()}`,
        baggageAllowanceKg:
          assign.seatClass === 'FIRST' ? 64 : assign.seatClass === 'BUSINESS' ? 46 : 23,
      };

      const bag: Baggage = {
        id: `bag-${Date.now()}-${assign.seatNumber}`,
        tagNumber: `BAG-${Math.floor(1000 + Math.random() * 9000)}-${Math.floor(
          10 + Math.random() * 90
        )}`,
        ticketId: tkt.id,
        flightId: flight.id,
        flightNumber: flight.flightNumber,
        passengerName: assign.passengerName,
        weightKg: 20.5,
        status: 'CHECKED_IN',
        isOverweight: false,
        carouselNumber: 'T1-Carousel 2',
        lastUpdated: new Date().toLocaleTimeString([], {
          hour: '2-digit',
          minute: '2-digit',
        }),
      };

      newTickets.push(tkt);
      newBags.push(bag);
    });

    setTickets((prev) => [...newTickets, ...prev]);
    setBaggage((prev) => [...newBags, ...prev]);

    // Increment bulk manifest for that flight
    setBaggageManifests((prev) =>
      prev.map((m) =>
        m.flightId === flight.id
          ? {
              ...m,
              totalBags: m.totalBags + newBags.length,
              totalWeightKg: Math.round(m.totalWeightKg + 21 * newBags.length),
              stageBreakdown: {
                ...m.stageBreakdown,
                checkedIn: m.stageBreakdown.checkedIn + newBags.length,
              },
            }
          : m
      )
    );

    setFlights((prev) =>
      prev.map((f) =>
        f.id === flight.id
          ? { ...f, bookedSeats: f.bookedSeats + seatAssignments.length }
          : f
      )
    );

    if (newTickets.length > 0) {
      setActiveBoardingPassTicket(newTickets[0]);
    }
  };

  // Single booking modal fallback handler (re-routes through multi-booking)
  const handleConfirmSingleBooking = (
    flight: Flight,
    passenger: Passenger,
    seatNumber: string,
    seatClass: SeatClass,
    finalPrice: number,
    paymentMethod: PaymentMethod
  ) => {
    handleConfirmMultiBooking(
      flight,
      [
        {
          seatNumber,
          seatClass,
          passengerName: passenger.fullName,
          passengerId: passenger.id,
        },
      ],
      finalPrice,
      paymentMethod
    );
    setBookingModalFlight(null);
  };

  // Update Flight Status (Allowed for ATC & Manager/Admin)
  const handleUpdateFlightStatus = (flightId: string, status: FlightStatus) => {
    if (currentUserRole !== 'ATC' && currentUserRole !== 'MANAGER_ADMIN') return;
    setFlights((prev) =>
      prev.map((f) => (f.id === flightId ? { ...f, status } : f))
    );
  };

  // Report Delay (Allowed for ATC & Manager/Admin)
  const handleReportDelay = (
    flightId: string,
    minutes: number,
    reason: 'WEATHER' | 'ATC_HOLD' | 'MAINTENANCE' | 'CREW_REST'
  ) => {
    if (currentUserRole !== 'ATC' && currentUserRole !== 'MANAGER_ADMIN') return;
    setFlights((prev) =>
      prev.map((f) => {
        if (f.id !== flightId) return f;
        const [hh, mm] = f.scheduledDeparture.split(':').map(Number);
        const totalMinutes = hh * 60 + mm + minutes;
        const newHH = Math.floor(totalMinutes / 60) % 24;
        const newMM = totalMinutes % 60;
        const estStr = `${String(newHH).padStart(2, '0')}:${String(newMM).padStart(
          2,
          '0'
        )}`;

        return {
          ...f,
          status: 'DELAYED',
          delayMinutes: f.delayMinutes + minutes,
          delayReason: reason,
          estimatedDeparture: estStr,
        };
      })
    );
  };

  // Gate Assignment Handlers (ATC, Ground Staff, Manager/Admin)
  const handleAssignGate = (flightId: string, gateId: string) => {
    if (
      currentUserRole !== 'ATC' &&
      currentUserRole !== 'GROUND_STAFF' &&
      currentUserRole !== 'MANAGER_ADMIN'
    )
      return;

    const targetGate = gates.find((g) => g.id === gateId);
    if (!targetGate) return;

    setFlights((prev) =>
      prev.map((f) => {
        if (f.id !== flightId) return f;
        return {
          ...f,
          pendingGateId: targetGate.id,
          pendingGateNumber: targetGate.gateNumber,
          gateAssignmentStatus: 'PENDING_CONFIRMATION',
        };
      })
    );
  };

  const handleConfirmGateAssignment = (flightId: string) => {
    if (
      currentUserRole !== 'ATC' &&
      currentUserRole !== 'GROUND_STAFF' &&
      currentUserRole !== 'MANAGER_ADMIN'
    )
      return;

    const targetFlight = flights.find((f) => f.id === flightId);
    if (!targetFlight || !targetFlight.pendingGateId) return;

    const newGateId = targetFlight.pendingGateId;
    const newGateNumber = targetFlight.pendingGateNumber;
    const oldGateId = targetFlight.gateId;

    setGates((prev) =>
      prev.map((g) => {
        if (g.id === oldGateId) {
          return { ...g, status: 'AVAILABLE', currentFlightId: undefined };
        }
        if (g.id === newGateId) {
          return { ...g, status: 'OCCUPIED', currentFlightId: flightId };
        }
        return g;
      })
    );

    setFlights((prev) =>
      prev.map((f) => {
        if (f.id !== flightId) return f;
        return {
          ...f,
          gateId: newGateId,
          gateNumber: newGateNumber,
          gateAssignmentStatus: 'CONFIRMED',
          pendingGateId: undefined,
          pendingGateNumber: undefined,
        };
      })
    );
  };

  const handleUpdateGateStatus = (gateId: string, status: any) => {
    if (
      currentUserRole !== 'ATC' &&
      currentUserRole !== 'GROUND_STAFF' &&
      currentUserRole !== 'MANAGER_ADMIN'
    )
      return;
    setGates((prev) => prev.map((g) => (g.id === gateId ? { ...g, status } : g)));
  };

  // Baggage Handlers (Passenger, Ground Staff, Manager/Admin)
  const handleUpdateBaggageStatus = (baggageId: string, status: BaggageStatus) => {
    if (currentUserRole !== 'GROUND_STAFF' && currentUserRole !== 'MANAGER_ADMIN')
      return;

    setBaggage((prev) =>
      prev.map((b) =>
        b.id === baggageId
          ? {
              ...b,
              status,
              lastUpdated: new Date().toLocaleTimeString([], {
                hour: '2-digit',
                minute: '2-digit',
              }),
            }
          : b
      )
    );
  };

  const handleAddNewBaggage = (newBag: Baggage) => {
    setBaggage((prev) => [newBag, ...prev]);
  };

  const handleAdvanceBulkManifest = (
    flightId: string,
    action: 'OFFLOAD_ULD' | 'CLAIM_BATCH' | 'LOAD_HOLD' | 'ADD_BULK_100'
  ) => {
    if (currentUserRole !== 'GROUND_STAFF' && currentUserRole !== 'MANAGER_ADMIN')
      return;

    setBaggageManifests((prev) =>
      prev.map((m) => {
        if (m.flightId !== flightId) return m;

        const nextBreakdown = { ...m.stageBreakdown };
        let nextTotalBags = m.totalBags;
        let nextWeight = m.totalWeightKg;

        if (action === 'ADD_BULK_100') {
          nextTotalBags += 100;
          nextWeight += 2200;
          nextBreakdown.checkedIn += 100;
        } else if (action === 'LOAD_HOLD') {
          const shift = Math.min(nextBreakdown.rampSort, 40);
          nextBreakdown.rampSort -= shift;
          nextBreakdown.loadedHold += shift;
        } else if (action === 'OFFLOAD_ULD') {
          const shift = Math.min(nextBreakdown.loadedHold, 50);
          nextBreakdown.loadedHold -= shift;
          nextBreakdown.carouselUnloaded += shift;
        } else if (action === 'CLAIM_BATCH') {
          const shift = Math.min(nextBreakdown.carouselUnloaded, 35);
          nextBreakdown.carouselUnloaded -= shift;
          nextBreakdown.claimed += shift;
        }

        return {
          ...m,
          totalBags: nextTotalBags,
          totalWeightKg: nextWeight,
          stageBreakdown: nextBreakdown,
          lastTelemetrySync: `${new Date().toLocaleTimeString([], {
            hour: '2-digit',
            minute: '2-digit',
          })} UTC`,
        };
      })
    );
  };

  // Emergency Handlers (Pilot/Crew, ATC, Manager/Admin)
  const handleDeclareEmergency = (
    flightId: string,
    type: EmergencyType,
    declaredByRole: EmergencyDeclarerRole = 'CAPTAIN_PILOT',
    declaredByName: string = 'Capt. Marcus Vance',
    severity: 'CRITICAL' | 'HIGH' = 'CRITICAL'
  ) => {
    if (currentUserRole === 'PASSENGER') return;

    const targetFlight = flights.find((f) => f.id === flightId);
    const flightNum = targetFlight ? targetFlight.flightNumber : 'AF-999';
    const aircraftTail = targetFlight ? targetFlight.aircraftTail : 'N-UNKNOWN';

    const rule =
      EMERGENCY_TYPE_RULES.find((r) => r.type === type) || EMERGENCY_TYPE_RULES[0];
    const initialFixes = rule.defaultFixes.map((f, index: number) => ({
      id: `fix-${Date.now()}-${index}`,
      label: f.label,
      subsystem: f.subsystem,
      status: 'PENDING' as const,
    }));

    const newIncident: EmergencyIncident = {
      id: `inc-${Date.now()}`,
      flightId,
      flightNumber: flightNum,
      aircraftTail,
      type,
      declaredByRole,
      declaredByName,
      severity,
      status: 'ACTIVE',
      reportedAt: `${new Date().toLocaleTimeString([], {
        hour: '2-digit',
        minute: '2-digit',
      })} UTC`,
      actionTaken: `Initiated emergency SOP for ${rule.label}. CFR Units assigned.`,
      assignedRunway: '04L (Priority Hold)',
      assignedGate: 'Remote De-Ice Apron / Hazmat Stand',
      emergencyUnitsDispatched: ['ARFF Foam Tender 1', 'Airport Medical 3', 'Ramp Ops Lead'],
      operationFixes: initialFixes,
    };

    setIncidents((prev) => [newIncident, ...prev]);

    setFlights((prev) =>
      prev.map((f) => (f.id === flightId ? { ...f, status: 'DELAYED', delayMinutes: 60 } : f))
    );
  };

  const handleApplyOperationFix = (incidentId: string, fixId: string) => {
    const nowStr = `${new Date().toLocaleTimeString([], {
      hour: '2-digit',
      minute: '2-digit',
    })} UTC`;

    setIncidents((prev) =>
      prev.map((inc) =>
        inc.id === incidentId
          ? {
              ...inc,
              operationFixes: inc.operationFixes.map((fix) =>
                fix.id === fixId
                  ? { ...fix, status: 'APPLIED', appliedAt: nowStr }
                  : fix
              ),
            }
          : inc
      )
    );
  };

  const handleApplyAllOperationFixes = (incidentId: string) => {
    const nowStr = `${new Date().toLocaleTimeString([], {
      hour: '2-digit',
      minute: '2-digit',
    })} UTC`;

    setIncidents((prev) =>
      prev.map((inc) =>
        inc.id === incidentId
          ? {
              ...inc,
              operationFixes: inc.operationFixes.map((fix) => ({
                ...fix,
                status: 'APPLIED',
                appliedAt: fix.appliedAt || nowStr,
              })),
            }
          : inc
      )
    );
  };

  const handleAddCustomOperationFix = (
    incidentId: string,
    label: string,
    subsystem: string
  ) => {
    const nowStr = `${new Date().toLocaleTimeString([], {
      hour: '2-digit',
      minute: '2-digit',
    })} UTC`;

    setIncidents((prev) =>
      prev.map((inc) =>
        inc.id === incidentId
          ? {
              ...inc,
              operationFixes: [
                ...inc.operationFixes,
                {
                  id: `fix-custom-${Date.now()}`,
                  label,
                  subsystem,
                  status: 'APPLIED',
                  appliedAt: nowStr,
                },
              ],
            }
          : inc
      )
    );
  };

  const handleResolveEmergency = (incidentId: string) => {
    handleApplyAllOperationFixes(incidentId);
    setIncidents((prev) =>
      prev.map((i) => (i.id === incidentId ? { ...i, status: 'RESOLVED' } : i))
    );
  };

  // Fleet handlers (Ground Staff & Manager/Admin)
  const handleRefuelAircraft = (
    aircraftId: string,
    category: 'PASSENGER' | 'CARGO'
  ) => {
    if (currentUserRole !== 'GROUND_STAFF' && currentUserRole !== 'MANAGER_ADMIN')
      return;

    if (category === 'PASSENGER') {
      setPassengerFleet((prev) =>
        prev.map((a) => (a.id === aircraftId ? { ...a, currentFuelPercent: 100 } : a))
      );
    } else {
      setCargoFleet((prev) =>
        prev.map((a) => (a.id === aircraftId ? { ...a, currentFuelPercent: 100 } : a))
      );
    }
  };

  const handleToggleMaintenance = (
    aircraftId: string,
    category: 'PASSENGER' | 'CARGO'
  ) => {
    if (currentUserRole !== 'GROUND_STAFF' && currentUserRole !== 'MANAGER_ADMIN')
      return;

    if (category === 'PASSENGER') {
      setPassengerFleet((prev) =>
        prev.map((a) =>
          a.id === aircraftId
            ? {
                ...a,
                status: a.status === 'IN_SERVICE' ? 'MAINTENANCE_DUE' : 'IN_SERVICE',
              }
            : a
        )
      );
    } else {
      setCargoFleet((prev) =>
        prev.map((a) =>
          a.id === aircraftId
            ? {
                ...a,
                status: a.status === 'IN_SERVICE' ? 'MAINTENANCE_DUE' : 'IN_SERVICE',
              }
            : a
        )
      );
    }
  };

  // Staff duty status & rest hours handlers (Pilot/Crew, Manager/Admin)
  const handleToggleDutyStatus = (staffId: string, nextStatus: DutyStatus) => {
    setStaff((prev) =>
      prev.map((s) => (s.id === staffId ? { ...s, dutyStatus: nextStatus } : s))
    );
  };

  const handleLogCrewRestHours = (staffId: string, additionalHours: number) => {
    setStaff((prev) =>
      prev.map((s) =>
        s.id === staffId
          ? {
              ...s,
              restHoursCompleted: Number(
                (s.restHoursCompleted + additionalHours).toFixed(1)
              ),
            }
          : s
      )
    );
  };

  // Boarding simulator handlers
  const handleBoardPassenger = (ticket: Ticket) => {
    setTickets((prev) =>
      prev.map((t) => (t.id === ticket.id ? { ...t, status: 'BOARDED' } : t))
    );
  };

  const handleResetBoarding = () => {
    setTickets((prev) =>
      prev.map((t) =>
        t.status === 'BOARDED' ? { ...t, status: 'CHECKED_IN' } : t
      )
    );
  };

  // Check if current tab is authorized for the logged-in role
  const authorizedMenus = ROLE_MENU_MAP[currentUserRole] || ROLE_MENU_MAP.PASSENGER;
  const isCurrentTabAuthorized = authorizedMenus.some((m) => m.id === activeTab);
  const currentMenuMeta =
    authorizedMenus.find((m) => m.id === activeTab) ||
    authorizedMenus[0] || { id: activeTab, label: 'Operations', shortDesc: '' };

  // 1. Render Opening Page (Aircraft Logo + Menu Hub) or Exited State
  if (isOpeningHubOpen || isExited) {
    return (
      <OpeningHub
        onSelectMenuModule={(selectedTab) => {
          setActiveTab(selectedTab);
          setIsOpeningHubOpen(false);
          setIsExited(false);
        }}
        currentUserRole={currentUserRole}
        onChangeUserRole={handleRoleChange}
        hasActiveEmergency={hasActiveEmergency}
        onExitSystem={() => {
          setIsExited(true);
          setIsOpeningHubOpen(true);
        }}
        isExited={isExited}
        onRelaunchSystem={() => {
          setIsExited(false);
          setIsOpeningHubOpen(true);
        }}
      />
    );
  }

  // 2. Render Workspace with Role-Based Left-Side Sidebar Navigation
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col lg:flex-row font-sans selection:bg-sky-500 selection:text-white">
      {/* Left-Side Sidebar Navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        hasActiveEmergency={hasActiveEmergency}
        activeIncidentCount={activeIncidents.length}
        onOpenEmergencyModal={() => setIsEmergencyModalOpen(true)}
        onQuickBook={() => {
          setPreSelectedFlightId(firstBookableFlight.id);
          setActiveTab('booking');
        }}
        currentUserRole={currentUserRole}
        onChangeUserRole={handleRoleChange}
        onReturnToOpening={() => setIsOpeningHubOpen(true)}
        onExitSystem={() => {
          setIsExited(true);
          setIsOpeningHubOpen(true);
        }}
      />

      {/* Right Column: Contextual Header + Active Page Content + Footer */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Contextual Workspace Header */}
        <header className="sticky top-0 z-20 border-b border-slate-800 bg-slate-950/90 backdrop-blur-md px-4 sm:px-6 lg:px-8 py-3 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-xs">
            <button
              onClick={() => setIsOpeningHubOpen(true)}
              className="text-slate-400 hover:text-white transition-colors flex items-center gap-1"
            >
              <Home className="h-3.5 w-3.5" />
              <span>Opening Menu</span>
            </button>
            <span aria-hidden="true" className="text-slate-600">
              /
            </span>
            <span className="font-semibold text-white">{currentMenuMeta.label}</span>
            <span aria-hidden="true" className="text-slate-600 hidden sm:inline">
              ·
            </span>
            <span className="text-sky-400 hidden md:inline font-medium">
              Role: {USER_ROLES.find((r) => r.id === currentUserRole)?.label}
            </span>
          </div>

          <div className="flex items-center gap-2.5">
            {hasActiveEmergency && authorizedMenus.some((m) => m.id === 'emergency') && (
              <button
                onClick={() => setActiveTab('emergency')}
                className="flex items-center gap-1.5 rounded-lg border border-rose-500/50 bg-rose-950/80 px-3 py-1.5 text-xs font-semibold text-rose-200 hover:bg-rose-900 transition-colors whitespace-nowrap"
              >
                <Wrench className="h-3.5 w-3.5 text-rose-400" />
                <span>Emergency Operation Fixes ({activeIncidents.length})</span>
              </button>
            )}

            <button
              onClick={() => {
                setIsExited(true);
                setIsOpeningHubOpen(true);
              }}
              className="flex items-center gap-1.5 rounded-lg border border-rose-500/40 bg-rose-950/50 px-3 py-1.5 text-xs font-semibold text-rose-200 hover:bg-rose-900/80 transition-colors whitespace-nowrap"
            >
              <LogOut className="h-3.5 w-3.5" />
              <span>Exit</span>
            </button>
          </div>
        </header>

        {/* Main Content Viewport */}
        <main className="flex-1 w-full max-w-[1380px] mx-auto p-4 sm:p-6 lg:p-8">
          {/* Security Guard: BLOCK direct unauthorized access */}
          {!isCurrentTabAuthorized ? (
            <div className="rounded-2xl border border-rose-500/40 bg-rose-950/20 p-8 sm:p-12 text-center space-y-4 max-w-xl mx-auto my-12">
              <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-rose-900/50 text-rose-400 border border-rose-500/30">
                <Lock className="h-8 w-8" />
              </div>
              <div className="space-y-2">
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-500/20 text-rose-300 text-xs font-mono font-semibold uppercase">
                  <ShieldAlert className="h-3.5 w-3.5" />
                  <span>Access Blocked · Unauthorized Menu</span>
                </div>
                <h2 className="text-xl font-bold text-white">
                  Restricted to Authorized Personnel
                </h2>
                <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
                  You are currently logged in as{' '}
                  <span className="text-white font-semibold">
                    {USER_ROLES.find((r) => r.id === currentUserRole)?.label}
                  </span>
                  . This module is not permitted for your operational access level. Please select an authorized menu below.
                </p>
              </div>

              <div className="flex flex-wrap items-center justify-center gap-2 pt-2">
                {authorizedMenus.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => setActiveTab(item.id)}
                    className="flex items-center gap-1.5 rounded-xl bg-slate-800 border border-slate-700 px-4 py-2 text-xs font-medium text-slate-200 hover:bg-sky-600 hover:text-white hover:border-sky-500 transition-colors"
                  >
                    <span>{item.label}</span>
                    <ArrowRight className="h-3 w-3" />
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <>
              {/* 1. Ticket Booking (Separate dedicated menu!) */}
              {activeTab === 'booking' && (
                <TicketBookingView
                  flights={flights}
                  passengerFleet={passengerFleet}
                  passengers={passengers}
                  existingTickets={tickets}
                  preSelectedFlightId={preSelectedFlightId}
                  onConfirmMultiBooking={handleConfirmMultiBooking}
                  onViewBoardingPass={(tkt) => setActiveBoardingPassTicket(tkt)}
                />
              )}

              {/* 2. Flight Details (Passenger) */}
              {activeTab === 'flight-details' && (
                <PassengerFlightDetailsView
                  flights={flights}
                  gates={gates}
                  passengerFleet={passengerFleet}
                  onBookFlight={(f) => {
                    setPreSelectedFlightId(f.id);
                    setActiveTab('booking');
                  }}
                />
              )}

              {/* 3. Tickets (Passenger) */}
              {activeTab === 'tickets' && (
                <PassengerTicketsView
                  tickets={tickets}
                  flights={flights}
                  onOpenBoardingPass={(tkt) => setActiveBoardingPassTicket(tkt)}
                  onBookMoreFlights={() => setActiveTab('booking')}
                />
              )}

              {/* 4. Assigned Flights (Pilot/Crew) */}
              {activeTab === 'assigned-flights' && (
                <PilotAssignedFlightsView
                  flights={flights}
                  staff={staff}
                  gates={gates}
                  onTriggerEmergency={(flight) => {
                    handleDeclareEmergency(
                      flight.id,
                      'BIRD_STRIKE',
                      'CAPTAIN_PILOT',
                      'Capt. Marcus Vance',
                      'HIGH'
                    );
                  }}
                />
              )}

              {/* 5. Management (Manager/Admin) */}
              {activeTab === 'management' && (
                <ManagementHubView
                  flights={flights}
                  gates={gates}
                  passengerFleet={passengerFleet}
                  cargoFleet={cargoFleet}
                  staff={staff}
                  tickets={tickets}
                  baggage={baggage}
                  baggageManifests={baggageManifests}
                  incidents={incidents}
                  onNavigateToTab={(tab) => setActiveTab(tab)}
                />
              )}

              {/* 6. Flight Operations / Flights (ATC & Manager/Admin) */}
              {activeTab === 'flights' && (
                <FlightBoard
                  flights={flights}
                  gates={gates}
                  passengerFleet={passengerFleet}
                  onSelectFlightForBooking={(flight) => {
                    if (
                      flight.status !== 'LANDED' &&
                      flight.status !== 'DEPARTED' &&
                      flight.status !== 'CANCELLED'
                    ) {
                      setPreSelectedFlightId(flight.id);
                      setActiveTab('booking');
                    }
                  }}
                  onUpdateFlightStatus={handleUpdateFlightStatus}
                  onReportDelay={handleReportDelay}
                  onAssignGate={handleAssignGate}
                  onConfirmGateAssignment={handleConfirmGateAssignment}
                  onTriggerEmergency={(flight) => {
                    handleDeclareEmergency(
                      flight.id,
                      'BIRD_STRIKE',
                      'CAPTAIN_PILOT',
                      'Capt. Marcus Vance',
                      'HIGH'
                    );
                  }}
                  onAddNewFlight={(newFlight) =>
                    setFlights((prev) => [newFlight, ...prev])
                  }
                />
              )}

              {/* 7. Gates (ATC, Ground Staff, Manager/Admin) */}
              {activeTab === 'gates' && (
                <GateManager
                  gates={gates}
                  flights={flights}
                  onAssignGate={handleAssignGate}
                  onConfirmGateAssignment={handleConfirmGateAssignment}
                  onUpdateGateStatus={handleUpdateGateStatus}
                />
              )}

              {/* 8. Baggage (Passenger, Ground Staff, Manager/Admin) */}
              {activeTab === 'baggage' && (
                <BaggageTracker
                  baggageList={baggage}
                  baggageManifests={baggageManifests}
                  flights={flights}
                  onUpdateBaggageStatus={handleUpdateBaggageStatus}
                  onAddNewBaggage={handleAddNewBaggage}
                  onAdvanceBulkManifest={handleAdvanceBulkManifest}
                />
              )}

              {/* 9. Crew (Pilot/Crew, Manager/Admin) */}
              {activeTab === 'crew' && (
                <CrewManager
                  staffList={staff}
                  flights={flights}
                  onToggleDutyStatus={handleToggleDutyStatus}
                  onLogCrewRestHours={handleLogCrewRestHours}
                  onAssignFlight={(staffId, flightId) => {
                    setStaff((prev) =>
                      prev.map((s) =>
                        s.id === staffId
                          ? { ...s, assignedFlightId: flightId || undefined }
                          : s
                      )
                    );
                  }}
                />
              )}

              {/* 10. Aircraft Fleet (Ground Staff) */}
              {activeTab === 'fleet' && (
                <FleetManager
                  passengerFleet={passengerFleet}
                  cargoFleet={cargoFleet}
                  onRefuelAircraft={handleRefuelAircraft}
                  onToggleMaintenance={handleToggleMaintenance}
                />
              )}

              {/* 11. Emergency Command (Pilot/Crew, ATC, Manager/Admin) */}
              {activeTab === 'emergency' && (
                <EmergencyCenter
                  incidents={incidents}
                  flights={flights}
                  onResolveIncident={handleResolveEmergency}
                  onApplyOperationFix={handleApplyOperationFix}
                  onApplyAllOperationFixes={handleApplyAllOperationFixes}
                  onAddCustomOperationFix={handleAddCustomOperationFix}
                  onDeclareEmergency={handleDeclareEmergency}
                  onExitEmergencyView={() =>
                    setActiveTab(authorizedMenus[0]?.id || 'flights')
                  }
                  onExitSystem={() => {
                    setIsExited(true);
                    setIsOpeningHubOpen(true);
                  }}
                />
              )}

              {/* 12. Analytics (Manager/Admin) */}
              {activeTab === 'analytics' && (
                <AnalyticsDashboard
                  flights={flights}
                  tickets={tickets}
                  gates={gates}
                  baggage={baggage}
                />
              )}
            </>
          )}
        </main>

        {/* Subdued Footer */}
        <footer className="mt-auto border-t border-slate-900 bg-slate-950/80 px-6 py-4 text-xs text-slate-500">
          <div className="max-w-[1380px] mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <span className="font-semibold text-slate-400">
                AeroFlow Aviation System
              </span>
              <span aria-hidden="true">·</span>
              <span>JFK Air Operations Center</span>
              <span aria-hidden="true">·</span>
              <span>Role-Based Console ({USER_ROLES.find((r) => r.id === currentUserRole)?.label})</span>
            </div>
            <div className="flex items-center gap-4 text-[11px]">
              <button
                onClick={() => setIsOpeningHubOpen(true)}
                className="text-slate-400 hover:text-white"
              >
                Opening Menu
              </button>
              <span aria-hidden="true">·</span>
              <button
                onClick={() => {
                  setIsExited(true);
                  setIsOpeningHubOpen(true);
                }}
                className="text-rose-400 hover:underline font-medium"
              >
                Exit System
              </button>
            </div>
          </div>
        </footer>
      </div>

      {/* Boarding Pass Modal */}
      {activeBoardingPassTicket && (
        <BoardingPassModal
          ticket={activeBoardingPassTicket}
          flight={
            flights.find((f) => f.id === activeBoardingPassTicket.flightId) ||
            flights[0]
          }
          onClose={() => setActiveBoardingPassTicket(null)}
          onMarkBoarded={(ticketId) => {
            setTickets((prev) =>
              prev.map((t) => (t.id === ticketId ? { ...t, status: 'BOARDED' } : t))
            );
          }}
        />
      )}

      {/* Emergency Center Quick Modal */}
      {isEmergencyModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="w-full max-w-5xl rounded-2xl border border-rose-500/50 bg-slate-900 p-6 shadow-2xl space-y-4 my-6">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <span className="text-base font-bold text-white flex items-center gap-2">
                <AlertTriangle className="h-4 w-4 text-rose-400" />
                <span>Emergency Response & Operation Fixes Console</span>
              </span>
              <button
                onClick={() => setIsEmergencyModalOpen(false)}
                className="rounded-lg px-3 py-1 text-xs text-slate-400 hover:text-white"
              >
                Close Window
              </button>
            </div>
            <EmergencyCenter
              incidents={incidents}
              flights={flights}
              onResolveIncident={handleResolveEmergency}
              onApplyOperationFix={handleApplyOperationFix}
              onApplyAllOperationFixes={handleApplyAllOperationFixes}
              onAddCustomOperationFix={handleAddCustomOperationFix}
              onDeclareEmergency={handleDeclareEmergency}
              onExitEmergencyView={() => setIsEmergencyModalOpen(false)}
              onExitSystem={() => {
                setIsEmergencyModalOpen(false);
                setIsExited(true);
                setIsOpeningHubOpen(true);
              }}
            />
          </div>
        </div>
      )}
    </div>
  );
}
