export interface CodeFile {
  path: string;
  name: string;
  language: string;
  category: 'core' | 'model' | 'service' | 'controller' | 'exception' | 'config' | 'test' | 'deployment';
  oopConcept: string;
  code: string;
}

export const SPRING_BOOT_CODEBASE: CodeFile[] = [
  {
    path: 'pom.xml',
    name: 'pom.xml',
    language: 'xml',
    category: 'config',
    oopConcept: 'Maven Build & Dependencies (Spring Boot 3.3.4, Java 21, JUnit 5, Lombok, Validation)',
    code: `<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>
    <parent>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-parent</artifactId>
        <version>3.3.4</version>
        <relativePath/>
    </parent>
    <groupId>com.aeroflow</groupId>
    <artifactId>aeroflow-airport-ops</artifactId>
    <version>1.0.0-SNAPSHOT</version>
    <name>AeroFlow Airport Operations Platform</name>
    <description>Enterprise Airport Management System showcasing Java OOP & Concurrency</description>

    <properties>
        <java.version>21</java.version>
    </properties>

    <dependencies>
        <!-- Spring Boot Starters -->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-web</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-data-jpa</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-validation</artifactId>
        </dependency>

        <!-- Database: PostgreSQL for Production, H2 for Fast In-Memory Demo -->
        <dependency>
            <groupId>org.postgresql</groupId>
            <artifactId>postgresql</artifactId>
            <scope>runtime</scope>
        </dependency>
        <dependency>
            <groupId>com.h2database</groupId>
            <artifactId>h2</artifactId>
            <scope>runtime</scope>
        </dependency>

        <!-- Lombok for Clean Encapsulation & Boilerplate Reduction -->
        <dependency>
            <groupId>org.projectlombok</groupId>
            <artifactId>lombok</artifactId>
            <optional>true</optional>
        </dependency>

        <!-- Testing: JUnit 5 & Mockito -->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-test</artifactId>
            <scope>test</scope>
        </dependency>
    </dependencies>

    <build>
        <plugins>
            <plugin>
                <groupId>org.springframework.boot</groupId>
                <artifactId>spring-boot-maven-plugin</artifactId>
            </plugin>
        </plugins>
    </build>
</project>`,
  },
  {
    path: 'src/main/java/com/aeroflow/model/person/Person.java',
    name: 'Person.java',
    language: 'java',
    category: 'model',
    oopConcept: 'Abstract Class & Encapsulation: Base identity for Passengers & Staff',
    code: `package com.aeroflow.model.person;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * OOP Concept: Abstract Class & Encapsulation
 * Person acts as the root abstract entity for all human actors in the airport.
 * Cannot be directly instantiated; must be subclassed by Passenger or Staff.
 */
@MappedSuperclass
@Getter
@Setter
@NoArgsConstructor
public abstract class Person {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    @NotBlank(message = "Full name is required")
    @Column(nullable = false)
    private String fullName;

    @Email(message = "Valid email is mandatory")
    @Column(nullable = false)
    private String email;

    @NotBlank(message = "Phone number is mandatory")
    private String phone;

    private String nationality;

    public Person(String fullName, String email, String phone, String nationality) {
        this.fullName = fullName;
        this.email = email;
        this.phone = phone;
        this.nationality = nationality;
    }

    /**
     * Polymorphic method to be implemented by concrete subclasses
     */
    public abstract String getRoleDescription();
}`,
  },
  {
    path: 'src/main/java/com/aeroflow/model/person/Passenger.java',
    name: 'Passenger.java',
    language: 'java',
    category: 'model',
    oopConcept: 'Inheritance & Polymorphism: Person → Passenger with Frequent Flyer logic',
    code: `package com.aeroflow.model.person;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * OOP Concept: Inheritance (Person -> Passenger) & Polymorphic Override
 */
@Entity
@Table(name = "passengers")
@Getter
@Setter
@NoArgsConstructor
public class Passenger extends Person {

    private String passportNumber;

    @Enumerated(EnumType.STRING)
    private FrequentFlyerTier frequentFlyerTier = FrequentFlyerTier.BRONZE;

    private boolean specialAssistance;
    private boolean fastTrackEligible;
    private int accumulatedMiles;

    public Passenger(String fullName, String email, String phone, String nationality,
                     String passportNumber, FrequentFlyerTier tier) {
        super(fullName, email, phone, nationality);
        this.passportNumber = passportNumber;
        this.frequentFlyerTier = tier;
        this.fastTrackEligible = (tier == FrequentFlyerTier.GOLD || tier == FrequentFlyerTier.PLATINUM);
    }

    @Override
    public String getRoleDescription() {
        return "Passenger [" + frequentFlyerTier + " Tier] - Passport: " + passportNumber;
    }

    public enum FrequentFlyerTier {
        BRONZE, SILVER, GOLD, PLATINUM
    }
}`,
  },
  {
    path: 'src/main/java/com/aeroflow/model/aircraft/Aircraft.java',
    name: 'Aircraft.java',
    language: 'java',
    category: 'model',
    oopConcept: 'Abstract Class & Method Overriding: Passenger vs Cargo Aircraft',
    code: `package com.aeroflow.model.aircraft;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * OOP Concept: Abstract Class
 * Encapsulates common flight physics and avionics properties.
 */
@Entity
@Inheritance(strategy = InheritanceType.JOINED)
@Table(name = "aircrafts")
@Getter
@Setter
@NoArgsConstructor
public abstract class Aircraft {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    @Column(unique = true, nullable = false)
    private String tailNumber;

    private String model;
    private String manufacturer;
    private int rangeKm;
    private double fuelCapacityLiters;
    private double currentFuelPercent;

    @Enumerated(EnumType.STRING)
    private AircraftStatus status = AircraftStatus.IN_SERVICE;

    public Aircraft(String tailNumber, String model, String manufacturer, int rangeKm, double fuelCapacityLiters) {
        this.tailNumber = tailNumber;
        this.model = model;
        this.manufacturer = manufacturer;
        this.rangeKm = rangeKm;
        this.fuelCapacityLiters = fuelCapacityLiters;
        this.currentFuelPercent = 100.0;
    }

    /**
     * Abstract method for Polymorphic Fuel & Payload Calculations
     */
    public abstract double calculateFuelBurnRatePerKm();

    public enum AircraftStatus {
        IN_SERVICE, MAINTENANCE_DUE, GROUNDED
    }
}`,
  },
  {
    path: 'src/main/java/com/aeroflow/model/aircraft/PassengerAircraft.java',
    name: 'PassengerAircraft.java',
    language: 'java',
    category: 'model',
    oopConcept: 'Inheritance (Aircraft → PassengerAircraft) & Polymorphism',
    code: `package com.aeroflow.model.aircraft;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "passenger_aircrafts")
@Getter
@Setter
@NoArgsConstructor
public class PassengerAircraft extends Aircraft {

    private int firstClassSeats;
    private int businessClassSeats;
    private int economyClassSeats;
    private String seatConfiguration; // e.g., "3-3-3"
    private boolean wifiEquipped;

    public PassengerAircraft(String tailNumber, String model, String manufacturer, int rangeKm,
                             double fuelCapacityLiters, int first, int business, int economy) {
        super(tailNumber, model, manufacturer, rangeKm, fuelCapacityLiters);
        this.firstClassSeats = first;
        this.businessClassSeats = business;
        this.economyClassSeats = economy;
        this.wifiEquipped = true;
    }

    public int getTotalPassengerCapacity() {
        return firstClassSeats + businessClassSeats + economyClassSeats;
    }

    @Override
    public double calculateFuelBurnRatePerKm() {
        // Base burn + passenger weight factor
        return 3.2 + (getTotalPassengerCapacity() * 0.008);
    }
}`,
  },
  {
    path: 'src/main/java/com/aeroflow/interfaces/Bookable.java',
    name: 'Bookable.java',
    language: 'java',
    category: 'model',
    oopConcept: 'Interface Abstraction: Contract for Bookable Flight Entities',
    code: `package com.aeroflow.interfaces;

import com.aeroflow.exception.FlightFullException;
import com.aeroflow.exception.SeatUnavailableException;
import com.aeroflow.model.booking.Ticket;
import com.aeroflow.model.person.Passenger;

/**
 * OOP Concept: Interface
 * Defines booking behaviour contract decoupled from implementation.
 */
public interface Bookable {
    Ticket bookSeat(Passenger passenger, String seatNumber, Ticket.SeatClass seatClass)
            throws FlightFullException, SeatUnavailableException;

    boolean cancelBooking(String ticketId);

    int getAvailableSeats();
}`,
  },
  {
    path: 'src/main/java/com/aeroflow/service/ConcurrentBookingService.java',
    name: 'ConcurrentBookingService.java',
    language: 'java',
    category: 'service',
    oopConcept: 'Multithreading & Synchronization: ReentrantLock to prevent double seat booking',
    code: `package com.aeroflow.service;

import com.aeroflow.exception.FlightFullException;
import com.aeroflow.exception.InvalidBookingException;
import com.aeroflow.exception.SeatUnavailableException;
import com.aeroflow.model.booking.Ticket;
import com.aeroflow.model.flight.Flight;
import com.aeroflow.model.person.Passenger;
import com.aeroflow.repository.FlightRepository;
import com.aeroflow.repository.TicketRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.ReentrantLock;

/**
 * OOP Concepts:
 * 1. Multithreading & Synchronization: Uses ReentrantLock per Flight to prevent race conditions.
 * 2. Collections: ConcurrentHashMap for granular thread-safe lock management.
 * 3. Method Overloading: Diverse booking signatures.
 */
@Service
public class ConcurrentBookingService {

    private final FlightRepository flightRepository;
    private final TicketRepository ticketRepository;

    // Granular Lock Map: Flight ID -> Dedicated ReentrantLock
    private final Map<String, ReentrantLock> flightLocks = new ConcurrentHashMap<>();

    public ConcurrentBookingService(FlightRepository flightRepository, TicketRepository ticketRepository) {
        this.flightRepository = flightRepository;
        this.ticketRepository = ticketRepository;
    }

    /**
     * Method Overload 1: Standard booking by seat number
     */
    @Transactional
    public Ticket reserveSeat(String flightId, Passenger passenger, String seatNumber, Ticket.SeatClass travelClass)
            throws FlightFullException, SeatUnavailableException {

        // Acquire thread-safe lock for this specific flight
        ReentrantLock lock = flightLocks.computeIfAbsent(flightId, k -> new ReentrantLock(true));
        lock.lock();

        try {
            Flight flight = flightRepository.findById(flightId)
                    .orElseThrow(() -> new InvalidBookingException("Flight not found: " + flightId));

            if (flight.getBookedSeats() >= flight.getTotalSeats()) {
                throw new FlightFullException("Cannot reserve seat: Flight " + flight.getFlightNumber() + " is at full capacity!");
            }

            // Check if seat is already reserved (Prevents Double Booking)
            boolean seatTaken = ticketRepository.existsByFlightIdAndSeatNumber(flightId, seatNumber);
            if (seatTaken) {
                throw new SeatUnavailableException("Conflict: Seat " + seatNumber + " on flight " + flight.getFlightNumber() + " was just booked by another thread!");
            }

            // Polymorphic Price Calculation
            double finalPrice = flight.calculateTicketPrice(travelClass, passenger.getFrequentFlyerTier());

            Ticket ticket = new Ticket(flight, passenger, seatNumber, travelClass, finalPrice);
            flight.incrementBookedSeats();

            flightRepository.save(flight);
            return ticketRepository.save(ticket);

        } finally {
            lock.unlock(); // Ensure lock is released even on exception
        }
    }

    /**
     * Method Overload 2: Auto-assign next available seat
     */
    public Ticket reserveNextAvailableSeat(String flightId, Passenger passenger, Ticket.SeatClass travelClass)
            throws FlightFullException, SeatUnavailableException {
        String autoAssignedSeat = "AUTO-" + (System.currentTimeMillis() % 100);
        return reserveSeat(flightId, passenger, autoAssignedSeat, travelClass);
    }
}`,
  },
  {
    path: 'src/main/java/com/aeroflow/controller/FlightController.java',
    name: 'FlightController.java',
    language: 'java',
    category: 'controller',
    oopConcept: 'REST API Controller & Streams/Lambdas: Filter and Sort Flights',
    code: `package com.aeroflow.controller;

import com.aeroflow.model.flight.Flight;
import com.aeroflow.service.FlightService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/flights")
@CrossOrigin(origins = "*") // Connect cleanly with React Vite Frontend
public class FlightController {

    private final FlightService flightService;

    public FlightController(FlightService flightService) {
        this.flightService = flightService;
    }

    @GetMapping
    public ResponseEntity<List<Flight>> getAllFlights() {
        return ResponseEntity.ok(flightService.findAllFlights());
    }

    @GetMapping("/search")
    public ResponseEntity<List<Flight>> searchFlights(
            @RequestParam(required = false) String origin,
            @RequestParam(required = false) String destination,
            @RequestParam(required = false) Flight.FlightStatus status) {
        // Leverages Java 8 Streams & Lambdas in service layer
        return ResponseEntity.ok(flightService.filterFlights(origin, destination, status));
    }

    @PostMapping("/{flightId}/delay")
    public ResponseEntity<Flight> reportDelay(
            @PathVariable String flightId,
            @RequestParam int delayMinutes,
            @RequestParam String reason) {
        return ResponseEntity.ok(flightService.registerFlightDelay(flightId, delayMinutes, reason));
    }
}`,
  },
  {
    path: 'src/test/java/com/aeroflow/BookingServiceTest.java',
    name: 'BookingServiceTest.java',
    language: 'java',
    category: 'test',
    oopConcept: 'JUnit 5: Testing Concurrency, Synchronization, and Custom Exceptions',
    code: `package com.aeroflow;

import com.aeroflow.exception.FlightFullException;
import com.aeroflow.exception.SeatUnavailableException;
import com.aeroflow.model.booking.Ticket;
import com.aeroflow.model.flight.Flight;
import com.aeroflow.model.person.Passenger;
import com.aeroflow.repository.FlightRepository;
import com.aeroflow.repository.TicketRepository;
import com.aeroflow.service.ConcurrentBookingService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/**
 * OOP Concept: JUnit 5 Testing Suite
 * Verifies Thread Safety, Multithreading Locks, and Polymorphic Pricing.
 */
@ExtendWith(MockitoExtension.class)
class BookingServiceTest {

    @Mock
    private FlightRepository flightRepository;

    @Mock
    private TicketRepository ticketRepository;

    @InjectMocks
    private ConcurrentBookingService bookingService;

    private Flight testFlight;
    private Passenger testPassenger;

    @BeforeEach
    void setUp() {
        testFlight = new Flight("AF-402", "JFK", "LHR", 100, 500.0);
        testFlight.setId("fl-101");

        testPassenger = new Passenger("Dr. Evelyn Reed", "evelyn@biotech.org",
                "+1-555-0199", "USA", "P99482", Passenger.FrequentFlyerTier.PLATINUM);
    }

    @Test
    @DisplayName("Should successfully book seat when available")
    void testSuccessfulBooking() throws Exception {
        when(flightRepository.findById("fl-101")).thenReturn(Optional.of(testFlight));
        when(ticketRepository.existsByFlightIdAndSeatNumber("fl-101", "14A")).thenReturn(false);
        when(ticketRepository.save(any(Ticket.class))).thenAnswer(i -> i.getArguments()[0]);

        Ticket ticket = bookingService.reserveSeat("fl-101", testPassenger, "14A", Ticket.SeatClass.BUSINESS);

        assertNotNull(ticket);
        assertEquals("14A", ticket.getSeatNumber());
        assertEquals(1, testFlight.getBookedSeats());
    }

    @Test
    @DisplayName("Should throw SeatUnavailableException when seat is already taken")
    void testDoubleBookingPrevention() {
        when(flightRepository.findById("fl-101")).thenReturn(Optional.of(testFlight));
        when(ticketRepository.existsByFlightIdAndSeatNumber("fl-101", "14A")).thenReturn(true);

        assertThrows(SeatUnavailableException.class, () -> {
            bookingService.reserveSeat("fl-101", testPassenger, "14A", Ticket.SeatClass.ECONOMY);
        });
    }

    @Test
    @DisplayName("Should throw FlightFullException when flight capacity is reached")
    void testFlightCapacityLimit() {
        testFlight.setBookedSeats(100);
        when(flightRepository.findById("fl-101")).thenReturn(Optional.of(testFlight));

        assertThrows(FlightFullException.class, () -> {
            bookingService.reserveSeat("fl-101", testPassenger, "22B", Ticket.SeatClass.ECONOMY);
        });
    }
}`,
  },
  {
    path: 'docker-compose.yml',
    name: 'docker-compose.yml',
    language: 'yaml',
    category: 'deployment',
    oopConcept: 'Production Deployment: Multi-tier Containerized Stack (PostgreSQL + Spring Boot + React)',
    code: `version: '3.8'

services:
  # Relational Database for Enterprise Storage
  postgres-db:
    image: postgres:16-alpine
    container_name: aeroflow-postgres
    environment:
      POSTGRES_DB: aeroflow_db
      POSTGRES_USER: aeroflow_admin
      POSTGRES_PASSWORD: supersecretpassword123
    ports:
      - "5432:5432"
    volumes:
      - pgdata:/var/lib/postgresql/data
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U aeroflow_admin -d aeroflow_db"]
      interval: 10s
      timeout: 5s
      retries: 5

  # Spring Boot 3 Backend API Service
  backend:
    build:
      context: ./backend
      dockerfile: Dockerfile
    container_name: aeroflow-backend
    environment:
      SPRING_DATASOURCE_URL: jdbc:postgresql://postgres-db:5432/aeroflow_db
      SPRING_DATASOURCE_USERNAME: aeroflow_admin
      SPRING_DATASOURCE_PASSWORD: supersecretpassword123
      SPRING_JPA_HIBERNATE_DDL_AUTO: update
    ports:
      - "8080:8080"
    depends_on:
      postgres-db:
        condition: service_healthy

  # React Frontend (Vite Single Page App)
  frontend:
    build:
      context: ./frontend
      dockerfile: Dockerfile
    container_name: aeroflow-frontend
    ports:
      - "3000:3000"
    depends_on:
      - backend

volumes:
  pgdata:`,
  },
  {
    path: 'Dockerfile.backend',
    name: 'Dockerfile (Spring Boot)',
    language: 'dockerfile',
    category: 'deployment',
    oopConcept: 'Multi-stage Docker Build for Spring Boot Java 21',
    code: `# Multi-Stage Dockerfile for High Performance & Minimal Image Footprint
FROM maven:3.9.8-eclipse-temurin-21 AS build
WORKDIR /app
COPY pom.xml .
RUN mvn dependency:go-offline -B
COPY src ./src
RUN mvn clean package -DskipTests

FROM eclipse-temurin:21-jre-alpine
WORKDIR /app
COPY --from=build /app/target/aeroflow-airport-ops-*.jar app.jar
EXPOSE 8080
ENTRYPOINT ["java", "-XX:+UseZGC", "-XX:MinRAMPercentage=50", "-XX:MaxRAMPercentage=80", "-jar", "app.jar"]`,
  },
];
