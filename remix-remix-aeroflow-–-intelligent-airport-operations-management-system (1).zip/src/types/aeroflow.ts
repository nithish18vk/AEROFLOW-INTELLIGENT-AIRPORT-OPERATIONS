/**
 * AeroFlow Domain Model Types
 * Designed to mirror Java OOP Architecture:
 * - Abstract Classes (Person, Aircraft, Payment)
 * - Concrete Subclasses (Passenger, Staff, PassengerAircraft, CargoAircraft)
 * - Interfaces (Bookable, Payable, Trackable)
 * - Domain Enums and Concurrency State
 */

export type Role = 'PILOT' | 'FIRST_OFFICER' | 'LEAD_ATTENDANT' | 'CABIN_CREW' | 'GROUND_ENGINEER';
export type UserRole =
  | 'PASSENGER'
  | 'PILOT_CREW'
  | 'ATC'
  | 'GROUND_STAFF'
  | 'MANAGER_ADMIN';

export type DutyStatus = 'ON_DUTY' | 'OFF_DUTY' | 'REST';
export type FrequentFlyerTier = 'BRONZE' | 'SILVER' | 'GOLD' | 'PLATINUM';

// Abstract Class: Person
export interface Person {
  id: string;
  fullName: string;
  email: string;
  phone: string;
  nationality: string;
  type: 'PASSENGER' | 'STAFF';
}

// Inheritance: Person -> Passenger
export interface Passenger extends Person {
  type: 'PASSENGER';
  passportNumber: string;
  frequentFlyerTier: FrequentFlyerTier;
  specialAssistance: boolean;
  fastTrack: boolean;
  accumulatedMiles: number;
}

// Inheritance: Person -> Staff
export interface Staff extends Person {
  type: 'STAFF';
  employeeId: string;
  role: Role;
  licenseNumber: string;
  flightHours: number;
  dutyStatus: DutyStatus;
  assignedFlightId?: string;
  restHoursCompleted: number; // Mandatory >= 8 hours rest before duty
  maxDailyDutyHours: number; // e.g. 10 hours max FDP
  currentShiftHours: number;
  medicalCertValid: boolean;
  qualifiedAircraftModels: string[];
}

export type AircraftStatus = 'IN_SERVICE' | 'MAINTENANCE_DUE' | 'GROUNDED';

// Abstract Class: Aircraft
export interface Aircraft {
  id: string;
  tailNumber: string;
  model: string;
  manufacturer: string;
  rangeKm: number;
  fuelCapacityLiters: number;
  currentFuelPercent: number;
  status: AircraftStatus;
  manufactureYear: number;
  category: 'PASSENGER' | 'CARGO';
}

// Inheritance: Aircraft -> PassengerAircraft
export interface PassengerAircraft extends Aircraft {
  category: 'PASSENGER';
  seatCapacity: {
    first: number;
    business: number;
    economy: number;
    total: number;
  };
  seatConfiguration: string; // e.g. "3-3-3" or "3-3"
  wifiAvailable: boolean;
  entertainmentSystem: boolean;
}

// Inheritance: Aircraft -> CargoAircraft
export interface CargoAircraft extends Aircraft {
  category: 'CARGO';
  maxPayloadTons: number;
  cargoVolumeCubicMeters: number;
  hazardousMaterialCertified: boolean;
  temperatureControlledBays: number;
}

export type Terminal = 'TERMINAL_A' | 'TERMINAL_B' | 'TERMINAL_C';
export type GateType = 'JETBRIDGE' | 'REMOTE_APRON';
export type GateStatus = 'AVAILABLE' | 'OCCUPIED' | 'RESERVED' | 'MAINTENANCE';

// Class: Gate
export interface Gate {
  id: string;
  gateNumber: string; // e.g. "A1", "B4"
  terminal: Terminal;
  type: GateType;
  status: GateStatus;
  maxAircraftWingspanMeters: number;
  currentFlightId?: string;
}

export type FlightStatus =
  | 'SCHEDULED'
  | 'BOARDING'
  | 'DEPARTED'
  | 'IN_FLIGHT'
  | 'LANDED'
  | 'DELAYED'
  | 'CANCELLED';

export type GateAssignmentStatus =
  | 'CONFIRMED'
  | 'PENDING_CONFIRMATION'
  | 'MOVEMENT_PENDING_APPROVAL'
  | 'UNASSIGNED';

// Class: Flight (implements Bookable, Trackable)
export interface Flight {
  id: string;
  flightNumber: string; // e.g. "AF-402"
  airline: string;
  originIata: string;
  originCity: string;
  destinationIata: string;
  destinationCity: string;
  aircraftId: string;
  aircraftTail: string;
  aircraftModel: string;
  aircraftCategory: 'PASSENGER' | 'CARGO';
  gateId?: string;
  gateNumber?: string;
  terminal?: Terminal;
  scheduledDeparture: string; // ISO string or HH:mm
  estimatedDeparture: string;
  scheduledArrival: string;
  departureDate?: string; // YYYY-MM-DD
  daysUntilDeparture?: number; // Gate assignment rule: assign 2 days before departure
  gateAssignmentStatus?: GateAssignmentStatus;
  pendingGateId?: string;
  pendingGateNumber?: string;
  gatePermissionBy?: string;
  gateMovementReason?: string;
  status: FlightStatus;
  delayMinutes: number;
  delayReason?: 'WEATHER' | 'ATC_HOLD' | 'MAINTENANCE' | 'CREW_REST' | 'NONE';
  basePrice: number;
  totalSeats: number;
  bookedSeats: number;
  assignedCrewIds: string[];
}

export type SeatClass = 'FIRST' | 'BUSINESS' | 'ECONOMY';
export type TicketStatus = 'CONFIRMED' | 'CHECKED_IN' | 'BOARDED' | 'CANCELLED';

// Class: Ticket (implements Payable)
export interface Ticket {
  id: string;
  pnr: string; // 6-character Booking Reference (e.g. "AF892X")
  flightId: string;
  flightNumber: string;
  passengerId: string;
  passengerName: string;
  seatNumber: string;
  travelClass: SeatClass;
  price: number;
  bookingTimestamp: string;
  status: TicketStatus;
  paymentId: string;
  baggageAllowanceKg: number;
}

export type BaggageStatus =
  | 'CHECKED_IN'
  | 'SECURITY_CLEARED'
  | 'RAMP_SORT'
  | 'LOADED'
  | 'IN_TRANSIT'
  | 'CAROUSEL_UNLOADED'
  | 'CLAIMED';

// Class: Baggage (individual RFID exception or VIP piece)
export interface Baggage {
  id: string;
  tagNumber: string; // RFID Barcode e.g. "BAG-7821-99"
  ticketId: string;
  flightId: string;
  flightNumber: string;
  passengerName: string;
  weightKg: number;
  status: BaggageStatus;
  isOverweight: boolean;
  carouselNumber?: string;
  lastUpdated: string;
}

// Realistic Bulk Flight Baggage Manifest (100-500+ bags per flight)
export interface FlightBaggageManifest {
  flightId: string;
  flightNumber: string;
  route: string;
  aircraftModel: string;
  flightStatus: FlightStatus;
  totalBags: number; // e.g., 150 to 520 bags
  totalWeightKg: number;
  uldContainersCount: number; // e.g., 10-14 ULD containers
  carouselNumber: string;
  stageBreakdown: {
    checkedIn: number;
    securityCleared: number;
    rampSort: number;
    loadedHold: number;
    inTransit: number;
    carouselUnloaded: number;
    claimed: number;
  };
  priorityBags: number;
  transferBags: number;
  overweightCount: number;
  lastTelemetrySync: string;
}

// Abstract Class: Payment
export type PaymentMethod = 'CREDIT_CARD' | 'CORPORATE_BILLING' | 'AIRLINE_MILES';

export interface Payment {
  id: string;
  ticketId: string;
  amount: number;
  currency: string;
  method: PaymentMethod;
  status: 'SUCCESS' | 'FAILED' | 'REFUNDED';
  transactionTimestamp: string;
  referenceNumber: string;
  details: {
    lastFourDigits?: string;
    corporateAccountId?: string;
    milesRedeemed?: number;
    authCode: string;
  };
}

export interface FlightNotification {
  id: string;
  flightId?: string;
  flightNumber?: string;
  title: string;
  message: string;
  timestamp: string;
  channel: 'SMS' | 'EMAIL' | 'PA_ANNOUNCEMENT' | 'APP_PUSH';
  priority: 'NORMAL' | 'URGENT' | 'EMERGENCY';
  sentToCount: number;
}

export type EmergencyType =
  | 'MEDICAL'
  | 'ENGINE_FAILURE'
  | 'BIRD_STRIKE'
  | 'SEVERE_TURBULENCE'
  | 'HYDRAULIC_LEAK'
  | 'CABIN_DEPRESSURIZATION'
  | 'FUEL_EMERGENCY'
  | 'SECURITY_THREAT'
  | 'RUNWAY_INCURSION';

export type EmergencyDeclarerRole =
  | 'CAPTAIN_PILOT'
  | 'FIRST_OFFICER'
  | 'ATC_CONTROLLER'
  | 'LEAD_ATTENDANT'
  | 'GROUND_ENGINEER'
  | 'RAMP_SUPERVISOR'
  | 'AIRPORT_SECURITY';

export interface EmergencyOperationFix {
  id: string;
  label: string;
  subsystem: string;
  status: 'PENDING' | 'APPLIED';
  appliedAt?: string;
}

export interface EmergencyIncident {
  id: string;
  flightId: string;
  flightNumber: string;
  aircraftTail: string;
  type: EmergencyType;
  declaredByRole: EmergencyDeclarerRole;
  declaredByName: string;
  severity: 'CRITICAL' | 'HIGH';
  status: 'ACTIVE' | 'RESOLVED';
  reportedAt: string;
  actionTaken: string;
  assignedRunway: string;
  assignedGate: string;
  emergencyUnitsDispatched: string[];
  operationFixes: EmergencyOperationFix[];
}
