import React, { useState } from 'react';
import { Gate, Flight, Terminal } from '../types/aeroflow';
import {
  AlertCircle,
  CheckCircle2,
  ArrowRightLeft,
  Wrench,
  Radio,
  ShieldCheck,
  CalendarClock,
} from 'lucide-react';

interface GateManagerProps {
  gates: Gate[];
  flights: Flight[];
  onAssignGate: (
    flightId: string,
    gateId: string,
    options?: {
      requireConfirmation?: boolean;
      permissionGrantedBy?: string;
      movementReason?: string;
    }
  ) => void;
  onConfirmGateAssignment: (flightId: string) => void;
  onUpdateGateStatus: (gateId: string, status: Gate['status']) => void;
}

export const GateManager: React.FC<GateManagerProps> = ({
  gates,
  flights,
  onAssignGate,
  onConfirmGateAssignment,
  onUpdateGateStatus,
}) => {
  const [selectedTerminal, setSelectedTerminal] = useState<Terminal | 'ALL'>('ALL');
  const [reassignModalGate, setReassignModalGate] = useState<Gate | null>(null);
  const [targetFlightId, setTargetFlightId] = useState<string>('');
  const [permissionChecked, setPermissionChecked] = useState<boolean>(true);
  const [permissionAuthority, setPermissionAuthority] = useState<string>(
    'Apron Control Supervisor (Tower-01)'
  );
  const [movementReason, setMovementReason] = useState<string>(
    'Turnaround Schedule Optimization'
  );
  const [requireConfirmStep, setRequireConfirmStep] = useState<boolean>(true);
  const [conflictError, setConflictError] = useState<string | null>(null);
  const [operationBanner, setOperationBanner] = useState<string | null>(null);

  const filteredGates = gates.filter(
    (g) => selectedTerminal === 'ALL' || g.terminal === selectedTerminal
  );

  const occupiedCount = gates.filter((g) => g.status === 'OCCUPIED').length;
  const reservedCount = gates.filter((g) => g.status === 'RESERVED').length;
  const availableCount = gates.filter((g) => g.status === 'AVAILABLE').length;
  const pendingConfirmFlights = flights.filter(
    (f) => f.gateAssignmentStatus === 'PENDING_CONFIRMATION'
  );

  const selectedFlightObj = flights.find((f) => f.id === targetFlightId);
  const isGateMovement = Boolean(
    selectedFlightObj?.gateId &&
      reassignModalGate &&
      selectedFlightObj.gateId !== reassignModalGate.id
  );

  const handleReassignSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reassignModalGate || !targetFlightId || !selectedFlightObj) return;

    // 1. Check 2-Day Advance Gate Allocation Rule
    if ((selectedFlightObj.daysUntilDeparture ?? 0) > 2 && !permissionChecked) {
      setConflictError(
        `GateAdvanceWindowException: Gates are assigned 2 days (48 hours) before departure. Flight ${selectedFlightObj.flightNumber} is ${selectedFlightObj.daysUntilDeparture} days out. Enable Apron Control Permission Override to assign early.`
      );
      return;
    }

    // 2. Check if moving an already-assigned gate requires permission
    if (isGateMovement && !permissionChecked) {
      setConflictError(
        `GateMovementPermissionException: Moving Flight ${selectedFlightObj.flightNumber} from Gate ${selectedFlightObj.gateNumber} to Gate ${reassignModalGate.gateNumber} requires explicit Apron Control Permission.`
      );
      return;
    }

    // 3. Check if target gate is occupied by another flight without permission override
    if (
      reassignModalGate.status === 'OCCUPIED' &&
      reassignModalGate.currentFlightId &&
      reassignModalGate.currentFlightId !== targetFlightId &&
      !permissionChecked
    ) {
      setConflictError(
        `GateUnavailableException: Gate ${reassignModalGate.gateNumber} is currently occupied by ${
          flights.find((f) => f.id === reassignModalGate.currentFlightId)?.flightNumber ||
          'Active Aircraft'
        }. Grant Apron Movement Permission to swap/reassign.`
      );
      return;
    }

    onAssignGate(targetFlightId, reassignModalGate.id, {
      requireConfirmation: requireConfirmStep,
      permissionGrantedBy: isGateMovement ? permissionAuthority : undefined,
      movementReason: isGateMovement ? movementReason : undefined,
    });

    setOperationBanner(
      isGateMovement
        ? `Gate Movement Approved by ${permissionAuthority}: Flight ${selectedFlightObj.flightNumber} moved to Gate ${reassignModalGate.gateNumber} (${
            requireConfirmStep ? 'Awaiting Confirmation' : 'Confirmed'
          }).`
        : `Gate ${reassignModalGate.gateNumber} assigned to Flight ${selectedFlightObj.flightNumber} (2-Day T-48h Protocol · ${
            requireConfirmStep ? 'Requires Confirmation' : 'Confirmed'
          }).`
    );

    setReassignModalGate(null);
    setTargetFlightId('');
    setConflictError(null);
  };

  return (
    <div className="space-y-6">
      {/* Header Overview Banner */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 rounded-xl border border-slate-800 bg-slate-900/60 p-6">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-sky-400">
            <Radio className="h-3.5 w-3.5 animate-pulse" />
            <span>T-48h (2-Day) Gate Allocation · Mandatory Confirmation & Approved Gate Movement</span>
          </div>
          <h2 className="mt-1 text-2xl font-bold tracking-tight text-white">
            Airport Gate Allocation & Movement Control
          </h2>
          <p className="mt-1 text-xs text-slate-300 max-w-2xl">
            Gates are assigned 2 days before departure and require operator confirmation. Gate movements between terminals or stands require Apron Control permission.
          </p>
        </div>

        {/* Metrics Ticker */}
        <div className="flex items-center gap-4 bg-slate-950 p-3 rounded-lg border border-slate-800">
          <div className="text-center px-2">
            <div className="text-[10px] text-slate-400 uppercase font-medium">Available</div>
            <div className="font-mono text-lg font-bold text-emerald-400 tabular-nums">
              {availableCount}
            </div>
          </div>
          <div className="h-8 w-px bg-slate-800" />
          <div className="text-center px-2">
            <div className="text-[10px] text-slate-400 uppercase font-medium">Confirmed</div>
            <div className="font-mono text-lg font-bold text-sky-400 tabular-nums">
              {occupiedCount}
            </div>
          </div>
          <div className="h-8 w-px bg-slate-800" />
          <div className="text-center px-2">
            <div className="text-[10px] text-slate-400 uppercase font-medium">Awaiting Confirm</div>
            <div className="font-mono text-lg font-bold text-amber-400 tabular-nums">
              {pendingConfirmFlights.length || reservedCount}
            </div>
          </div>
        </div>
      </div>

      {/* Operation Feedback Banner */}
      {operationBanner && (
        <div className="flex items-center justify-between gap-3 rounded-xl border border-sky-500/40 bg-sky-950/50 p-3.5 text-xs text-sky-200">
          <div className="flex items-center gap-2">
            <ShieldCheck className="h-4 w-4 text-sky-400 shrink-0" />
            <span>{operationBanner}</span>
          </div>
          <button
            onClick={() => setOperationBanner(null)}
            className="text-sky-300 hover:text-white font-semibold"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* 2-Day Advance Gate Assignment & Confirmation Queue */}
      <div className="rounded-xl border border-slate-800 bg-slate-900/50 overflow-hidden">
        <div className="p-4 border-b border-slate-800 flex flex-wrap items-center justify-between gap-2 bg-slate-950/60">
          <div className="flex items-center gap-2">
            <CalendarClock className="h-4 w-4 text-amber-400" />
            <h3 className="text-sm font-bold text-white">
              2-Day Advance Gate Assignment & Confirmation Schedule (T-48h Rule)
            </h3>
          </div>
          <span className="text-xs text-slate-400">
            Gates assigned 2 days prior to departure require confirmation; gate changes require permission
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-950/40 text-slate-400 font-semibold">
                <th className="py-2.5 px-4">Flight</th>
                <th className="py-2.5 px-4">Route & Aircraft</th>
                <th className="py-2.5 px-4">Departure Window</th>
                <th className="py-2.5 px-4">Assigned Gate</th>
                <th className="py-2.5 px-4">Confirmation & Permission Status</th>
                <th className="py-2.5 px-4 text-right">Gate Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {flights.map((flight) => {
                const isPending = flight.gateAssignmentStatus === 'PENDING_CONFIRMATION';
                const isConfirmed = flight.gateAssignmentStatus === 'CONFIRMED';

                return (
                  <tr key={flight.id} className="hover:bg-slate-800/30 transition-colors">
                    <td className="py-3 px-4 font-mono font-bold text-sky-400">
                      {flight.flightNumber}
                    </td>
                    <td className="py-3 px-4">
                      <div className="text-slate-200 font-medium">
                        {flight.originIata} → {flight.destinationIata}
                      </div>
                      <div className="text-[11px] text-slate-400">{flight.aircraftModel}</div>
                    </td>
                    <td className="py-3 px-4 font-mono text-slate-300">
                      <div>
                        {flight.departureDate || '2026-10-08'} · {flight.scheduledDeparture}
                      </div>
                      <div className="text-[10px] text-sky-400">
                        {flight.daysUntilDeparture === 2
                          ? 'T-48h (2 Days Before Departure)'
                          : flight.daysUntilDeparture === 0
                          ? 'Day of Operation (Active)'
                          : `${flight.daysUntilDeparture} Days Prior`}
                      </div>
                    </td>
                    <td className="py-3 px-4 font-mono font-bold text-white">
                      {flight.gateNumber ? `Gate ${flight.gateNumber}` : 'Unassigned'}
                    </td>
                    <td className="py-3 px-4">
                      {isPending ? (
                        <div className="text-amber-400 font-semibold">
                          Pending Confirmation (Assigned 2 Days Prior)
                        </div>
                      ) : isConfirmed ? (
                        <div className="text-emerald-400 font-semibold flex items-center gap-1">
                          <CheckCircle2 className="h-3.5 w-3.5" />
                          <span>Confirmed Allocation</span>
                        </div>
                      ) : (
                        <span className="text-slate-400">Awaiting 2-Day Allocation</span>
                      )}
                      {flight.gatePermissionBy && (
                        <div className="text-[10px] text-slate-400 mt-0.5">
                          Moved with Permission: {flight.gatePermissionBy} ({flight.gateMovementReason})
                        </div>
                      )}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-2">
                        {isPending && (
                          <button
                            onClick={() => {
                              onConfirmGateAssignment(flight.id);
                              setOperationBanner(
                                `Confirmed Gate ${flight.gateNumber} allocation for Flight ${flight.flightNumber}.`
                              );
                            }}
                            className="rounded bg-emerald-600 px-3 py-1 text-[11px] font-bold text-white hover:bg-emerald-500 transition-colors whitespace-nowrap"
                          >
                            Confirm Gate
                          </button>
                        )}
                        <button
                          onClick={() => {
                            const currentGate =
                              gates.find((g) => g.id === flight.gateId) ||
                              gates.find((g) => g.status === 'AVAILABLE') ||
                              gates[0];
                            setReassignModalGate(currentGate);
                            setTargetFlightId(flight.id);
                            setConflictError(null);
                          }}
                          className="flex items-center gap-1 rounded border border-slate-700 bg-slate-800 px-2.5 py-1 text-[11px] font-semibold text-slate-200 hover:bg-slate-700 hover:text-white transition-colors whitespace-nowrap"
                        >
                          <ArrowRightLeft className="h-3 w-3 text-sky-400" />
                          <span>{flight.gateId ? 'Move Gate (With Permission)' : 'Assign Gate'}</span>
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Terminal Filter Controls */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-800 pb-3">
        {[
          { id: 'ALL', label: 'All Terminals' },
          { id: 'TERMINAL_A', label: 'Terminal A (Int’l Widebody)' },
          { id: 'TERMINAL_B', label: 'Terminal B (Domestic)' },
          { id: 'TERMINAL_C', label: 'Terminal C (Remote / Cargo)' },
        ].map((t) => (
          <button
            key={t.id}
            onClick={() => setSelectedTerminal(t.id as any)}
            className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition-all whitespace-nowrap ${
              selectedTerminal === t.id
                ? 'bg-sky-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Gate Grid Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
        {filteredGates.map((gate) => {
          const activeFlight = flights.find(
            (f) => f.id === gate.currentFlightId || f.gateId === gate.id
          );
          const isUnconfirmed =
            activeFlight?.gateAssignmentStatus === 'PENDING_CONFIRMATION';

          return (
            <div
              key={gate.id}
              className={`rounded-xl border p-4 transition-all flex flex-col justify-between ${
                isUnconfirmed
                  ? 'border-amber-500/50 bg-slate-900/90'
                  : gate.status === 'OCCUPIED'
                  ? 'border-sky-500/30 bg-slate-900/80'
                  : gate.status === 'AVAILABLE'
                  ? 'border-emerald-500/30 bg-slate-900/40'
                  : 'border-rose-500/30 bg-slate-900/40'
              }`}
            >
              <div>
                <div className="flex items-start justify-between">
                  <div>
                    <span className="text-[10px] font-mono text-slate-400 uppercase">
                      {gate.terminal.replace('TERMINAL_', 'T-')} ·{' '}
                      {gate.type === 'JETBRIDGE' ? 'Jetbridge' : 'Remote'}
                    </span>
                    <div className="font-mono text-2xl font-bold text-white mt-0.5">
                      Gate {gate.gateNumber}
                    </div>
                  </div>

                  <span
                    className={`font-mono text-[10px] font-bold uppercase ${
                      isUnconfirmed
                        ? 'text-amber-400'
                        : gate.status === 'AVAILABLE'
                        ? 'text-emerald-400'
                        : gate.status === 'OCCUPIED'
                        ? 'text-sky-400'
                        : 'text-rose-400'
                    }`}
                  >
                    {isUnconfirmed ? 'T-48H UNCONFIRMED' : gate.status}
                  </span>
                </div>

                {/* Assigned Aircraft / Flight Info */}
                <div className="mt-4 rounded-lg bg-slate-950/80 p-3 border border-slate-800/80 min-h-[96px]">
                  {activeFlight ? (
                    <div>
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-mono font-bold text-sky-400">
                          {activeFlight.flightNumber}
                        </span>
                        <span className="text-[10px] font-semibold text-slate-400">
                          Dep: {activeFlight.scheduledDeparture}
                        </span>
                      </div>
                      <div className="mt-1 text-xs text-slate-200 truncate">
                        {activeFlight.destinationCity} ({activeFlight.destinationIata})
                      </div>
                      <div className="mt-1 text-[10px] text-slate-400 font-mono">
                        {activeFlight.daysUntilDeparture === 2
                          ? 'Assigned 2 Days Prior'
                          : activeFlight.aircraftTail}
                      </div>
                    </div>
                  ) : (
                    <div className="flex flex-col items-center justify-center h-full text-slate-400 text-xs py-2">
                      <CheckCircle2 className="h-4 w-4 text-emerald-500/60 mb-1" />
                      <span>Ready for T-48h Assignment</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Bottom Actions */}
              <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between gap-2">
                {isUnconfirmed && activeFlight ? (
                  <button
                    onClick={() => {
                      onConfirmGateAssignment(activeFlight.id);
                      setOperationBanner(
                        `Confirmed Gate ${gate.gateNumber} for Flight ${activeFlight.flightNumber}.`
                      );
                    }}
                    className="flex-1 rounded bg-emerald-600 py-1.5 text-center text-xs font-bold text-white hover:bg-emerald-500 transition-colors"
                  >
                    Confirm Gate
                  </button>
                ) : (
                  <button
                    onClick={() => {
                      setReassignModalGate(gate);
                      setTargetFlightId(activeFlight?.id || flights[0]?.id || '');
                      setConflictError(null);
                    }}
                    className="flex-1 rounded bg-slate-800 py-1.5 text-center text-xs font-semibold text-slate-300 hover:bg-slate-700 hover:text-white transition-colors"
                  >
                    {activeFlight ? 'Move / Reassign' : 'Assign Flight'}
                  </button>
                )}

                <button
                  onClick={() => {
                    const nextStatus: Gate['status'] =
                      gate.status === 'MAINTENANCE' ? 'AVAILABLE' : 'MAINTENANCE';
                    onUpdateGateStatus(gate.id, nextStatus);
                  }}
                  title="Toggle Maintenance Inspection"
                  aria-label={`Toggle Maintenance for Gate ${gate.gateNumber}`}
                  className="rounded p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white"
                >
                  <Wrench className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Gate Assignment (2 Days Prior) & Permission Movement Modal */}
      {reassignModalGate && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4">
          <div className="w-full max-w-lg rounded-xl border border-slate-800 bg-slate-900 p-6 shadow-2xl">
            <h3 className="text-lg font-bold text-white">
              Gate Allocation & Approved Movement Console
            </h3>
            <p className="mt-1 text-xs text-slate-400">
              Enforces 2-day (T-48h) advance gate assignment, confirmation workflow, and Apron Control permission for gate movements.
            </p>

            {conflictError && (
              <div className="mt-3 flex items-start gap-2 rounded-lg bg-rose-950/80 p-3 text-xs text-rose-300 border border-rose-500/40">
                <AlertCircle className="h-4 w-4 shrink-0 text-rose-400 mt-0.5" />
                <div>{conflictError}</div>
              </div>
            )}

            <form onSubmit={handleReassignSubmit} className="mt-4 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-medium text-slate-300">
                    Select Flight:
                  </label>
                  <select
                    required
                    value={targetFlightId}
                    onChange={(e) => {
                      setTargetFlightId(e.target.value);
                      setConflictError(null);
                    }}
                    className="mt-1 w-full rounded border border-slate-700 bg-slate-950 px-3 py-2 text-xs text-white focus:border-sky-500 focus:outline-none"
                  >
                    <option value="">-- Choose flight --</option>
                    {flights.map((f) => (
                      <option key={f.id} value={f.id}>
                        {f.flightNumber} ({f.originIata}→{f.destinationIata}) ·{' '}
                        {f.gateNumber ? `Cur: Gate ${f.gateNumber}` : 'Unassigned'} [T-{f.daysUntilDeparture ?? 2}d]
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-xs font-medium text-slate-300">
                    Target Gate:
                  </label>
                  <select
                    value={reassignModalGate.id}
                    onChange={(e) => {
                      const g = gates.find((item) => item.id === e.target.value);
                      if (g) setReassignModalGate(g);
                      setConflictError(null);
                    }}
                    className="mt-1 w-full rounded border border-slate-700 bg-slate-950 px-3 py-2 text-xs text-white focus:border-sky-500 focus:outline-none"
                  >
                    {gates.map((g) => (
                      <option key={g.id} value={g.id}>
                        Gate {g.gateNumber} ({g.terminal.replace('TERMINAL_', 'T-')}) - {g.status}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Gate Movement Permission Section */}
              <div className="rounded-lg border border-slate-800 bg-slate-950 p-3.5 space-y-3 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-sky-400">
                    Apron Control Gate Movement Permission
                  </span>
                  <span className="text-[11px] text-slate-400">
                    {isGateMovement
                      ? `Moving from Gate ${selectedFlightObj?.gateNumber} → Gate ${reassignModalGate.gateNumber}`
                      : 'Initial T-48h Gate Assignment'}
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] text-slate-400 block mb-1">
                      Approving Authority:
                    </label>
                    <select
                      value={permissionAuthority}
                      onChange={(e) => setPermissionAuthority(e.target.value)}
                      className="w-full rounded border border-slate-700 bg-slate-900 px-2.5 py-1.5 text-xs text-white"
                    >
                      <option value="Apron Control Supervisor (Tower-01)">
                        Apron Control Supervisor (Tower-01)
                      </option>
                      <option value="Terminal Duty Manager (AOCC)">
                        Terminal Duty Manager (AOCC)
                      </option>
                      <option value="ATC Surface Movement Director">
                        ATC Surface Movement Director
                      </option>
                    </select>
                  </div>

                  <div>
                    <label className="text-[11px] text-slate-400 block mb-1">
                      Movement / Allocation Reason:
                    </label>
                    <input
                      type="text"
                      value={movementReason}
                      onChange={(e) => setMovementReason(e.target.value)}
                      className="w-full rounded border border-slate-700 bg-slate-900 px-2.5 py-1.5 text-xs text-white"
                    />
                  </div>
                </div>

                <label className="flex items-center gap-2 cursor-pointer pt-1">
                  <input
                    type="checkbox"
                    checked={permissionChecked}
                    onChange={(e) => setPermissionChecked(e.target.checked)}
                    className="rounded border-slate-700 bg-slate-900 text-sky-500"
                  />
                  <span className="text-slate-200 font-medium">
                    Permission granted by {permissionAuthority} for gate movement / T-48h allocation
                  </span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={requireConfirmStep}
                    onChange={(e) => setRequireConfirmStep(e.target.checked)}
                    className="rounded border-slate-700 bg-slate-900 text-sky-500"
                  />
                  <span className="text-slate-300">
                    Place in T-48h Pending Confirmation state (requires final operator confirmation)
                  </span>
                </label>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setReassignModalGate(null)}
                  className="rounded px-3 py-1.5 text-xs text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded bg-sky-600 px-4 py-1.5 text-xs font-semibold text-white hover:bg-sky-500 transition-colors"
                >
                  {isGateMovement ? 'Approve & Execute Gate Move' : 'Assign Gate (2-Day Rule)'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
