import React, { useState } from 'react';
import {
  Baggage,
  BaggageStatus,
  Flight,
  FlightBaggageManifest,
} from '../types/aeroflow';
import {
  Luggage,
  Search,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  Plus,
  Scan,
  PackageCheck,
  Boxes,
} from 'lucide-react';

interface BaggageTrackerProps {
  baggageList: Baggage[];
  baggageManifests: FlightBaggageManifest[];
  flights: Flight[];
  onUpdateBaggageStatus: (baggageId: string, status: BaggageStatus) => void;
  onAddNewBaggage: (newBaggage: Baggage) => void;
  onAdvanceBulkManifest: (
    flightId: string,
    action: 'OFFLOAD_ULD' | 'CLAIM_BATCH' | 'LOAD_HOLD' | 'ADD_BULK_100'
  ) => void;
}

export const BaggageTracker: React.FC<BaggageTrackerProps> = ({
  baggageList,
  baggageManifests,
  flights,
  onUpdateBaggageStatus,
  onAddNewBaggage,
  onAdvanceBulkManifest,
}) => {
  const [searchTag, setSearchTag] = useState('');
  const [manifestFilter, setManifestFilter] = useState<'ALL' | 'LANDED' | 'OUTBOUND'>('ALL');
  const [isRegisterModalOpen, setIsRegisterModalOpen] = useState(false);
  const [newPassengerName, setNewPassengerName] = useState('Dr. Evelyn Reed');
  const [newFlightId, setNewFlightId] = useState(flights[0]?.id || '');
  const [newWeightKg, setNewWeightKg] = useState(21.5);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const statuses: { id: BaggageStatus; label: string }[] = [
    { id: 'CHECKED_IN', label: '1. Check-In' },
    { id: 'SECURITY_CLEARED', label: '2. TSA Cleared' },
    { id: 'RAMP_SORT', label: '3. Ramp Sort' },
    { id: 'LOADED', label: '4. Loaded Hold' },
    { id: 'IN_TRANSIT', label: '5. In Flight' },
    { id: 'CAROUSEL_UNLOADED', label: '6. Carousel Ready' },
    { id: 'CLAIMED', label: '7. Claimed' },
  ];

  const filteredManifests = baggageManifests.filter((m) => {
    const matchesSearch =
      m.flightNumber.toLowerCase().includes(searchTag.toLowerCase()) ||
      m.route.toLowerCase().includes(searchTag.toLowerCase()) ||
      m.aircraftModel.toLowerCase().includes(searchTag.toLowerCase()) ||
      m.carouselNumber.toLowerCase().includes(searchTag.toLowerCase());

    const matchesType =
      manifestFilter === 'ALL' ||
      (manifestFilter === 'LANDED' && m.flightStatus === 'LANDED') ||
      (manifestFilter === 'OUTBOUND' && m.flightStatus !== 'LANDED');

    return matchesSearch && matchesType;
  });

  const filteredBaggage = baggageList.filter(
    (b) =>
      b.tagNumber.toLowerCase().includes(searchTag.toLowerCase()) ||
      b.passengerName.toLowerCase().includes(searchTag.toLowerCase()) ||
      b.flightNumber.toLowerCase().includes(searchTag.toLowerCase())
  );

  // Aggregate High-Volume Totals
  const totalSystemBags = baggageManifests.reduce((sum, m) => sum + m.totalBags, 0);
  const totalSystemWeightKg = baggageManifests.reduce(
    (sum, m) => sum + m.totalWeightKg,
    0
  );
  const totalUldContainers = baggageManifests.reduce(
    (sum, m) => sum + m.uldContainersCount,
    0
  );
  const landedBagsTotal = baggageManifests
    .filter((m) => m.flightStatus === 'LANDED')
    .reduce((sum, m) => sum + m.totalBags, 0);

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (newWeightKg > 32.0) {
      setErrorMessage(
        `OverweightBaggageException: Bag weight ${newWeightKg}kg exceeds maximum single-piece IATA safety limit of 32.0kg! Must be repacked.`
      );
      return;
    }

    const assignedFlight = flights.find((f) => f.id === newFlightId) || flights[0];

    const newBag: Baggage = {
      id: `bag-${Date.now()}`,
      tagNumber: `BAG-${Math.floor(1000 + Math.random() * 9000)}-${Math.floor(
        10 + Math.random() * 90
      )}`,
      ticketId: `tkt-${Date.now()}`,
      flightId: assignedFlight.id,
      flightNumber: assignedFlight.flightNumber,
      passengerName: newPassengerName,
      weightKg: Number(newWeightKg),
      status: 'CHECKED_IN',
      isOverweight: newWeightKg > 23.0,
      carouselNumber: 'T1-Carousel 2',
      lastUpdated: new Date().toLocaleTimeString([], {
        hour: '2-digit',
        minute: '2-digit',
      }),
    };

    onAddNewBaggage(newBag);
    setIsRegisterModalOpen(false);
    setErrorMessage(null);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 rounded-xl border border-slate-800 bg-slate-900/60 p-6">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-sky-400">
            <Boxes className="h-3.5 w-3.5" />
            <span>High-Volume Bulk Flight Manifests (100–500+ Bags per Flight) & ULD Telemetry</span>
          </div>
          <h2 className="mt-1 text-2xl font-bold tracking-tight text-white">
            Bulk Baggage Operations & Carousel Reconciliation
          </h2>
          <p className="mt-1 text-xs text-slate-300 max-w-2xl">
            Models realistic wide-body and narrow-body baggage volumes (180–500+ bags per flight) using aluminum ULD containers, conveyor batch offloading, and exception RFID tracking.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsRegisterModalOpen(true)}
            className="flex items-center gap-2 rounded-lg bg-sky-600 px-4 py-2 text-xs font-semibold text-white hover:bg-sky-500 shadow-sm transition-colors whitespace-nowrap"
          >
            <Plus className="h-4 w-4" />
            <span>Log Priority / Exception Bag</span>
          </button>
        </div>
      </div>

      {/* Aggregate Bulk Volume Metrics */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-4">
          <div className="text-xs text-slate-400">Total Active & Landed Bags</div>
          <div className="mt-1 font-mono text-2xl font-bold text-white tabular-nums">
            {totalSystemBags.toLocaleString()} Bags
          </div>
          <div className="mt-0.5 text-[11px] text-sky-400">
            184–486 bags per commercial flight
          </div>
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-4">
          <div className="text-xs text-slate-400">Landed Flights Bag Volume</div>
          <div className="mt-1 font-mono text-2xl font-bold text-emerald-400 tabular-nums">
            {landedBagsTotal.toLocaleString()} Bags
          </div>
          <div className="mt-0.5 text-[11px] text-slate-400">
            AF-332 (448 bags) · AF-118 (392 bags)
          </div>
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-4">
          <div className="text-xs text-slate-400">Active ULD Containers</div>
          <div className="mt-1 font-mono text-2xl font-bold text-amber-400 tabular-nums">
            {totalUldContainers} ULDs
          </div>
          <div className="mt-0.5 text-[11px] text-slate-400">
            AKE / AKH Wide-Body Cargo Containers
          </div>
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-4">
          <div className="text-xs text-slate-400">Aggregate Baggage Mass</div>
          <div className="mt-1 font-mono text-2xl font-bold text-slate-200 tabular-nums">
            {(totalSystemWeightKg / 1000).toFixed(1)} Tons
          </div>
          <div className="mt-0.5 text-[11px] text-slate-400">
            {totalSystemWeightKg.toLocaleString()} kg total load
          </div>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
          <input
            type="text"
            aria-label="Search flight manifests or RFID tags"
            placeholder="Filter by flight (e.g. AF-332, AF-118, AF-880), carousel, or RFID tag..."
            value={searchTag}
            onChange={(e) => setSearchTag(e.target.value)}
            className="w-full rounded-lg border border-slate-700 bg-slate-950 pl-9 pr-4 py-2 text-xs text-slate-100 placeholder:text-slate-500 focus:border-sky-500 focus:outline-none"
          />
        </div>

        <div className="flex items-center gap-1 rounded-lg bg-slate-900 p-1 border border-slate-800">
          {[
            { id: 'ALL', label: 'All Flight Manifests' },
            { id: 'LANDED', label: 'Landed Flights (100–500+ Bags)' },
            { id: 'OUTBOUND', label: 'Outbound Loading' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setManifestFilter(tab.id as any)}
              className={`rounded-md px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap ${
                manifestFilter === tab.id
                  ? 'bg-sky-600 text-white'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* High-Volume Flight Baggage Manifest Cards (100-500+ Bags per Flight) */}
      <div className="space-y-4">
        <h3 className="text-sm font-bold text-white">
          Flight-Level Bulk Baggage Manifests (100–500+ Bags per Aircraft)
        </h3>

        <div className="grid grid-cols-1 gap-4">
          {filteredManifests.map((manifest) => {
            const isLanded = manifest.flightStatus === 'LANDED';
            const sb = manifest.stageBreakdown;
            const unloadedOrClaimed = sb.carouselUnloaded + sb.claimed;
            const offloadPercent =
              manifest.totalBags > 0
                ? Math.round((unloadedOrClaimed / manifest.totalBags) * 100)
                : 0;
            const loadedPercent =
              manifest.totalBags > 0
                ? Math.round((sb.loadedHold / manifest.totalBags) * 100)
                : 0;

            return (
              <div
                key={manifest.flightId}
                className={`rounded-xl border p-5 space-y-4 ${
                  isLanded
                    ? 'border-emerald-500/40 bg-slate-900/80'
                    : 'border-slate-800 bg-slate-900/60'
                }`}
              >
                <div className="flex flex-wrap items-center justify-between gap-4">
                  <div>
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-mono text-lg font-bold text-sky-400">
                        {manifest.flightNumber}
                      </span>
                      <span className="text-sm font-semibold text-white">
                        {manifest.route}
                      </span>
                      <span
                        className={`font-mono text-xs font-bold uppercase ${
                          isLanded ? 'text-emerald-400' : 'text-amber-400'
                        }`}
                      >
                        · {manifest.flightStatus}
                      </span>
                    </div>
                    <div className="mt-1 text-xs text-slate-400 flex flex-wrap items-center gap-2">
                      <span>{manifest.aircraftModel}</span>
                      <span aria-hidden="true">·</span>
                      <span>
                        Assigned Zone: <strong className="text-slate-200">{manifest.carouselNumber}</strong>
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>
                        ULD Containers:{' '}
                        <strong className="font-mono text-slate-200">
                          {manifest.uldContainersCount > 0
                            ? `${manifest.uldContainersCount} Aluminum ULDs`
                            : 'Bulk Belly Hold'}
                        </strong>
                      </span>
                    </div>
                  </div>

                  {/* Total Bag Count & Weight Callout */}
                  <div className="flex items-center gap-4 bg-slate-950 px-4 py-2.5 rounded-lg border border-slate-800">
                    <div>
                      <div className="text-[10px] text-slate-400 uppercase">Total Flight Bags</div>
                      <div className="font-mono text-xl font-bold text-white tabular-nums">
                        {manifest.totalBags} Bags
                      </div>
                    </div>
                    <div className="h-8 w-px bg-slate-800" />
                    <div>
                      <div className="text-[10px] text-slate-400 uppercase">Total Cargo Weight</div>
                      <div className="font-mono text-base font-bold text-sky-400 tabular-nums">
                        {manifest.totalWeightKg.toLocaleString()} kg
                      </div>
                    </div>
                  </div>
                </div>

                {/* Stage Breakdown Grid for the 100-500+ Bags */}
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5 text-xs">
                  <div className="rounded-lg bg-slate-950/80 p-2.5 border border-slate-800">
                    <div className="text-[10px] text-slate-400">1. Checked In</div>
                    <div className="font-mono text-sm font-bold text-slate-200 mt-0.5 tabular-nums">
                      {sb.checkedIn} bags
                    </div>
                  </div>
                  <div className="rounded-lg bg-slate-950/80 p-2.5 border border-slate-800">
                    <div className="text-[10px] text-slate-400">2. TSA Cleared</div>
                    <div className="font-mono text-sm font-bold text-slate-200 mt-0.5 tabular-nums">
                      {sb.securityCleared} bags
                    </div>
                  </div>
                  <div className="rounded-lg bg-slate-950/80 p-2.5 border border-slate-800">
                    <div className="text-[10px] text-slate-400">3. Ramp Sort / ULD</div>
                    <div className="font-mono text-sm font-bold text-amber-400 mt-0.5 tabular-nums">
                      {sb.rampSort} bags
                    </div>
                  </div>
                  <div className="rounded-lg bg-slate-950/80 p-2.5 border border-slate-800">
                    <div className="text-[10px] text-slate-400">4. Aircraft Hold</div>
                    <div className="font-mono text-sm font-bold text-sky-400 mt-0.5 tabular-nums">
                      {sb.loadedHold} bags
                    </div>
                  </div>
                  <div className="rounded-lg bg-slate-950/80 p-2.5 border border-slate-800">
                    <div className="text-[10px] text-slate-400">5. Carousel Unloaded</div>
                    <div className="font-mono text-sm font-bold text-emerald-400 mt-0.5 tabular-nums">
                      {sb.carouselUnloaded} bags
                    </div>
                  </div>
                  <div className="rounded-lg bg-slate-950/80 p-2.5 border border-slate-800">
                    <div className="text-[10px] text-slate-400">6. Passenger Claimed</div>
                    <div className="font-mono text-sm font-bold text-emerald-300 mt-0.5 tabular-nums">
                      {sb.claimed} bags
                    </div>
                  </div>
                </div>

                {/* Progress Bar & Bulk Action Buttons */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2 border-t border-slate-800/80 text-xs">
                  <div className="flex-1 space-y-1">
                    <div className="flex items-center justify-between text-[11px] text-slate-300">
                      <span>
                        {isLanded
                          ? `Landed Offload & Carousel Claim Progress (${unloadedOrClaimed}/${manifest.totalBags} bags)`
                          : `Outbound Aircraft Hold Loading Progress (${sb.loadedHold}/${manifest.totalBags} bags)`}
                      </span>
                      <span className="font-mono font-bold">
                        {isLanded ? `${offloadPercent}%` : `${loadedPercent}%`}
                      </span>
                    </div>
                    <div className="h-2 w-full rounded-full bg-slate-800 overflow-hidden">
                      <div
                        className={`h-full transition-all ${
                          isLanded ? 'bg-emerald-500' : 'bg-sky-500'
                        }`}
                        style={{
                          width: `${isLanded ? offloadPercent : loadedPercent}%`,
                        }}
                      />
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-2">
                    {isLanded ? (
                      <>
                        <button
                          onClick={() =>
                            onAdvanceBulkManifest(manifest.flightId, 'OFFLOAD_ULD')
                          }
                          className="rounded-lg bg-emerald-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-emerald-500 transition-colors whitespace-nowrap"
                        >
                          Offload ULD Batch (+36 Bags)
                        </button>
                        <button
                          onClick={() =>
                            onAdvanceBulkManifest(manifest.flightId, 'CLAIM_BATCH')
                          }
                          className="rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 px-3 py-1.5 text-xs font-semibold text-slate-200 transition-colors whitespace-nowrap"
                        >
                          Process Passenger Claims (+50 Bags)
                        </button>
                      </>
                    ) : (
                      <button
                        onClick={() =>
                          onAdvanceBulkManifest(manifest.flightId, 'LOAD_HOLD')
                        }
                        className="rounded-lg bg-sky-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-sky-500 transition-colors whitespace-nowrap"
                      >
                        Load ULD Batch into Hold (+50 Bags)
                      </button>
                    )}

                    <button
                      onClick={() =>
                        onAdvanceBulkManifest(manifest.flightId, 'ADD_BULK_100')
                      }
                      className="rounded-lg border border-sky-500/40 bg-sky-950/50 hover:bg-sky-900/70 px-3 py-1.5 text-xs font-semibold text-sky-300 transition-colors whitespace-nowrap"
                    >
                      +100 Bulk Bags
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Individual VIP / Exception RFID Tags Inspector */}
      <div className="space-y-3 pt-4 border-t border-slate-800">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Scan className="h-4 w-4 text-sky-400" />
              <span>Flagged Exception & Priority VIP RFID Tag Inspector</span>
            </h3>
            <p className="text-xs text-slate-400">
              Individual telemetry drill-down for overweight (&gt;23kg), VIP First Class, or transfer-critical bags sampled from the bulk flight manifests.
            </p>
          </div>
        </div>

        <div className="space-y-3">
          {filteredBaggage.map((bag) => {
            const currentStatusIndex = statuses.findIndex((s) => s.id === bag.status);

            return (
              <div
                key={bag.id}
                className="rounded-xl border border-slate-800 bg-slate-900/70 p-4 shadow-sm space-y-3"
              >
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="rounded-lg bg-slate-800 p-2 text-sky-400 border border-slate-700">
                      <Luggage className="h-4 w-4" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-sm font-bold text-white">
                          {bag.tagNumber}
                        </span>
                        {bag.isOverweight && (
                          <span className="flex items-center gap-1 font-mono text-xs font-bold text-amber-400">
                            <AlertTriangle className="h-3.5 w-3.5" />
                            <span>Heavy Exception ({bag.weightKg} kg)</span>
                          </span>
                        )}
                      </div>
                      <div className="text-xs text-slate-400">
                        Passenger: <span className="text-slate-200 font-medium">{bag.passengerName}</span> · Flight:{' '}
                        <span className="font-mono text-sky-400 font-semibold">{bag.flightNumber}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="text-right text-xs">
                      <span className="text-slate-400">Carousel: </span>
                      <span className="font-mono font-bold text-white">
                        {bag.carouselNumber || 'Unassigned'}
                      </span>
                    </div>

                    {currentStatusIndex < statuses.length - 1 ? (
                      <button
                        onClick={() =>
                          onUpdateBaggageStatus(bag.id, statuses[currentStatusIndex + 1].id)
                        }
                        className="flex items-center gap-1.5 rounded-lg bg-slate-800 px-3 py-1.5 text-xs font-semibold text-slate-200 hover:bg-slate-700 hover:text-white border border-slate-700 transition-colors whitespace-nowrap"
                      >
                        <span>Advance Stage</span>
                        <ArrowRight className="h-3.5 w-3.5 text-sky-400" />
                      </button>
                    ) : (
                      <span className="flex items-center gap-1 text-xs font-semibold text-emerald-400">
                        <CheckCircle2 className="h-4 w-4" />
                        <span>Claimed</span>
                      </span>
                    )}
                  </div>
                </div>

                {/* Visual Pipeline Progression */}
                <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-1.5">
                  {statuses.map((step, idx) => {
                    const isDone = idx <= currentStatusIndex;
                    const isCurrent = idx === currentStatusIndex;

                    return (
                      <button
                        key={step.id}
                        type="button"
                        onClick={() => onUpdateBaggageStatus(bag.id, step.id)}
                        className={`rounded-lg p-2 text-center transition-all border ${
                          isCurrent
                            ? 'bg-sky-600/20 border-sky-500 text-sky-300'
                            : isDone
                            ? 'bg-slate-950 border-emerald-500/30 text-emerald-400'
                            : 'bg-slate-950/40 border-slate-800 text-slate-400 hover:border-slate-700'
                        }`}
                      >
                        <div className="text-[10px] font-mono uppercase tracking-wider font-semibold truncate">
                          {step.label}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Baggage Registration Modal */}
      {isRegisterModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          <div className="w-full max-w-md rounded-xl border border-slate-800 bg-slate-900 p-6 shadow-2xl">
            <h3 className="text-lg font-bold text-white">
              Log Priority / Exception Baggage Tag
            </h3>
            <p className="mt-1 text-xs text-slate-400">
              Generates IATA RFID 10-digit barcode, validates weight thresholds, and increments the flight’s bulk manifest.
            </p>

            {errorMessage && (
              <div className="mt-3 flex items-start gap-2 rounded-lg bg-rose-950/80 p-3 text-xs text-rose-300 border border-rose-500/40">
                <AlertTriangle className="h-4 w-4 shrink-0 text-rose-400 mt-0.5" />
                <div>{errorMessage}</div>
              </div>
            )}

            <form onSubmit={handleRegisterSubmit} className="mt-4 space-y-4">
              <div>
                <label className="text-xs font-medium text-slate-300">Passenger Name:</label>
                <input
                  type="text"
                  required
                  value={newPassengerName}
                  onChange={(e) => setNewPassengerName(e.target.value)}
                  className="mt-1 w-full rounded border border-slate-700 bg-slate-950 px-3 py-1.5 text-xs text-white focus:border-sky-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="text-xs font-medium text-slate-300">Flight Route:</label>
                <select
                  value={newFlightId}
                  onChange={(e) => setNewFlightId(e.target.value)}
                  className="mt-1 w-full rounded border border-slate-700 bg-slate-950 px-3 py-1.5 text-xs text-white focus:border-sky-500 focus:outline-none"
                >
                  {flights.map((f) => (
                    <option key={f.id} value={f.id}>
                      {f.flightNumber} ({f.originIata} → {f.destinationIata})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-xs font-medium text-slate-300">
                  Scale Weight (kg):
                </label>
                <input
                  type="number"
                  step="0.1"
                  required
                  value={newWeightKg}
                  onChange={(e) => setNewWeightKg(Number(e.target.value))}
                  className="mt-1 w-full rounded border border-slate-700 bg-slate-950 px-3 py-1.5 text-xs font-mono text-white focus:border-sky-500 focus:outline-none"
                />
                <span className="text-[10px] text-slate-400 mt-1 block">
                  Standard limit: 23.0kg · Heavy surcharge: &gt;23kg · Max safety cutoff: 32.0kg
                </span>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => {
                    setIsRegisterModalOpen(false);
                    setErrorMessage(null);
                  }}
                  className="rounded px-3 py-1.5 text-xs text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded bg-sky-600 px-4 py-1.5 text-xs font-semibold text-white hover:bg-sky-500 transition-colors"
                >
                  Print Tag & Register
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
