import React, { useState, useEffect } from 'react';
import { Flight, Ticket, Passenger } from '../types/aeroflow';
import {
  Users,
  Play,
  RotateCcw,
  CheckCircle2,
  Clock,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  PlaneTakeoff,
  Award,
} from 'lucide-react';

interface BoardingQueueSimulatorProps {
  flight: Flight;
  tickets: Ticket[];
  passengers: Passenger[];
  onBoardPassenger: (ticketId: string) => void;
  onResetBoarding: (flightId: string) => void;
}

interface QueuedItem {
  ticket: Ticket;
  passenger: Passenger;
  priorityScore: number;
  groupName: string;
}

export const BoardingQueueSimulator: React.FC<BoardingQueueSimulatorProps> = ({
  flight,
  tickets,
  passengers,
  onBoardPassenger,
  onResetBoarding,
}) => {
  const [isAutoPlaying, setIsAutoPlaying] = useState(false);
  const [recentBoarded, setRecentBoarded] = useState<QueuedItem | null>(null);

  // Build the PriorityQueue structure
  const flightTickets = tickets.filter((t) => t.flightId === flight.id);

  // Score function for PriorityQueue Comparator:
  // Comparator<QueuedItem> = (a, b) -> b.priorityScore - a.priorityScore
  const calculatePriorityScore = (t: Ticket, p: Passenger): { score: number; group: string } => {
    if (p.specialAssistance) {
      return { score: 100, group: 'Group 0: Special Assistance' };
    }
    if (t.travelClass === 'FIRST' || p.frequentFlyerTier === 'PLATINUM') {
      return { score: 90, group: 'Group 1: First Class & Platinum' };
    }
    if (t.travelClass === 'BUSINESS' || p.frequentFlyerTier === 'GOLD') {
      return { score: 80, group: 'Group 2: Business & Gold' };
    }
    if (p.frequentFlyerTier === 'SILVER') {
      return { score: 60, group: 'Group 3: Silver Tier' };
    }
    return { score: 30, group: 'Group 4: General Economy' };
  };

  const queueItems: QueuedItem[] = flightTickets
    .map((t) => {
      const p = passengers.find((item) => item.id === t.passengerId) || {
        id: t.passengerId,
        fullName: t.passengerName,
        email: '',
        phone: '',
        nationality: '',
        type: 'PASSENGER' as const,
        passportNumber: 'US-999',
        frequentFlyerTier: 'BRONZE' as const,
        specialAssistance: false,
        fastTrack: false,
        accumulatedMiles: 0,
      };
      const { score, group } = calculatePriorityScore(t, p);
      return { ticket: t, passenger: p, priorityScore: score, groupName: group };
    })
    .sort((a, b) => b.priorityScore - a.priorityScore); // PriorityQueue comparator order

  const waitingQueue = queueItems.filter((item) => item.ticket.status !== 'BOARDED');
  const boardedList = queueItems.filter((item) => item.ticket.status === 'BOARDED');

  const boardNext = () => {
    if (waitingQueue.length === 0) {
      setIsAutoPlaying(false);
      return;
    }
    const next = waitingQueue[0];
    onBoardPassenger(next.ticket.id);
    setRecentBoarded(next);
  };

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isAutoPlaying && waitingQueue.length > 0) {
      timer = setTimeout(() => {
        boardNext();
      }, 700);
    } else if (waitingQueue.length === 0) {
      setIsAutoPlaying(false);
    }
    return () => clearTimeout(timer);
  }, [isAutoPlaying, waitingQueue]);

  const boardedPercent =
    flightTickets.length > 0
      ? Math.round((boardedList.length / flightTickets.length) * 100)
      : 0;

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 rounded-xl border border-slate-800 bg-slate-900/60 p-6">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-sky-400">
            <Users className="h-3.5 w-3.5" />
            <span>Java Collections: java.util.PriorityQueue & Queue Simulator</span>
          </div>
          <h2 className="mt-1 text-2xl font-bold tracking-tight text-white">
            Flight Boarding Queue: {flight.flightNumber}
          </h2>
          <p className="mt-1 text-xs text-slate-300">
            {flight.originCity} ({flight.originIata}) → {flight.destinationCity} ({flight.destinationIata}) · Gate {flight.gateNumber || 'A1'}
          </p>
        </div>

        {/* Boarding Controls */}
        <div className="flex items-center gap-2">
          <button
            disabled={waitingQueue.length === 0}
            onClick={boardNext}
            className="flex items-center gap-1.5 rounded-lg bg-sky-600 px-3.5 py-2 text-xs font-semibold text-white shadow-sm hover:bg-sky-500 disabled:opacity-40 transition-colors"
          >
            <ArrowRight className="h-4 w-4" />
            <span>Poll Next Passenger</span>
          </button>

          <button
            disabled={waitingQueue.length === 0}
            onClick={() => setIsAutoPlaying(!isAutoPlaying)}
            className={`flex items-center gap-1.5 rounded-lg px-3.5 py-2 text-xs font-semibold shadow-sm transition-colors ${
              isAutoPlaying
                ? 'bg-amber-600 text-white hover:bg-amber-500'
                : 'bg-emerald-600 text-white hover:bg-emerald-500 disabled:opacity-40'
            }`}
          >
            <Play className="h-4 w-4" />
            <span>{isAutoPlaying ? 'Pause Queue' : 'Auto Board Stream'}</span>
          </button>

          <button
            onClick={() => onResetBoarding(flight.id)}
            title="Reset Boarding Status"
            className="rounded-lg border border-slate-700 bg-slate-800 p-2 text-slate-300 hover:text-white"
          >
            <RotateCcw className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* Progress & Live Boarding Announcement Banner */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Progress Card */}
        <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-4">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span>Boarding Completion</span>
            <span className="font-mono font-bold text-white tabular-nums">
              {boardedList.length} / {flightTickets.length} ({boardedPercent}%)
            </span>
          </div>
          <div className="h-2 w-full rounded-full bg-slate-800 overflow-hidden">
            <div
              className="h-full bg-emerald-400 transition-all duration-300"
              style={{ width: `${boardedPercent}%` }}
            />
          </div>
        </div>

        {/* Priority Logic Note */}
        <div className="md:col-span-2 rounded-xl border border-sky-500/20 bg-sky-950/20 p-4 text-xs text-sky-200 flex items-center justify-between">
          <div className="space-y-0.5">
            <div className="font-semibold text-sky-300 flex items-center gap-1.5">
              <Sparkles className="h-3.5 w-3.5" />
              <span>PriorityQueue Comparator Strategy:</span>
            </div>
            <p className="text-[11px] text-slate-400">
              Special Assistance (Score 100) &gt; First & Platinum (Score 90) &gt; Business & Gold (Score 80) &gt; General Economy (Score 30).
            </p>
          </div>
          {recentBoarded && (
            <div className="hidden sm:block text-right">
              <div className="text-[10px] text-slate-400 uppercase font-mono">Just Scanned:</div>
              <div className="font-bold text-emerald-400 font-mono text-sm">
                Seat {recentBoarded.ticket.seatNumber} ({recentBoarded.passenger.fullName})
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Two Queue Containers: Waiting in PriorityQueue vs Successfully Boarded */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left: Priority Waiting Queue (PriorityQueue.poll()) */}
        <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-5 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Clock className="h-4 w-4 text-amber-400" />
              <h3 className="font-bold text-white text-sm">
                Waiting Priority Queue ({waitingQueue.length} Pending)
              </h3>
            </div>
            <span className="font-mono text-xs text-slate-400">
              FIFO with Heap Priority
            </span>
          </div>

          <div className="space-y-2 max-h-[460px] overflow-y-auto pr-1">
            {waitingQueue.length === 0 ? (
              <div className="flex flex-col items-center justify-center p-8 text-slate-400 text-xs text-center border border-dashed border-slate-800 rounded-lg">
                <CheckCircle2 className="h-6 w-6 text-emerald-400 mb-1" />
                <span>All passengers boarded. Flight gate cleared for departure!</span>
              </div>
            ) : (
              waitingQueue.map((item, index) => (
                <div
                  key={item.ticket.id}
                  className={`flex items-center justify-between rounded-lg p-3 border transition-all ${
                    index === 0
                      ? 'border-sky-500/50 bg-sky-950/30 ring-1 ring-sky-500/30'
                      : 'border-slate-800 bg-slate-950/60'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className="flex h-6 w-6 items-center justify-center rounded-full bg-slate-800 font-mono text-xs font-bold text-slate-300">
                      {index + 1}
                    </span>
                    <div>
                      <div className="font-semibold text-slate-200 text-xs">
                        {item.passenger.fullName}
                      </div>
                      <div className="text-[10px] text-slate-400">
                        {item.groupName} · Priority Score: <span className="font-mono text-sky-400">{item.priorityScore}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <div className="text-right">
                      <span className="font-mono font-bold text-amber-400 text-xs">
                        Seat {item.ticket.seatNumber}
                      </span>
                      <div className="text-[10px] text-slate-400 font-mono">
                        {item.ticket.travelClass}
                      </div>
                    </div>

                    <button
                      onClick={() => onBoardPassenger(item.ticket.id)}
                      className="rounded bg-slate-800 px-2.5 py-1 text-[11px] font-semibold text-slate-200 hover:bg-emerald-600 hover:text-white transition-colors"
                    >
                      Scan
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Right: Boarded Passenger Cabin Roster */}
        <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-5 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-emerald-400" />
              <h3 className="font-bold text-white text-sm">
                Seated Cabin Manifest ({boardedList.length} Boarded)
              </h3>
            </div>
            <span className="font-mono text-xs text-emerald-400">
              Verified Onboard
            </span>
          </div>

          <div className="space-y-2 max-h-[460px] overflow-y-auto pr-1">
            {boardedList.length === 0 ? (
              <div className="flex flex-col items-center justify-center p-8 text-slate-400 text-xs text-center border border-dashed border-slate-800 rounded-lg">
                <Users className="h-6 w-6 text-slate-400 mb-1" />
                <span>Boarding gate waiting to call first passenger group.</span>
              </div>
            ) : (
              boardedList.map((item) => (
                <div
                  key={item.ticket.id}
                  className="flex items-center justify-between rounded-lg p-2.5 border border-emerald-500/20 bg-slate-950/70"
                >
                  <div className="flex items-center gap-2.5">
                    <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                    <div>
                      <div className="font-semibold text-slate-200 text-xs">
                        {item.passenger.fullName}
                      </div>
                      <div className="text-[10px] text-slate-400">
                        {item.passenger.frequentFlyerTier} Tier · PNR: {item.ticket.pnr}
                      </div>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="font-mono font-bold text-emerald-400 text-xs">
                      Seat {item.ticket.seatNumber}
                    </span>
                    <div className="text-[10px] text-slate-400 uppercase font-mono">
                      Boarded
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
