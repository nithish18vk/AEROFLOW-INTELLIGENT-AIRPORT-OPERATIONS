import React from 'react';
import {
  Plane,
  AlertTriangle,
  Sparkles,
  Layers,
  Luggage,
  Users,
  BarChart3,
  Cpu,
  ShieldAlert,
  LogOut,
  Home,
  Compass,
  CheckCircle2,
  ArrowRight,
  UserCheck,
  Power,
  Ticket as TicketIcon,
  ShieldCheck,
  Lock,
} from 'lucide-react';
import { UserRole } from '../types/aeroflow';

export type ActiveTab =
  | 'booking'
  | 'flight-details'
  | 'tickets'
  | 'assigned-flights'
  | 'flights'
  | 'gates'
  | 'baggage'
  | 'crew'
  | 'fleet'
  | 'emergency'
  | 'management'
  | 'analytics';

export interface MenuItemConfig {
  id: ActiveTab;
  label: string;
  shortDesc: string;
}

export const USER_ROLES: { id: UserRole; label: string; badge: string; desc: string }[] = [
  { id: 'PASSENGER', label: 'Passenger', badge: 'Passenger Portal', desc: 'Ticket booking, flight schedules & baggage tracking' },
  { id: 'PILOT_CREW', label: 'Pilot / Crew', badge: 'Flight Deck & Cabin', desc: 'Assigned flights, crew rest compliance & emergency command' },
  { id: 'ATC', label: 'ATC', badge: 'Control Tower', desc: 'Air traffic dispatch, delays, gate links & emergency coordination' },
  { id: 'GROUND_STAFF', label: 'Ground Staff', badge: 'Ramp & Apron', desc: 'Bulk baggage manifests, gate slots & aircraft maintenance' },
  { id: 'MANAGER_ADMIN', label: 'Manager / Admin', badge: 'Executive AOCC', desc: 'Complete airport oversight across all operations & analytics' },
];

/**
 * Strict Role-Based Menu Mapping:
 * - Passenger: Ticket Booking, Flight Details, Baggage, Tickets
 * - Pilot/Crew: Assigned Flights, Crew, Emergency
 * - ATC: Flight Operations, Gates, Emergency
 * - Ground Staff: Baggage, Gates, Aircraft
 * - Manager/Admin: Management, Flights, Crew, Gates, Baggage, Emergency, Analytics
 */
export const ROLE_MENU_MAP: Record<UserRole, MenuItemConfig[]> = {
  PASSENGER: [
    {
      id: 'booking',
      label: 'Ticket Booking',
      shortDesc: 'Search routes, real-time aircraft cabin maps & multi-seat booking',
    },
    {
      id: 'flight-details',
      label: 'Flight Details',
      shortDesc: 'Live flight schedule, terminal & gate timetable and status',
    },
    {
      id: 'baggage',
      label: 'Baggage',
      shortDesc: 'Track passenger luggage, carousel allocations & RFID telemetry',
    },
    {
      id: 'tickets',
      label: 'Tickets',
      shortDesc: 'Digital booking references (PNR), baggage allowance & boarding passes',
    },
  ],
  PILOT_CREW: [
    {
      id: 'assigned-flights',
      label: 'Assigned Flights',
      shortDesc: 'Flight deck briefing, route dispatch, fuel load & crew pairings',
    },
    {
      id: 'crew',
      label: 'Crew',
      shortDesc: 'Mandatory 8h pilot rest eligibility, FDP limits & crew rostering',
    },
    {
      id: 'emergency',
      label: 'Emergency',
      shortDesc: 'Emergency command, incident reporting & live subsystem fixes',
    },
  ],
  ATC: [
    {
      id: 'flights',
      label: 'Flight Operations',
      shortDesc: 'Live flight schedule, radar slots, delays & runway operations',
    },
    {
      id: 'gates',
      label: 'Gates',
      shortDesc: 'T-48h gate assignment, movement approvals & terminal allocation',
    },
    {
      id: 'emergency',
      label: 'Emergency',
      shortDesc: 'Emergency command, runway priority holds & CFR unit coordination',
    },
  ],
  GROUND_STAFF: [
    {
      id: 'baggage',
      label: 'Baggage',
      shortDesc: 'Bulk flight manifests (100–500+ bags), ULD containers & carousels',
    },
    {
      id: 'gates',
      label: 'Gates',
      shortDesc: 'Apron parking slots, jetbridge wingspan checks & gate maintenance',
    },
    {
      id: 'fleet',
      label: 'Aircraft',
      shortDesc: 'Aircraft fleet management, ramp refueling & maintenance status',
    },
  ],
  MANAGER_ADMIN: [
    {
      id: 'management',
      label: 'Management',
      shortDesc: 'Central Airport Operations Control Center (AOCC) executive hub',
    },
    {
      id: 'flights',
      label: 'Flights',
      shortDesc: 'Full airport flight schedules, schedule dispatch & delay management',
    },
    {
      id: 'crew',
      label: 'Crew',
      shortDesc: 'Flight crew staffing, 8h rest compliance & shift rosters',
    },
    {
      id: 'gates',
      label: 'Gates',
      shortDesc: 'Terminal gate utilization, approvals & apron moves',
    },
    {
      id: 'baggage',
      label: 'Baggage',
      shortDesc: 'Airport-wide baggage logistics, ULD balancing & baggage SLA',
    },
    {
      id: 'emergency',
      label: 'Emergency',
      shortDesc: 'Emergency response command & live incident operations',
    },
    {
      id: 'analytics',
      label: 'Analytics',
      shortDesc: 'AOCC operations telemetry, on-time KPI & cabin yield',
    },
  ],
};

export const getTabIcon = (id: ActiveTab) => {
  switch (id) {
    case 'booking':
      return Sparkles;
    case 'flight-details':
      return Plane;
    case 'tickets':
      return TicketIcon;
    case 'assigned-flights':
      return Compass;
    case 'flights':
      return Plane;
    case 'gates':
      return Layers;
    case 'baggage':
      return Luggage;
    case 'crew':
      return Users;
    case 'fleet':
      return Plane;
    case 'emergency':
      return ShieldAlert;
    case 'management':
      return Cpu;
    case 'analytics':
      return BarChart3;
  }
};

interface SidebarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  hasActiveEmergency: boolean;
  activeIncidentCount: number;
  onOpenEmergencyModal: () => void;
  onQuickBook: () => void;
  currentUserRole: UserRole;
  onChangeUserRole: (role: UserRole) => void;
  onReturnToOpening: () => void;
  onExitSystem: () => void;
}

export const Navbar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  hasActiveEmergency,
  activeIncidentCount,
  onOpenEmergencyModal,
  onQuickBook,
  currentUserRole,
  onChangeUserRole,
  onReturnToOpening,
  onExitSystem,
}) => {
  const currentRoleConfig = USER_ROLES.find((r) => r.id === currentUserRole) || USER_ROLES[0];
  // Strictly filter menus: only show menus authorized for currentUserRole!
  const authorizedMenus = ROLE_MENU_MAP[currentUserRole] || ROLE_MENU_MAP.PASSENGER;
  const isEmergencyAllowed = authorizedMenus.some((m) => m.id === 'emergency');

  return (
    <aside
      aria-label="Role-Based Sidebar Navigation"
      className="w-full lg:w-64 xl:w-68 shrink-0 border-b lg:border-b-0 lg:border-r border-slate-800 bg-slate-950 flex flex-col justify-between lg:min-h-screen lg:sticky lg:top-0 z-30"
    >
      <div>
        {/* Brand Header with Aircraft Logo */}
        <div className="p-4 sm:p-5 border-b border-slate-800/80 flex items-center justify-between">
          <button
            onClick={onReturnToOpening}
            className="flex items-center gap-3 text-left group focus:outline-none"
            title="Return to Opening Aircraft Menu Hub"
          >
            <div className="relative flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-sky-600 text-white shadow-md shadow-sky-950 ring-1 ring-sky-400/40 group-hover:bg-sky-500 transition-colors">
              <Plane className="h-5 w-5 -rotate-45" />
            </div>
            <div>
              <div className="text-base font-bold tracking-tight text-white group-hover:text-sky-400 transition-colors">
                AeroFlow
              </div>
              <div className="text-[11px] text-slate-400 font-medium">
                JFK Operations System
              </div>
            </div>
          </button>

          {/* Mobile Quick Exit Button */}
          <button
            onClick={onExitSystem}
            className="lg:hidden flex items-center gap-1.5 rounded-lg border border-rose-500/40 bg-rose-950/50 px-2.5 py-1.5 text-xs font-semibold text-rose-300 hover:bg-rose-900/70 transition-colors whitespace-nowrap"
          >
            <LogOut className="h-3.5 w-3.5" />
            <span>Exit</span>
          </button>
        </div>

        {/* Active Operator Role Switcher */}
        <div className="px-4 py-3 border-b border-slate-900 bg-slate-900/40">
          <label
            htmlFor="sidebar-role-select"
            className="block text-[11px] font-medium text-slate-400 mb-1"
          >
            Logged-In Role (Controls Menus)
          </label>
          <select
            id="sidebar-role-select"
            value={currentUserRole}
            onChange={(e) => onChangeUserRole(e.target.value as UserRole)}
            className="w-full rounded-lg border border-slate-700 bg-slate-950 px-2.5 py-1.5 text-xs font-medium text-slate-200 focus:border-sky-500 focus:outline-none"
          >
            {USER_ROLES.map((r) => (
              <option key={r.id} value={r.id}>
                {r.label} · {r.badge}
              </option>
            ))}
          </select>

          <div className="mt-1.5 flex items-center gap-1.5 text-[10px] text-sky-400 font-medium">
            <ShieldCheck className="h-3 w-3 shrink-0" />
            <span className="truncate">{currentRoleConfig.badge}</span>
          </div>
        </div>

        {/* Emergency Quick Banner inside Sidebar (Only if Emergency is authorized for this role) */}
        {hasActiveEmergency && isEmergencyAllowed && (
          <div className="px-3 pt-3">
            <button
              onClick={() => setActiveTab('emergency')}
              className="w-full flex items-center justify-between gap-2 px-3 py-2 text-xs font-semibold text-rose-200 bg-rose-950/90 border border-rose-500/50 rounded-lg hover:bg-rose-900 transition-colors"
            >
              <span className="flex items-center gap-2 truncate">
                <AlertTriangle className="h-4 w-4 text-rose-400 shrink-0 animate-pulse" />
                <span className="truncate">Active Emergency ({activeIncidentCount})</span>
              </span>
              <span className="text-[10px] font-mono underline shrink-0">Fix / Exit</span>
            </button>
          </div>
        )}

        {/* Desktop Left-Side Vertical Menu - STRICTLY ONLY AUTHORIZED MENUS */}
        <nav aria-label="Role Authorized Modules" className="hidden lg:block p-3 space-y-4">
          <div>
            <div className="px-3 mb-2 flex items-center justify-between text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
              <span>{currentRoleConfig.label} Menus</span>
              <span className="font-mono text-[10px] text-slate-500">
                {authorizedMenus.length} allowed
              </span>
            </div>

            <div className="space-y-1">
              {authorizedMenus.map((item) => {
                const Icon = getTabIcon(item.id);
                const isActive = activeTab === item.id;
                const isEmg = item.id === 'emergency';

                return (
                  <button
                    key={item.id}
                    onClick={() => setActiveTab(item.id)}
                    className={`w-full flex items-center justify-between gap-2.5 px-3 py-2.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
                      isActive
                        ? isEmg
                          ? 'bg-rose-600 text-white shadow-sm'
                          : 'bg-sky-600 text-white shadow-sm font-semibold'
                        : isEmg && hasActiveEmergency
                        ? 'text-rose-300 bg-rose-950/40 hover:bg-rose-950/80 border border-rose-500/30'
                        : 'text-slate-300 hover:text-white hover:bg-slate-900'
                    }`}
                  >
                    <span className="flex items-center gap-2.5 truncate">
                      <Icon className="h-4 w-4 shrink-0" />
                      <span className="truncate">{item.label}</span>
                    </span>
                    {isEmg && hasActiveEmergency && (
                      <span className="font-mono text-[10px] font-bold px-1.5 py-0.5 rounded bg-rose-500/20 text-rose-200">
                        {activeIncidentCount}
                      </span>
                    )}
                    {item.id === 'booking' && (
                      <span className="font-mono text-[9px] font-bold px-1.5 py-0.5 rounded bg-sky-500/20 text-sky-200">
                        NEW
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        </nav>

        {/* Mobile Horizontal Strip for narrow screens - STRICTLY ONLY AUTHORIZED MENUS */}
        <div className="flex lg:hidden overflow-x-auto px-3 py-2 bg-slate-900/90 border-t border-slate-800 gap-1.5">
          {authorizedMenus.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap shrink-0 transition-colors ${
                  isActive
                    ? 'bg-sky-600 text-white font-semibold'
                    : 'text-slate-300 bg-slate-800/80 hover:bg-slate-800'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Bottom Actions */}
      <div className="hidden lg:flex flex-col gap-2 p-4 border-t border-slate-800 bg-slate-950">
        {/* If passenger, show prominent shortcut to Ticket Booking */}
        {currentUserRole === 'PASSENGER' ? (
          <button
            onClick={() => setActiveTab('booking')}
            className="w-full flex items-center justify-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-sky-600 hover:bg-sky-500 rounded-lg shadow-sm transition-colors whitespace-nowrap"
          >
            <Sparkles className="h-3.5 w-3.5" />
            <span>Book Flight Seat</span>
          </button>
        ) : (
          <div className="rounded-lg bg-slate-900/80 border border-slate-800 px-3 py-2 text-[11px] text-slate-400">
            <span className="text-white font-semibold block">{currentRoleConfig.label}</span>
            <span className="text-slate-500 text-[10px]">Restricted Role Security Active</span>
          </div>
        )}

        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={onReturnToOpening}
            className="flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-300 bg-slate-900 hover:bg-slate-800 hover:text-white border border-slate-800 rounded-lg transition-colors whitespace-nowrap"
          >
            <Home className="h-3.5 w-3.5" />
            <span>Menu Hub</span>
          </button>

          <button
            onClick={onExitSystem}
            className="flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-semibold text-rose-300 bg-rose-950/60 hover:bg-rose-900/80 hover:text-white border border-rose-500/40 rounded-lg transition-colors whitespace-nowrap"
          >
            <LogOut className="h-3.5 w-3.5" />
            <span>Exit System</span>
          </button>
        </div>
      </div>
    </aside>
  );
};

interface OpeningHubProps {
  onSelectMenuModule: (tab: ActiveTab) => void;
  currentUserRole: UserRole;
  onChangeUserRole: (role: UserRole) => void;
  hasActiveEmergency: boolean;
  onExitSystem: () => void;
  isExited: boolean;
  onRelaunchSystem: () => void;
}

export const OpeningHub: React.FC<OpeningHubProps> = ({
  onSelectMenuModule,
  currentUserRole,
  onChangeUserRole,
  hasActiveEmergency,
  onExitSystem,
  isExited,
  onRelaunchSystem,
}) => {
  const currentRoleConfig = USER_ROLES.find((r) => r.id === currentUserRole) || USER_ROLES[0];
  // Strictly filter menus for Opening Hub as well: Only show authorized menus for currentUserRole!
  const authorizedMenus = ROLE_MENU_MAP[currentUserRole] || ROLE_MENU_MAP.PASSENGER;
  const isEmergencyAllowed = authorizedMenus.some((m) => m.id === 'emergency');

  if (isExited) {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center justify-center p-6">
        <div className="w-full max-w-lg rounded-2xl border border-slate-800 bg-slate-900/90 p-8 text-center space-y-6 shadow-2xl">
          <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-2xl bg-slate-950 border border-slate-800 text-sky-400 shadow-inner">
            <Plane className="h-10 w-10 -rotate-45" />
          </div>
          <div className="space-y-2">
            <div className="text-xs font-medium text-emerald-400">
              Session Safely Closed · All Role Credentials Cleared
            </div>
            <h1 className="text-2xl font-bold text-white">
              Exited AeroFlow Operations System
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
              You have safely exited the AeroFlow Airport Operations Management console as{' '}
              <span className="text-slate-200 font-semibold">
                {currentRoleConfig.label}
              </span>
              . All flight telemetry locks and terminal controls have been released.
            </p>
          </div>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
            <button
              onClick={onRelaunchSystem}
              className="w-full sm:w-auto flex items-center justify-center gap-2 rounded-lg bg-sky-600 px-6 py-2.5 text-xs font-semibold text-white hover:bg-sky-500 transition-colors"
            >
              <Power className="h-4 w-4" />
              <span>Return to Aircraft Logo & Menu Hub</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between p-6 sm:p-10">
      {/* Top Bar on Opening Screen: Operator Role & Exit Button */}
      <header className="w-full max-w-6xl mx-auto flex flex-wrap items-center justify-between gap-4 border-b border-slate-800/80 pb-4">
        <div className="flex items-center gap-2.5">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-sky-600 text-white">
            <Plane className="h-4 w-4 -rotate-45" />
          </div>
          <span className="text-sm font-bold tracking-tight text-white">
            AeroFlow Aviation Command
          </span>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <UserCheck className="h-4 w-4 text-sky-400 hidden sm:inline" />
            <label htmlFor="opening-role-select" className="text-xs text-slate-400">
              User Role:
            </label>
            <select
              id="opening-role-select"
              value={currentUserRole}
              onChange={(e) => onChangeUserRole(e.target.value as UserRole)}
              className="rounded-lg border border-slate-700 bg-slate-900 px-3 py-1.5 text-xs font-medium text-white focus:border-sky-500 focus:outline-none"
            >
              {USER_ROLES.map((r) => (
                <option key={r.id} value={r.id}>
                  {r.label} ({r.badge})
                </option>
              ))}
            </select>
          </div>

          <button
            onClick={onExitSystem}
            className="flex items-center gap-1.5 rounded-lg border border-rose-500/40 bg-rose-950/60 px-3.5 py-1.5 text-xs font-semibold text-rose-200 hover:bg-rose-900/80 transition-colors whitespace-nowrap"
          >
            <LogOut className="h-3.5 w-3.5" />
            <span>Exit System</span>
          </button>
        </div>
      </header>

      {/* Centerpiece: Prominent Aircraft Logo Emblem & Prompt to Select Menu */}
      <main className="w-full max-w-6xl mx-auto my-8 space-y-8">
        <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-6 sm:p-10 text-center space-y-5 relative overflow-hidden">
          {/* Aircraft Logo Emblem */}
          <div className="mx-auto flex flex-col items-center">
            <div
              aria-label="AeroFlow Aircraft Emblem Logo"
              className="relative flex h-24 w-24 items-center justify-center rounded-3xl bg-gradient-to-b from-sky-500 to-sky-700 text-white shadow-xl shadow-sky-950/80 border border-sky-400/40"
            >
              <svg
                viewBox="0 0 64 64"
                className="h-14 w-14 fill-current text-white drop-shadow"
                role="img"
                aria-label="Commercial Jet Aircraft Logo"
              >
                <path d="M58.5 11.5c-1.8-1.8-4.8-1.5-7 .7L39.8 23.9 14.2 16.5l-4.5 4.5 19.6 10.7-9.8 9.8-8.2-1.8-3.3 3.3 9.2 4.9 4.9 9.2 3.3-3.3-1.8-8.2 9.8-9.8 10.7 19.6 4.5-4.5-7.4-25.6 11.7-11.7c2.2-2.2 2.5-5.2.7-7z" />
              </svg>
            </div>
            <div className="mt-3 text-xs font-medium text-sky-400 tracking-wide">
              JFK International Air Operations Control · Role: {currentRoleConfig.label} ({currentRoleConfig.badge})
            </div>
          </div>

          <div className="max-w-2xl mx-auto space-y-2">
            <h1 className="text-2xl sm:text-4xl font-bold tracking-tight text-white">
              AeroFlow Airport Operations Hub
            </h1>
            <p className="text-sm sm:text-base text-slate-300">
              Welcome to the central operations platform.{' '}
              <span className="text-sky-300 font-semibold">
                Showing authorized menus for {currentRoleConfig.label}. Please select a menu module below to open its respective workspace.
              </span>
            </p>
          </div>

          {/* Quick Primary Action CTA */}
          <div className="flex flex-wrap items-center justify-center gap-3 pt-1">
            <button
              onClick={() => onSelectMenuModule(authorizedMenus[0]?.id || 'booking')}
              className="flex items-center gap-2 rounded-lg bg-sky-600 px-5 py-2.5 text-xs sm:text-sm font-semibold text-white hover:bg-sky-500 transition-colors shadow-md"
            >
              <Plane className="h-4 w-4" />
              <span>Open {authorizedMenus[0]?.label}</span>
              <ArrowRight className="h-4 w-4" />
            </button>

            {hasActiveEmergency && isEmergencyAllowed && (
              <button
                onClick={() => onSelectMenuModule('emergency')}
                className="flex items-center gap-2 rounded-lg bg-rose-600 px-5 py-2.5 text-xs sm:text-sm font-semibold text-white hover:bg-rose-500 transition-colors shadow-md"
              >
                <AlertTriangle className="h-4 w-4" />
                <span>Respond to Active Emergency</span>
              </button>
            )}
          </div>
        </div>

        {/* Interactive Menu Selection Grid - STRICTLY ROLE-BASED */}
        <section aria-label="Operations Menu Selection">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-semibold text-slate-300">
              Authorized Menus for <span className="text-sky-400">{currentRoleConfig.label}</span> (Redirects to Sidebar Workspace)
            </h2>
            <span className="text-xs text-slate-400 font-mono tabular-nums">
              {authorizedMenus.length} Menus Available
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3.5">
            {authorizedMenus.map((item) => {
              const Icon = getTabIcon(item.id);
              const isEmergencyItem = item.id === 'emergency';

              return (
                <button
                  key={item.id}
                  onClick={() => onSelectMenuModule(item.id)}
                  className={`group text-left rounded-xl border p-4 transition-all flex flex-col justify-between ${
                    isEmergencyItem && hasActiveEmergency
                      ? 'border-rose-500/50 bg-rose-950/30 hover:bg-rose-950/50 hover:border-rose-400'
                      : 'border-slate-800 bg-slate-900/50 hover:bg-slate-900 hover:border-sky-500/50'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between gap-2 mb-3">
                      <div
                        className={`flex h-9 w-9 items-center justify-center rounded-lg border ${
                          isEmergencyItem
                            ? 'bg-rose-950/80 border-rose-700 text-rose-400'
                            : 'bg-slate-950 border-slate-800 text-sky-400 group-hover:border-sky-500/40'
                        }`}
                      >
                        <Icon className="h-4 w-4" />
                      </div>
                      <ArrowRight className="h-4 w-4 text-slate-500 group-hover:text-sky-400 group-hover:translate-x-0.5 transition-all" />
                    </div>
                    <div className="text-sm font-bold text-white group-hover:text-sky-300 transition-colors">
                      {item.label}
                    </div>
                    <p className="mt-1 text-xs text-slate-400 leading-relaxed">
                      {item.shortDesc}
                    </p>
                  </div>

                  <div className="mt-4 pt-2.5 border-t border-slate-800/70 flex items-center justify-between text-[11px] font-medium text-sky-400">
                    <span>Open Module</span>
                    <span aria-hidden="true">→</span>
                  </div>
                </button>
              );
            })}
          </div>
        </section>
      </main>

      {/* Footer with Exit option */}
      <footer className="w-full max-w-6xl mx-auto border-t border-slate-800/80 pt-4 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-slate-400">
        <div>
          AeroFlow Airport Operations Management System · Role-Based Access Control Enforced
        </div>
        <button
          onClick={onExitSystem}
          className="text-rose-400 hover:underline font-medium flex items-center gap-1"
        >
          <LogOut className="h-3.5 w-3.5" />
          <span>Exit Application</span>
        </button>
      </footer>
    </div>
  );
};
