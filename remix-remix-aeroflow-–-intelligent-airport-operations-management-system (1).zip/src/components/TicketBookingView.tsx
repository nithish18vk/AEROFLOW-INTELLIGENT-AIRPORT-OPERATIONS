import React, { useState, useMemo, useEffect } from 'react';
import {
  Flight,
  Passenger,
  PassengerAircraft,
  SeatClass,
  Ticket,
  PaymentMethod,
} from '../types/aeroflow';
import {
  Plane,
  Search,
  Filter,
  ArrowRight,
  ArrowLeftRight,
  RotateCcw,
  CheckCircle2,
  Lock,
  Sparkles,
  Users,
  CreditCard,
  ShieldCheck,
  AlertCircle,
  Clock,
  MapPin,
  Luggage,
  Calendar,
  DollarSign,
  Info,
} from 'lucide-react';

interface TicketBookingViewProps {
  flights: Flight[];
  passengerFleet: PassengerAircraft[];
  passengers: Passenger[];
  existingTickets: Ticket[];
  onConfirmMultiBooking: (
    flight: Flight,
    seatAssignments: { seatNumber: string; seatClass: SeatClass; passengerName: string; passengerId?: string }[],
    totalPrice: number,
    paymentMethod: PaymentMethod
  ) => void;
  preSelectedFlightId?: string;
  onViewBoardingPass?: (ticket: Ticket) => void;
}

interface AircraftCabinLayout {
  modelName: string;
  fuselageType: 'WIDE_BODY_TWIN_AISLE' | 'NARROW_BODY_SINGLE_AISLE';
  seatConfigLabel: string;
  capacities: {
    first: number;
    business: number;
    economy: number;
    total: number;
  };
  firstClassSeats: string[];
  businessSeats: string[];
  economySeats: string[];
}

export const getCabinLayoutForAircraft = (
  flight: Flight,
  fleet: PassengerAircraft[]
): AircraftCabinLayout => {
  const matchedAc = fleet.find(
    (ac) => ac.id === flight.aircraftId || ac.model === flight.aircraftModel
  );
  const model = matchedAc?.model || flight.aircraftModel;

  // 1. Boeing 737 MAX 9 (Narrow-body 3-3, 178 seats, NO First Class)
  if (model.includes('737')) {
    return {
      modelName: 'Boeing 737 MAX 9',
      fuselageType: 'NARROW_BODY_SINGLE_AISLE',
      seatConfigLabel: 'Single-Aisle Narrow-Body (2-2 Business / 3-3 Economy)',
      capacities: matchedAc?.seatCapacity || {
        first: 0,
        business: 16,
        economy: 162,
        total: 178,
      },
      firstClassSeats: [],
      businessSeats: [
        '01A', '01C', '01D', '01F',
        '02A', '02C', '02D', '02F',
        '03A', '03C', '03D', '03F',
        '04A', '04C', '04D', '04F',
      ],
      economySeats: [
        '10A', '10B', '10C', '10D', '10E', '10F',
        '11A', '11B', '11C', '11D', '11E', '11F',
        '12A', '12B', '12C', '12D', '12E', '12F',
        '14A', '14B', '14C', '14D', '14E', '14F',
        '15A', '15B', '15C', '15D', '15E', '15F',
        '16A', '16B', '16C', '16D', '16E', '16F',
      ],
    };
  }

  // 2. Airbus A350-900 (Ultra-Long-Range Wide-body, 310 seats: 12 First, 36 Business, 262 Economy)
  if (model.includes('A350') || model.includes('350')) {
    return {
      modelName: 'Airbus A350-900',
      fuselageType: 'WIDE_BODY_TWIN_AISLE',
      seatConfigLabel: 'Twin-Aisle Wide-Body (1-2-1 Suites / 1-2-1 Pods / 3-3-3 Economy)',
      capacities: matchedAc?.seatCapacity || {
        first: 12,
        business: 36,
        economy: 262,
        total: 310,
      },
      firstClassSeats: [
        '01A', '01D', '01G', '01K',
        '02A', '02D', '02G', '02K',
        '03A', '03D', '03G', '03K',
      ],
      businessSeats: [
        '10A', '10D', '10G', '10K',
        '11A', '11D', '11G', '11K',
        '12A', '12D', '12G', '12K',
        '14A', '14D', '14G', '14K',
        '15A', '15D', '15G', '15K',
      ],
      economySeats: [
        '20A', '20B', '20C', '20D', '20E', '20G', '20H', '20J', '20K',
        '21A', '21B', '21C', '21D', '21E', '21G', '21H', '21J', '21K',
        '22A', '22B', '22C', '22D', '22E', '22G', '22H', '22J', '22K',
        '23A', '23B', '23C', '23D', '23E', '23G', '23H', '23J', '23K',
      ],
    };
  }

  // 3. Boeing 787-9 Dreamliner (Wide-body, 290 seats: 8 First, 28 Business, 254 Economy)
  return {
    modelName: 'Boeing 787-9 Dreamliner',
    fuselageType: 'WIDE_BODY_TWIN_AISLE',
    seatConfigLabel: 'Twin-Aisle Wide-Body (1-2-1 First / 2-2-2 Business / 3-3-3 Economy)',
    capacities: matchedAc?.seatCapacity || {
      first: 8,
      business: 28,
      economy: 254,
      total: 290,
    },
    firstClassSeats: [
      '01A', '01D', '01G', '01K',
      '02A', '02D', '02G', '02K',
    ],
    businessSeats: [
      '10A', '10C', '10D', '10G', '10H', '10K',
      '11A', '11C', '11D', '11G', '11H', '11K',
      '12A', '12C', '12D', '12G', '12H', '12K',
      '14A', '14C', '14D', '14G', '14H', '14K',
    ],
    economySeats: [
      '20A', '20B', '20C', '20D', '20E', '20F', '20G', '20H', '20K',
      '21A', '21B', '21C', '21D', '21E', '21F', '21G', '21H', '21K',
      '22A', '22B', '22C', '22D', '22E', '22F', '22G', '22H', '22K',
    ],
  };
};

export const TicketBookingView: React.FC<TicketBookingViewProps> = ({
  flights,
  passengerFleet,
  passengers,
  existingTickets,
  onConfirmMultiBooking,
  preSelectedFlightId,
}) => {
  // Route Filters: From -> To
  const [fromFilter, setFromFilter] = useState<string>('ALL');
  const [toFilter, setToFilter] = useState<string>('ALL');
  const [searchKeyword, setSearchKeyword] = useState<string>('');

  // Extract unique origins and destinations from PASSENGER flights
  const passengerFlights = useMemo(
    () => flights.filter((f) => f.aircraftCategory === 'PASSENGER'),
    [flights]
  );

  const uniqueOrigins = useMemo(() => {
    const set = new Map<string, string>();
    passengerFlights.forEach((f) => {
      set.set(f.originIata, `${f.originCity} (${f.originIata})`);
    });
    return Array.from(set.entries());
  }, [passengerFlights]);

  const uniqueDestinations = useMemo(() => {
    const set = new Map<string, string>();
    passengerFlights.forEach((f) => {
      set.set(f.destinationIata, `${f.destinationCity} (${f.destinationIata})`);
    });
    return Array.from(set.entries());
  }, [passengerFlights]);

  // Check if flight is bookable: NOT landed, NOT departed, NOT cancelled
  const isFlightBookable = (f: Flight) => {
    return (
      f.status !== 'LANDED' &&
      f.status !== 'DEPARTED' &&
      f.status !== 'CANCELLED' &&
      f.bookedSeats < f.totalSeats
    );
  };

  // Filtered & Sorted Flights: Show available flights first!
  const sortedAndFilteredFlights = useMemo(() => {
    let list = passengerFlights.filter((flight) => {
      if (fromFilter !== 'ALL' && flight.originIata !== fromFilter) return false;
      if (toFilter !== 'ALL' && flight.destinationIata !== toFilter) return false;
      if (searchKeyword.trim()) {
        const q = searchKeyword.toLowerCase();
        const match =
          flight.flightNumber.toLowerCase().includes(q) ||
          flight.originCity.toLowerCase().includes(q) ||
          flight.destinationCity.toLowerCase().includes(q) ||
          flight.aircraftModel.toLowerCase().includes(q);
        if (!match) return false;
      }
      return true;
    });

    // Sort: AVAILABLE FLIGHTS FIRST!
    list.sort((a, b) => {
      const aAvail = isFlightBookable(a);
      const bAvail = isFlightBookable(b);
      if (aAvail && !bAvail) return -1;
      if (!aAvail && bAvail) return 1;
      // Secondary sort: scheduled departure
      return a.scheduledDeparture.localeCompare(b.scheduledDeparture);
    });

    return list;
  }, [passengerFlights, fromFilter, toFilter, searchKeyword]);

  // Selected Flight for Seat Booking
  const [selectedFlight, setSelectedFlight] = useState<Flight | null>(() => {
    if (preSelectedFlightId) {
      const found = passengerFlights.find((f) => f.id === preSelectedFlightId);
      if (found) return found;
    }
    // Default to the first available bookable flight
    return passengerFlights.find(isFlightBookable) || passengerFlights[0] || null;
  });

  // Keep selected flight in sync if preSelectedFlightId changes
  useEffect(() => {
    if (preSelectedFlightId) {
      const found = passengerFlights.find((f) => f.id === preSelectedFlightId);
      if (found) setSelectedFlight(found);
    }
  }, [preSelectedFlightId, passengerFlights]);

  // Cabin Layout for Selected Flight
  const cabinLayout = useMemo(() => {
    if (!selectedFlight) return null;
    return getCabinLayoutForAircraft(selectedFlight, passengerFleet);
  }, [selectedFlight, passengerFleet]);

  // Occupied Seats for Selected Flight
  const occupiedSeats = useMemo(() => {
    if (!selectedFlight) return new Set<string>();
    return new Set(
      existingTickets
        .filter((t) => t.flightId === selectedFlight.id && t.status !== 'CANCELLED')
        .map((t) => t.seatNumber)
    );
  }, [existingTickets, selectedFlight]);

  // Multiple Seats Selection State
  const [selectedSeats, setSelectedSeats] = useState<string[]>([]);
  // Passenger assignments per selected seat: Record<seatNumber, { name: string; passengerId?: string }>
  const [seatAssignments, setSeatAssignments] = useState<
    Record<string, { name: string; passengerId?: string }>
  >({});
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('CREDIT_CARD');
  const [primaryPassengerId, setPrimaryPassengerId] = useState<string>(
    passengers[0]?.id || ''
  );
  const [bookingSuccessModal, setBookingSuccessModal] = useState<{
    flight: Flight;
    seats: string[];
    totalPrice: number;
    pnrList: string[];
  } | null>(null);

  // When selected flight changes, reset seat selection
  useEffect(() => {
    setSelectedSeats([]);
    setSeatAssignments({});
  }, [selectedFlight?.id]);

  const primaryPassenger =
    passengers.find((p) => p.id === primaryPassengerId) || passengers[0];

  // Helper to determine seat class
  const getSeatClass = (seat: string): SeatClass => {
    if (!cabinLayout) return 'ECONOMY';
    if (cabinLayout.firstClassSeats.includes(seat)) return 'FIRST';
    if (cabinLayout.businessSeats.includes(seat)) return 'BUSINESS';
    return 'ECONOMY';
  };

  // Helper to calculate price for a single seat
  const getSeatPrice = (seat: string, basePrice: number): number => {
    const sClass = getSeatClass(seat);
    let multiplier = 1.0;
    if (sClass === 'FIRST') multiplier = 3.6;
    if (sClass === 'BUSINESS') multiplier = 2.1;

    let price = basePrice * multiplier;
    // Frequent flyer discounts
    if (primaryPassenger?.frequentFlyerTier === 'PLATINUM') price *= 0.82;
    else if (primaryPassenger?.frequentFlyerTier === 'GOLD') price *= 0.88;
    else if (primaryPassenger?.frequentFlyerTier === 'SILVER') price *= 0.94;

    return Math.round(price);
  };

  // Toggle seat in multi-seat selection
  const handleToggleSeat = (seat: string) => {
    if (!selectedFlight || !isFlightBookable(selectedFlight)) return;
    if (occupiedSeats.has(seat)) return;

    setSelectedSeats((prev) => {
      const exists = prev.includes(seat);
      let next: string[];
      if (exists) {
        next = prev.filter((s) => s !== seat);
        // remove assignment
        const copy = { ...seatAssignments };
        delete copy[seat];
        setSeatAssignments(copy);
      } else {
        next = [...prev, seat];
        // assign default passenger name
        const seatIndex = next.length;
        const defaultName =
          seatIndex === 1
            ? primaryPassenger?.fullName || 'Lead Passenger'
            : `Passenger ${seatIndex} (${primaryPassenger?.fullName.split(' ')[1] || 'Guest'})`;

        setSeatAssignments((prevAssign) => ({
          ...prevAssign,
          [seat]: {
            name: defaultName,
            passengerId: seatIndex === 1 ? primaryPassenger?.id : undefined,
          },
        }));
      }
      return next;
    });
  };

  // Handle passenger name change for a specific seat
  const handleSeatPassengerChange = (seat: string, name: string) => {
    setSeatAssignments((prev) => ({
      ...prev,
      [seat]: { ...prev[seat], name },
    }));
  };

  // Calculate cumulative price for all selected seats
  const totalBookingPrice = useMemo(() => {
    if (!selectedFlight) return 0;
    return selectedSeats.reduce(
      (sum, seat) => sum + getSeatPrice(seat, selectedFlight.basePrice),
      0
    );
  }, [selectedSeats, selectedFlight, primaryPassenger]);

  // Handle Swap Origins
  const handleSwapRoute = () => {
    const tempFrom = fromFilter;
    setFromFilter(toFilter);
    setToFilter(tempFrom);
  };

  // Reset Filters
  const handleResetFilters = () => {
    setFromFilter('ALL');
    setToFilter('ALL');
    setSearchKeyword('');
  };

  // Confirm Multi-Seat Booking
  const handleConfirmBooking = () => {
    if (!selectedFlight || selectedSeats.length === 0) return;
    if (!isFlightBookable(selectedFlight)) return;

    const assignments = selectedSeats.map((seat) => {
      const seatClass = getSeatClass(seat);
      const assign = seatAssignments[seat];
      return {
        seatNumber: seat,
        seatClass,
        passengerName: assign?.name || primaryPassenger.fullName,
        passengerId: assign?.passengerId || primaryPassenger.id,
      };
    });

    onConfirmMultiBooking(selectedFlight, assignments, totalBookingPrice, paymentMethod);

    // Show local confirmation feedback
    const generatedPnrs = selectedSeats.map(
      () =>
        `AF${Math.floor(100 + Math.random() * 900)}${String.fromCharCode(
          65 + Math.floor(Math.random() * 26)
        )}`
    );

    setBookingSuccessModal({
      flight: selectedFlight,
      seats: [...selectedSeats],
      totalPrice: totalBookingPrice,
      pnrList: generatedPnrs,
    });

    // Reset selection
    setSelectedSeats([]);
    setSeatAssignments({});
  };

  return (
    <div className="space-y-6">
      {/* Top Header & Overview */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-sky-400">
            <Sparkles className="h-4 w-4" />
            <span>Dedicated Ticket Booking Service</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white mt-1">
            Flight Ticket & Seat Booking
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Select route, choose available flights, and reserve single or multiple seats with accurate aircraft cabin maps.
          </p>
        </div>

        {/* Available stats badge */}
        <div className="flex items-center gap-3">
          <div className="rounded-xl border border-slate-800 bg-slate-900/80 px-4 py-2.5 text-right">
            <div className="text-[11px] text-slate-400 uppercase font-semibold">Available Flights</div>
            <div className="text-lg font-bold text-emerald-400">
              {passengerFlights.filter(isFlightBookable).length} of {passengerFlights.length}
            </div>
          </div>
          <div className="rounded-xl border border-slate-800 bg-slate-900/80 px-4 py-2.5 text-right">
            <div className="text-[11px] text-slate-400 uppercase font-semibold">Active Aircraft</div>
            <div className="text-lg font-bold text-sky-400">{passengerFleet.length} Jets</div>
          </div>
        </div>
      </div>

      {/* Route Filter Bar: Filter by From -> To */}
      <section
        aria-label="Route Search and Filters"
        className="rounded-2xl border border-slate-800 bg-slate-900/90 p-4 sm:p-5 shadow-xl space-y-4"
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-300">
            <Filter className="h-4 w-4 text-sky-400" />
            <span>Filter Flights by Route (From → To)</span>
          </div>
          {(fromFilter !== 'ALL' || toFilter !== 'ALL' || searchKeyword) && (
            <button
              onClick={handleResetFilters}
              className="flex items-center gap-1 text-xs text-rose-400 hover:text-rose-300 transition-colors"
            >
              <RotateCcw className="h-3 w-3" />
              <span>Reset Filters</span>
            </button>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-3 items-center">
          {/* Origin (From) */}
          <div className="md:col-span-4">
            <label htmlFor="origin-filter" className="block text-[11px] font-medium text-slate-400 mb-1">
              From (Origin)
            </label>
            <div className="relative">
              <MapPin className="absolute left-3 top-2.5 h-4 w-4 text-sky-400 pointer-events-none" />
              <select
                id="origin-filter"
                value={fromFilter}
                onChange={(e) => setFromFilter(e.target.value)}
                className="w-full rounded-xl border border-slate-700 bg-slate-950 pl-9 pr-3 py-2 text-xs font-medium text-white focus:border-sky-500 focus:outline-none"
              >
                <option value="ALL">All Origins (Any Departure City)</option>
                {uniqueOrigins.map(([iata, label]) => (
                  <option key={iata} value={iata}>
                    {label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Swap Button */}
          <div className="md:col-span-1 flex justify-center pt-5 md:pt-4">
            <button
              type="button"
              onClick={handleSwapRoute}
              title="Swap From and To"
              className="flex h-9 w-9 items-center justify-center rounded-xl border border-slate-700 bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition-colors"
            >
              <ArrowLeftRight className="h-4 w-4" />
            </button>
          </div>

          {/* Destination (To) */}
          <div className="md:col-span-4">
            <label htmlFor="destination-filter" className="block text-[11px] font-medium text-slate-400 mb-1">
              To (Destination)
            </label>
            <div className="relative">
              <MapPin className="absolute left-3 top-2.5 h-4 w-4 text-emerald-400 pointer-events-none" />
              <select
                id="destination-filter"
                value={toFilter}
                onChange={(e) => setToFilter(e.target.value)}
                className="w-full rounded-xl border border-slate-700 bg-slate-950 pl-9 pr-3 py-2 text-xs font-medium text-white focus:border-sky-500 focus:outline-none"
              >
                <option value="ALL">All Destinations (Any Arrival City)</option>
                {uniqueDestinations.map(([iata, label]) => (
                  <option key={iata} value={iata}>
                    {label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Keyword Search */}
          <div className="md:col-span-3">
            <label htmlFor="booking-search" className="block text-[11px] font-medium text-slate-400 mb-1">
              Flight # or Model
            </label>
            <div className="relative">
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400 pointer-events-none" />
              <input
                id="booking-search"
                type="text"
                placeholder="e.g. AF-402, 787..."
                value={searchKeyword}
                onChange={(e) => setSearchKeyword(e.target.value)}
                className="w-full rounded-xl border border-slate-700 bg-slate-950 pl-9 pr-3 py-2 text-xs font-medium text-white placeholder-slate-500 focus:border-sky-500 focus:outline-none"
              />
            </div>
          </div>
        </div>

        {/* Active route pill */}
        {(fromFilter !== 'ALL' || toFilter !== 'ALL') && (
          <div className="flex items-center gap-2 pt-1 text-xs text-sky-300">
            <Info className="h-3.5 w-3.5 text-sky-400" />
            <span>
              Route Filter:{' '}
              <strong className="text-white">
                {fromFilter === 'ALL' ? 'Any Origin' : fromFilter} →{' '}
                {toFilter === 'ALL' ? 'Any Destination' : toFilter}
              </strong>{' '}
              · Showing available flights first
            </span>
          </div>
        )}
      </section>

      {/* Flights List or Empty State ("No flights available for this route.") */}
      {sortedAndFilteredFlights.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-slate-800 bg-slate-900/40 p-12 text-center space-y-4">
          <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-slate-800/80 text-rose-400">
            <AlertCircle className="h-7 w-7" />
          </div>
          <div className="space-y-1">
            <h3 className="text-lg font-bold text-white">
              No flights available for this route.
            </h3>
            <p className="text-xs sm:text-sm text-slate-400 max-w-md mx-auto">
              We couldn't find any passenger flights matching the selected departure and arrival airport criteria.
            </p>
          </div>
          <button
            onClick={handleResetFilters}
            className="inline-flex items-center gap-2 rounded-xl bg-sky-600 px-5 py-2 text-xs font-semibold text-white hover:bg-sky-500 transition-colors shadow-md"
          >
            <RotateCcw className="h-3.5 w-3.5" />
            <span>Clear Route Filters & View All Flights</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Left Column (5 Cols): Flight Selector Cards */}
          <div className="lg:col-span-5 space-y-3">
            <div className="flex items-center justify-between text-xs text-slate-400 px-1">
              <span className="font-semibold text-slate-300">
                Matching Flights ({sortedAndFilteredFlights.length})
              </span>
              <span className="text-[11px] text-emerald-400 font-mono">Available Shown First</span>
            </div>

            <div className="space-y-2.5 max-h-[720px] overflow-y-auto pr-1">
              {sortedAndFilteredFlights.map((flight) => {
                const isSelected = selectedFlight?.id === flight.id;
                const bookable = isFlightBookable(flight);
                const seatsRemaining = flight.totalSeats - flight.bookedSeats;

                return (
                  <div
                    key={flight.id}
                    onClick={() => setSelectedFlight(flight)}
                    className={`group relative rounded-xl border p-4 transition-all cursor-pointer ${
                      isSelected
                        ? 'border-sky-500 bg-sky-950/30 ring-1 ring-sky-500 shadow-md'
                        : bookable
                        ? 'border-slate-800 bg-slate-900/60 hover:border-slate-700 hover:bg-slate-900'
                        : 'border-slate-800/60 bg-slate-950/40 opacity-75 hover:opacity-100'
                    }`}
                  >
                    {/* Top Row: Flight number, model, & Status Badge */}
                    <div className="flex items-start justify-between gap-2 mb-2.5">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-bold text-white font-mono">
                            {flight.flightNumber}
                          </span>
                          <span className="text-[11px] font-medium text-slate-400">
                            {flight.airline}
                          </span>
                        </div>
                        <div className="text-[11px] text-slate-400 truncate max-w-[200px]">
                          {flight.aircraftModel} · {flight.aircraftTail}
                        </div>
                      </div>

                      {/* Status and Bookable Tag */}
                      <div className="flex flex-col items-end gap-1">
                        {bookable ? (
                          <span className="inline-flex items-center gap-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 px-2 py-0.5 text-[10px] font-semibold text-emerald-300">
                            <CheckCircle2 className="h-3 w-3" />
                            <span>Bookable · {seatsRemaining} Left</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 rounded-full bg-rose-500/10 border border-rose-500/30 px-2 py-0.5 text-[10px] font-semibold text-rose-300">
                            <Lock className="h-3 w-3" />
                            <span>
                              {flight.status === 'LANDED'
                                ? 'Landed · Booking Closed'
                                : flight.status === 'DEPARTED'
                                ? 'Departed · Closed'
                                : flight.status === 'CANCELLED'
                                ? 'Flight Cancelled'
                                : 'Flight Full'}
                            </span>
                          </span>
                        )}
                        <span className="text-[10px] font-mono text-slate-400 uppercase">
                          Status: {flight.status}
                        </span>
                      </div>
                    </div>

                    {/* Middle Row: Route Cities & Times */}
                    <div className="flex items-center justify-between border-t border-slate-800/80 pt-2.5">
                      <div>
                        <div className="text-base font-bold text-white font-mono">
                          {flight.originIata}
                        </div>
                        <div className="text-[11px] text-slate-400 truncate max-w-[110px]">
                          {flight.originCity}
                        </div>
                        <div className="text-[11px] font-mono text-sky-400 mt-0.5">
                          {flight.scheduledDeparture}
                        </div>
                      </div>

                      <div className="flex flex-col items-center px-2">
                        <div className="text-[10px] text-slate-500 font-mono">Direct</div>
                        <div className="flex items-center gap-1 text-slate-600">
                          <span className="h-[1px] w-6 bg-slate-700" />
                          <Plane className="h-3 w-3 text-slate-400 -rotate-45" />
                          <span className="h-[1px] w-6 bg-slate-700" />
                        </div>
                        <div className="text-[10px] text-slate-400 font-mono">
                          Gate {flight.gateNumber || 'TBD'}
                        </div>
                      </div>

                      <div className="text-right">
                        <div className="text-base font-bold text-white font-mono">
                          {flight.destinationIata}
                        </div>
                        <div className="text-[11px] text-slate-400 truncate max-w-[110px]">
                          {flight.destinationCity}
                        </div>
                        <div className="text-[11px] font-mono text-emerald-400 mt-0.5">
                          {flight.scheduledArrival}
                        </div>
                      </div>
                    </div>

                    {/* Bottom Row: Price & Booking Action */}
                    <div className="mt-3 flex items-center justify-between border-t border-slate-800/60 pt-2 text-xs">
                      <div>
                        <span className="text-[10px] text-slate-400 block">Base Economy</span>
                        <span className="font-bold text-white font-mono">
                          ${flight.basePrice}{' '}
                          <span className="text-[10px] text-slate-400 font-normal">/ seat</span>
                        </span>
                      </div>

                      <button
                        type="button"
                        disabled={!bookable}
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedFlight(flight);
                        }}
                        className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition-colors ${
                          bookable
                            ? isSelected
                              ? 'bg-sky-600 text-white'
                              : 'bg-slate-800 text-sky-300 hover:bg-sky-600 hover:text-white'
                            : 'bg-slate-900 text-slate-500 cursor-not-allowed border border-slate-800'
                        }`}
                      >
                        {bookable ? (
                          <>
                            <span>Select Seats</span>
                            <ArrowRight className="h-3 w-3" />
                          </>
                        ) : (
                          <>
                            <Lock className="h-3 w-3" />
                            <span>Booking Disabled</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right Column (7 Cols): Aircraft Cabin Map & Multi-Seat Booking Panel */}
          <div className="lg:col-span-7 space-y-5">
            {selectedFlight && cabinLayout ? (
              <div className="rounded-2xl border border-slate-800 bg-slate-900/90 p-5 shadow-2xl space-y-6">
                {/* Aircraft Header */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-base font-bold text-white font-mono">
                        {selectedFlight.flightNumber} Cabin Layout
                      </span>
                      <span className="text-xs text-sky-400 font-semibold">
                        · {cabinLayout.modelName}
                      </span>
                    </div>
                    <p className="text-xs text-slate-400 mt-0.5">
                      {cabinLayout.seatConfigLabel}
                    </p>
                  </div>

                  {/* Flight Status Banner */}
                  <div className="flex items-center gap-2">
                    {!isFlightBookable(selectedFlight) ? (
                      <div className="rounded-lg bg-rose-950/60 border border-rose-500/40 px-3 py-1.5 text-xs font-semibold text-rose-300 flex items-center gap-1.5">
                        <Lock className="h-3.5 w-3.5" />
                        <span>Booking Closed ({selectedFlight.status})</span>
                      </div>
                    ) : (
                      <div className="rounded-lg bg-emerald-950/60 border border-emerald-500/40 px-3 py-1.5 text-xs font-semibold text-emerald-300 flex items-center gap-1.5">
                        <CheckCircle2 className="h-3.5 w-3.5" />
                        <span>Interactive Multi-Seat Selection Active</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Capacity Summary Pills */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center text-xs">
                  <div className="rounded-xl border border-amber-500/30 bg-amber-950/20 p-2">
                    <span className="text-[10px] text-amber-300 font-semibold uppercase block">First Class</span>
                    <span className="text-sm font-bold text-amber-200">
                      {cabinLayout.capacities.first > 0 ? `${cabinLayout.capacities.first} Seats` : 'None'}
                    </span>
                  </div>

                  <div className="rounded-xl border border-purple-500/30 bg-purple-950/20 p-2">
                    <span className="text-[10px] text-purple-300 font-semibold uppercase block">Business</span>
                    <span className="text-sm font-bold text-purple-200">
                      {cabinLayout.capacities.business} Seats
                    </span>
                  </div>

                  <div className="rounded-xl border border-sky-500/30 bg-sky-950/20 p-2">
                    <span className="text-[10px] text-sky-300 font-semibold uppercase block">Economy</span>
                    <span className="text-sm font-bold text-sky-200">
                      {cabinLayout.capacities.economy} Seats
                    </span>
                  </div>

                  <div className="rounded-xl border border-slate-700 bg-slate-950/60 p-2">
                    <span className="text-[10px] text-slate-400 font-semibold uppercase block">Total Capacity</span>
                    <span className="text-sm font-bold text-white">
                      {cabinLayout.capacities.total} Seats
                    </span>
                  </div>
                </div>

                {/* Disable booking warning if landed/departed/cancelled */}
                {!isFlightBookable(selectedFlight) && (
                  <div className="rounded-xl border border-rose-500/40 bg-rose-950/30 p-3.5 text-xs text-rose-200 flex items-start gap-2.5">
                    <Lock className="h-4 w-4 text-rose-400 shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-white block">Seat Booking is Disabled for this Flight</strong>
                      This flight is currently in <strong>{selectedFlight.status}</strong> status. In compliance with airport operations policy, ticket and seat booking is locked once a flight has departed, landed, or been cancelled.
                    </div>
                  </div>
                )}

                {/* Legend */}
                <div className="flex flex-wrap items-center justify-between gap-3 text-[11px] text-slate-400 border-y border-slate-800/80 py-2.5">
                  <div className="flex flex-wrap items-center gap-3">
                    <span className="flex items-center gap-1.5">
                      <span className="h-3 w-3 rounded bg-amber-500/40 border border-amber-400" />
                      <span>First (${Math.round(selectedFlight.basePrice * 3.6)})</span>
                    </span>
                    <span className="flex items-center gap-1.5">
                      <span className="h-3 w-3 rounded bg-purple-500/40 border border-purple-400" />
                      <span>Business (${Math.round(selectedFlight.basePrice * 2.1)})</span>
                    </span>
                    <span className="flex items-center gap-1.5">
                      <span className="h-3 w-3 rounded bg-sky-500/40 border border-sky-400" />
                      <span>Economy (${selectedFlight.basePrice})</span>
                    </span>
                    <span className="flex items-center gap-1.5">
                      <span className="h-3 w-3 rounded bg-emerald-500 border border-emerald-300 ring-2 ring-emerald-500/50" />
                      <span className="text-emerald-300 font-semibold">Selected</span>
                    </span>
                    <span className="flex items-center gap-1.5">
                      <span className="h-3 w-3 rounded bg-slate-800 border border-slate-700 opacity-60" />
                      <span>Occupied</span>
                    </span>
                  </div>
                  <span className="text-slate-400 italic">Click seats to select / unselect</span>
                </div>

                {/* Interactive Cabin Layout Map */}
                <div className="rounded-xl border border-slate-800 bg-slate-950/80 p-4 space-y-5 overflow-x-auto">
                  {/* Cockpit Nose Indicator */}
                  <div className="mx-auto flex w-36 items-center justify-center rounded-t-full border border-b-0 border-slate-700 bg-slate-900 py-1.5 text-[10px] font-semibold text-slate-400 uppercase tracking-widest">
                    ▲ Flight Deck
                  </div>

                  {/* 1. First Class Section (if available) */}
                  {cabinLayout.firstClassSeats.length > 0 ? (
                    <div className="space-y-2">
                      <div className="text-[11px] font-bold uppercase tracking-wider text-amber-400 flex items-center justify-between">
                        <span>First Class Private Suites (1-2-1)</span>
                        <span className="text-[10px] font-normal text-slate-400">Lie-Flat 180°</span>
                      </div>
                      <div className="grid grid-cols-4 gap-2 max-w-sm mx-auto">
                        {cabinLayout.firstClassSeats.map((seat) => {
                          const isOccupied = occupiedSeats.has(seat);
                          const isSelected = selectedSeats.includes(seat);
                          const disabled = !isFlightBookable(selectedFlight) || isOccupied;

                          return (
                            <button
                              key={seat}
                              type="button"
                              disabled={disabled}
                              onClick={() => handleToggleSeat(seat)}
                              title={
                                isOccupied
                                  ? `Seat ${seat} is occupied`
                                  : `Select First Class Seat ${seat} ($${getSeatPrice(seat, selectedFlight.basePrice)})`
                              }
                              className={`relative flex flex-col items-center justify-center h-12 rounded-lg font-mono text-xs font-semibold transition-all ${
                                isSelected
                                  ? 'bg-emerald-600 text-white shadow-lg ring-2 ring-emerald-400 scale-105'
                                  : isOccupied
                                  ? 'bg-slate-900 text-slate-600 border border-slate-800 cursor-not-allowed opacity-50'
                                  : disabled
                                  ? 'bg-amber-950/30 text-amber-500/50 border border-amber-900/30 cursor-not-allowed'
                                  : 'bg-amber-950/40 text-amber-300 border border-amber-500/40 hover:bg-amber-800/60 hover:text-white cursor-pointer shadow-sm'
                              }`}
                            >
                              <span>{seat}</span>
                              {isOccupied && <Lock className="h-2.5 w-2.5 mt-0.5 text-slate-600" />}
                              {isSelected && <CheckCircle2 className="h-3 w-3 mt-0.5 text-white" />}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  ) : (
                    <div className="rounded-lg border border-dashed border-slate-800 bg-slate-900/30 p-2 text-center text-xs text-slate-500">
                      No First Class cabin configured for this {cabinLayout.modelName} (All Business + Economy)
                    </div>
                  )}

                  <div className="h-[1px] bg-slate-800 my-2" />

                  {/* 2. Business Class Section */}
                  <div className="space-y-2">
                    <div className="text-[11px] font-bold uppercase tracking-wider text-purple-400 flex items-center justify-between">
                      <span>Business Class Cabins</span>
                      <span className="text-[10px] font-normal text-slate-400">Direct Aisle Access</span>
                    </div>
                    <div className="grid grid-cols-4 sm:grid-cols-6 gap-2 max-w-md mx-auto">
                      {cabinLayout.businessSeats.map((seat) => {
                        const isOccupied = occupiedSeats.has(seat);
                        const isSelected = selectedSeats.includes(seat);
                        const disabled = !isFlightBookable(selectedFlight) || isOccupied;

                        return (
                          <button
                            key={seat}
                            type="button"
                            disabled={disabled}
                            onClick={() => handleToggleSeat(seat)}
                            title={
                              isOccupied
                                ? `Seat ${seat} is occupied`
                                : `Select Business Class Seat ${seat} ($${getSeatPrice(seat, selectedFlight.basePrice)})`
                            }
                            className={`relative flex flex-col items-center justify-center h-11 rounded-lg font-mono text-xs font-semibold transition-all ${
                              isSelected
                                ? 'bg-emerald-600 text-white shadow-lg ring-2 ring-emerald-400 scale-105'
                                : isOccupied
                                ? 'bg-slate-900 text-slate-600 border border-slate-800 cursor-not-allowed opacity-50'
                                : disabled
                                ? 'bg-purple-950/30 text-purple-500/50 border border-purple-900/30 cursor-not-allowed'
                                : 'bg-purple-950/40 text-purple-300 border border-purple-500/40 hover:bg-purple-800/60 hover:text-white cursor-pointer shadow-sm'
                            }`}
                          >
                            <span>{seat}</span>
                            {isOccupied && <Lock className="h-2.5 w-2.5 mt-0.5 text-slate-600" />}
                            {isSelected && <CheckCircle2 className="h-3 w-3 mt-0.5 text-white" />}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <div className="h-[1px] bg-slate-800 my-2" />

                  {/* 3. Economy Section */}
                  <div className="space-y-2">
                    <div className="text-[11px] font-bold uppercase tracking-wider text-sky-400 flex items-center justify-between">
                      <span>Main Cabin Economy Class</span>
                      <span className="text-[10px] font-normal text-slate-400">Standard & Preferred</span>
                    </div>
                    <div className="grid grid-cols-6 sm:grid-cols-9 gap-1.5 max-w-lg mx-auto">
                      {cabinLayout.economySeats.map((seat) => {
                        const isOccupied = occupiedSeats.has(seat);
                        const isSelected = selectedSeats.includes(seat);
                        const disabled = !isFlightBookable(selectedFlight) || isOccupied;

                        return (
                          <button
                            key={seat}
                            type="button"
                            disabled={disabled}
                            onClick={() => handleToggleSeat(seat)}
                            title={
                              isOccupied
                                ? `Seat ${seat} is occupied`
                                : `Select Economy Seat ${seat} ($${getSeatPrice(seat, selectedFlight.basePrice)})`
                            }
                            className={`relative flex flex-col items-center justify-center h-10 rounded-lg font-mono text-[11px] font-semibold transition-all ${
                              isSelected
                                ? 'bg-emerald-600 text-white shadow-lg ring-2 ring-emerald-400 scale-105'
                                : isOccupied
                                ? 'bg-slate-900 text-slate-600 border border-slate-800 cursor-not-allowed opacity-50'
                                : disabled
                                ? 'bg-sky-950/30 text-sky-500/50 border border-sky-900/30 cursor-not-allowed'
                                : 'bg-sky-950/40 text-sky-300 border border-sky-500/40 hover:bg-sky-800/60 hover:text-white cursor-pointer shadow-sm'
                            }`}
                          >
                            <span>{seat}</span>
                            {isOccupied && <Lock className="h-2 w-2 text-slate-600" />}
                            {isSelected && <CheckCircle2 className="h-2.5 w-2.5 text-white" />}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>

                {/* Selected Seats Summary & Multiple Passenger Assignment */}
                {selectedSeats.length > 0 && (
                  <div className="rounded-xl border border-sky-500/40 bg-sky-950/20 p-4 space-y-4">
                    <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
                      <div>
                        <div className="text-xs font-bold text-white flex items-center gap-1.5">
                          <Users className="h-4 w-4 text-sky-400" />
                          <span>
                            Selected Seats ({selectedSeats.length}): {selectedSeats.join(', ')}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-400 mt-0.5">
                          You are booking multiple seats. Assign passenger names for each seat below.
                        </p>
                      </div>

                      <button
                        onClick={() => {
                          setSelectedSeats([]);
                          setSeatAssignments({});
                        }}
                        className="text-xs text-rose-400 hover:underline font-medium"
                      >
                        Clear Selection
                      </button>
                    </div>

                    {/* Seat Assignment List */}
                    <div className="space-y-2.5">
                      {selectedSeats.map((seat, idx) => {
                        const sClass = getSeatClass(seat);
                        const seatPrice = getSeatPrice(seat, selectedFlight.basePrice);
                        const currentName = seatAssignments[seat]?.name || '';

                        return (
                          <div
                            key={seat}
                            className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 rounded-lg border border-slate-800 bg-slate-900/90 p-3"
                          >
                            <div className="flex items-center gap-3">
                              <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-sky-600/30 text-sky-300 font-mono font-bold text-xs border border-sky-500/40">
                                {seat}
                              </span>
                              <div>
                                <span className="text-xs font-semibold text-white">
                                  Seat {seat} · {sClass} Class
                                </span>
                                <div className="text-[10px] text-slate-400 font-mono">
                                  ${seatPrice} · Baggage: {sClass === 'FIRST' ? '64kg' : sClass === 'BUSINESS' ? '46kg' : '23kg'}
                                </div>
                              </div>
                            </div>

                            <div className="flex-1 max-w-xs">
                              <label htmlFor={`psg-${seat}`} className="sr-only">
                                Passenger Name
                              </label>
                              <input
                                id={`psg-${seat}`}
                                type="text"
                                placeholder={`Passenger ${idx + 1} Full Name`}
                                value={currentName}
                                onChange={(e) => handleSeatPassengerChange(seat, e.target.value)}
                                className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-1.5 text-xs font-medium text-white placeholder-slate-500 focus:border-sky-500 focus:outline-none"
                              />
                            </div>
                          </div>
                        );
                      })}
                    </div>

                    {/* Primary Booking Contact & Payment Method */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-slate-800/80">
                      <div>
                        <label htmlFor="primary-passenger" className="block text-[11px] font-medium text-slate-400 mb-1">
                          Primary Booking Account
                        </label>
                        <select
                          id="primary-passenger"
                          value={primaryPassengerId}
                          onChange={(e) => setPrimaryPassengerId(e.target.value)}
                          className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-1.5 text-xs font-medium text-white focus:border-sky-500 focus:outline-none"
                        >
                          {passengers.map((p) => (
                            <option key={p.id} value={p.id}>
                              {p.fullName} ({p.frequentFlyerTier} Tier · {p.accumulatedMiles.toLocaleString()} Miles)
                            </option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label htmlFor="booking-payment" className="block text-[11px] font-medium text-slate-400 mb-1">
                          Payment Method
                        </label>
                        <select
                          id="booking-payment"
                          value={paymentMethod}
                          onChange={(e) => setPaymentMethod(e.target.value as PaymentMethod)}
                          className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-1.5 text-xs font-medium text-white focus:border-sky-500 focus:outline-none"
                        >
                          <option value="CREDIT_CARD">Credit / Debit Card (Instant Issuance)</option>
                          <option value="CORPORATE_BILLING">Corporate Aviation Account (Pre-Approved)</option>
                          <option value="AIRLINE_MILES">Airline Frequent Flyer Miles (Redemption)</option>
                        </select>
                      </div>
                    </div>

                    {/* Price Total & Confirm Button */}
                    <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-3 border-t border-slate-800">
                      <div>
                        <div className="text-[11px] text-slate-400">Total Price for {selectedSeats.length} Seat(s)</div>
                        <div className="text-xl font-bold text-white font-mono flex items-baseline gap-2">
                          <span>${totalBookingPrice.toLocaleString()}</span>
                          {primaryPassenger?.frequentFlyerTier !== 'BRONZE' && (
                            <span className="text-[11px] text-emerald-400 font-sans font-semibold">
                              ({primaryPassenger?.frequentFlyerTier} Tier Discount Applied)
                            </span>
                          )}
                        </div>
                      </div>

                      <button
                        onClick={handleConfirmBooking}
                        disabled={!isFlightBookable(selectedFlight)}
                        className="w-full sm:w-auto flex items-center justify-center gap-2 rounded-xl bg-emerald-600 px-6 py-2.5 text-xs font-bold text-white hover:bg-emerald-500 transition-colors shadow-lg shadow-emerald-950/60 disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        <CreditCard className="h-4 w-4" />
                        <span>Confirm & Book {selectedSeats.length} Seat{selectedSeats.length > 1 ? 's' : ''}</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="rounded-2xl border border-dashed border-slate-800 bg-slate-900/30 p-12 text-center text-slate-500">
                Select a flight on the left to inspect cabin seat capacity and book multiple seats.
              </div>
            )}
          </div>
        </div>
      )}

      {/* Booking Success Modal Feedback */}
      {bookingSuccessModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="w-full max-w-lg rounded-2xl border border-emerald-500/50 bg-slate-900 p-6 shadow-2xl space-y-4">
            <div className="flex items-center gap-3">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-emerald-500/20 text-emerald-400">
                <CheckCircle2 className="h-6 w-6" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-white">Booking Confirmed Successfully!</h3>
                <p className="text-xs text-slate-400">
                  {bookingSuccessModal.seats.length} seat(s) reserved on {bookingSuccessModal.flight.flightNumber}
                </p>
              </div>
            </div>

            <div className="rounded-xl border border-slate-800 bg-slate-950/70 p-4 space-y-2 text-xs">
              <div className="flex justify-between text-slate-300">
                <span>Flight Route:</span>
                <span className="font-semibold text-white">
                  {bookingSuccessModal.flight.originCity} ({bookingSuccessModal.flight.originIata}) →{' '}
                  {bookingSuccessModal.flight.destinationCity} ({bookingSuccessModal.flight.destinationIata})
                </span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Reserved Seats:</span>
                <span className="font-mono font-bold text-emerald-400">
                  {bookingSuccessModal.seats.join(', ')}
                </span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Total Charged:</span>
                <span className="font-mono font-bold text-white">
                  ${bookingSuccessModal.totalPrice.toLocaleString()}
                </span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Booking Reference (PNR):</span>
                <span className="font-mono font-bold text-sky-400">
                  {bookingSuccessModal.pnrList.join(', ')}
                </span>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setBookingSuccessModal(null)}
                className="rounded-xl bg-sky-600 px-5 py-2 text-xs font-semibold text-white hover:bg-sky-500 transition-colors"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
