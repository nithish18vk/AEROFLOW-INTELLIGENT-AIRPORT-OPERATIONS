import React, { useState } from 'react';
import { FlightNotification, Flight } from '../types/aeroflow';
import {
  Bell,
  Send,
  MessageSquare,
  Radio,
  Mail,
  Smartphone,
  CheckCircle2,
  AlertTriangle,
} from 'lucide-react';

interface NotificationCenterProps {
  notifications: FlightNotification[];
  flights: Flight[];
  onBroadcastNotification: (
    flightId: string,
    title: string,
    message: string,
    channel: FlightNotification['channel'],
    priority: FlightNotification['priority']
  ) => void;
}

export const NotificationCenter: React.FC<NotificationCenterProps> = ({
  notifications,
  flights,
  onBroadcastNotification,
}) => {
  const [selectedFlightId, setSelectedFlightId] = useState(flights[0]?.id || '');
  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [channel, setChannel] = useState<FlightNotification['channel']>('PA_ANNOUNCEMENT');
  const [priority, setPriority] = useState<FlightNotification['priority']>('NORMAL');
  const [broadcastSuccess, setBroadcastSuccess] = useState(false);

  const handleBroadcast = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !message) return;

    onBroadcastNotification(selectedFlightId, title, message, channel, priority);
    setTitle('');
    setMessage('');
    setBroadcastSuccess(true);
    setTimeout(() => setBroadcastSuccess(false), 3000);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 rounded-xl border border-slate-800 bg-slate-900/60 p-6">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-sky-400">
            <Radio className="h-3.5 w-3.5" />
            <span>Flight Communications & PA Broadcaster</span>
            <span aria-hidden="true">·</span>
            <span>Java Var-args: notifyPassengers(String msg, Passenger... recipients)</span>
          </div>
          <h2 className="mt-1 text-2xl font-bold tracking-tight text-white">
            Passenger Flight Notification Hub
          </h2>
          <p className="mt-1 text-xs text-slate-300">
            Transmit gate announcements, delay alerts, and boarding calls via airport PA, SMS, or mobile push.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Form: Broadcast New Message */}
        <div className="lg:col-span-5 rounded-xl border border-slate-800 bg-slate-900/50 p-5 space-y-4">
          <h3 className="font-bold text-white text-sm flex items-center gap-2">
            <Send className="h-4 w-4 text-sky-400" />
            <span>Broadcast Flight Dispatch</span>
          </h3>

          {broadcastSuccess && (
            <div className="flex items-center gap-2 rounded-lg bg-emerald-950/80 p-3 text-xs text-emerald-300 border border-emerald-500/40">
              <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-400" />
              <span>Announcement dispatched successfully to all booked passengers!</span>
            </div>
          )}

          <form onSubmit={handleBroadcast} className="space-y-3.5 text-xs">
            <div>
              <label className="font-semibold text-slate-300">Target Flight:</label>
              <select
                value={selectedFlightId}
                onChange={(e) => setSelectedFlightId(e.target.value)}
                className="mt-1 w-full rounded border border-slate-700 bg-slate-950 px-3 py-1.5 text-white focus:border-sky-500 focus:outline-none"
              >
                {flights.map((f) => (
                  <option key={f.id} value={f.id}>
                    {f.flightNumber} ({f.originIata} → {f.destinationIata}) · {f.bookedSeats} Passengers
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="font-semibold text-slate-300">Transmission Channel:</label>
              <div className="mt-1 grid grid-cols-2 gap-2">
                {[
                  { id: 'PA_ANNOUNCEMENT', label: 'Airport PA System', icon: Radio },
                  { id: 'SMS', label: 'Passenger SMS', icon: MessageSquare },
                  { id: 'EMAIL', label: 'Direct Email', icon: Mail },
                  { id: 'APP_PUSH', label: 'Mobile App Push', icon: Smartphone },
                ].map((c) => {
                  const Icon = c.icon;
                  return (
                    <button
                      key={c.id}
                      type="button"
                      onClick={() => setChannel(c.id as any)}
                      className={`flex items-center gap-2 p-2 rounded-lg border text-left transition-all ${
                        channel === c.id
                          ? 'bg-sky-600/20 border-sky-500 text-sky-200'
                          : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      <Icon className="h-3.5 w-3.5" />
                      <span className="text-[11px] font-medium">{c.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            <div>
              <label className="font-semibold text-slate-300">Subject / Announcement Title:</label>
              <input
                type="text"
                required
                placeholder="e.g. Immediate Gate Change for Flight AF-402"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="mt-1 w-full rounded border border-slate-700 bg-slate-950 px-3 py-1.5 text-white focus:border-sky-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="font-semibold text-slate-300">Message Content:</label>
              <textarea
                required
                rows={3}
                placeholder="Enter flight operational update or boarding directive..."
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                className="mt-1 w-full rounded border border-slate-700 bg-slate-950 px-3 py-1.5 text-white focus:border-sky-500 focus:outline-none resize-none"
              />
            </div>

            <button
              type="submit"
              className="w-full rounded-lg bg-sky-600 py-2 font-bold text-white shadow hover:bg-sky-500 transition-colors"
            >
              Transmit Announcement
            </button>
          </form>
        </div>

        {/* Right List: Broadcast History */}
        <div className="lg:col-span-7 rounded-xl border border-slate-800 bg-slate-900/50 p-5 space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <h3 className="font-bold text-white text-sm flex items-center gap-2">
              <Bell className="h-4 w-4 text-sky-400" />
              <span>Broadcast Telemetry Log</span>
            </h3>
            <span className="font-mono text-xs text-slate-400">
              {notifications.length} Total Transmissions
            </span>
          </div>

          <div className="space-y-3 max-h-[440px] overflow-y-auto pr-1">
            {notifications.map((notif) => (
              <div
                key={notif.id}
                className="rounded-lg border border-slate-800 bg-slate-950/80 p-4 space-y-2 text-xs"
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <span className="font-mono text-sky-400 font-bold">
                      {notif.flightNumber || 'SYSTEM'}
                    </span>
                    <h4 className="font-bold text-white text-sm mt-0.5">
                      {notif.title}
                    </h4>
                  </div>
                  <div className="text-right">
                    <span className="font-mono text-[11px] text-slate-400">
                      {notif.timestamp}
                    </span>
                    <div className="text-[10px] text-slate-400 uppercase font-mono">
                      {notif.channel}
                    </div>
                  </div>
                </div>

                <p className="text-slate-300 leading-relaxed">
                  {notif.message}
                </p>

                <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-slate-800/80">
                  <span>Recipients Reached: {notif.sentToCount} Passengers</span>
                  <span className="font-mono text-emerald-400">Delivered</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
