import React, { useState } from 'react';
import { SPRING_BOOT_CODEBASE, CodeFile } from '../data/springBootCodebase';
import {
  FileCode,
  Terminal,
  Copy,
  Check,
  Download,
  Server,
  Cloud,
  Layers,
  ArrowRight,
  ExternalLink,
  Cpu,
  BookOpen,
  Boxes,
} from 'lucide-react';

export const SpringBootDeploymentHub: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<CodeFile>(SPRING_BOOT_CODEBASE[0]);
  const [copied, setCopied] = useState(false);
  const [activeSection, setActiveSection] = useState<'code' | 'instructions'>('instructions');

  const handleCopyCode = () => {
    navigator.clipboard.writeText(selectedFile.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadFile = () => {
    const blob = new Blob([selectedFile.code], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = selectedFile.name;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Hero Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 rounded-xl border border-slate-800 bg-slate-900/60 p-6">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-sky-400">
            <Server className="h-3.5 w-3.5" />
            <span>Full-Stack Enterprise Architecture & Production Runbook</span>
          </div>
          <h2 className="mt-1 text-2xl font-bold tracking-tight text-white">
            Spring Boot 3 + React Architecture & Deployment Hub
          </h2>
          <p className="mt-1 text-xs text-slate-300">
            Executable Java 21 Spring Boot source tree, REST endpoints, Docker multi-stage containers, and cloud deployment guides.
          </p>
        </div>

        {/* Section Tabs */}
        <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800">
          <button
            onClick={() => setActiveSection('instructions')}
            className={`rounded px-3 py-1.5 text-xs font-semibold transition-all ${
              activeSection === 'instructions'
                ? 'bg-sky-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            How to Run & Deploy
          </button>
          <button
            onClick={() => setActiveSection('code')}
            className={`rounded px-3 py-1.5 text-xs font-semibold transition-all ${
              activeSection === 'code'
                ? 'bg-sky-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Java Source Codebase
          </button>
        </div>
      </div>

      {/* SECTION 1: Step-by-Step Execution & Deployment Guide */}
      {activeSection === 'instructions' && (
        <div className="space-y-6">
          {/* Architecture Overview Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-5 space-y-2">
              <div className="flex items-center gap-2 text-sky-400 font-bold text-sm">
                <Boxes className="h-4 w-4" />
                <span>1. Presentation Tier</span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                React 19 SPA running on Vite. Interacts with backend via asynchronous Fetch / Axios clients with JWT Bearer tokens and CORS headers.
              </p>
              <div className="font-mono text-[11px] text-slate-400 pt-1">
                Port: 3000 · Client Routes
              </div>
            </div>

            <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-5 space-y-2">
              <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm">
                <Server className="h-4 w-4" />
                <span>2. Application Tier</span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                Spring Boot 3.3.x on Java 21. ReentrantLock concurrency control, Spring Data JPA, Hibernate, Bean Validation, and JUnit 5 tests.
              </p>
              <div className="font-mono text-[11px] text-slate-400 pt-1">
                Port: 8080 · /api/v1/* Endpoints
              </div>
            </div>

            <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-5 space-y-2">
              <div className="flex items-center gap-2 text-indigo-400 font-bold text-sm">
                <Cloud className="h-4 w-4" />
                <span>3. Persistence Tier</span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                PostgreSQL 16 relational database with ACID isolation, connection pooling via HikariCP, and in-memory H2 support for rapid local prototyping.
              </p>
              <div className="font-mono text-[11px] text-slate-400 pt-1">
                Port: 5432 · aeroflow_db
              </div>
            </div>
          </div>

          {/* Local Run Instructions */}
          <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-6 space-y-4">
            <h3 className="font-bold text-white text-base flex items-center gap-2">
              <Terminal className="h-4 w-4 text-sky-400" />
              <span>Step-by-Step Instructions: Running Locally</span>
            </h3>

            <div className="space-y-4 text-xs text-slate-300">
              <div className="space-y-1.5">
                <div className="font-bold text-slate-200">Prerequisites</div>
                <div className="text-slate-400">
                  Ensure you have installed: <strong>Java 21 JDK</strong> (Eclipse Temurin or OpenJDK), <strong>Maven 3.9+</strong>, <strong>Node.js 20+</strong>, and <strong>Docker Desktop</strong> (optional for PostgreSQL).
                </div>
              </div>

              {/* Step 1: Clone & Database */}
              <div className="space-y-1.5 border-t border-slate-800 pt-3">
                <div className="font-bold text-slate-200 flex items-center gap-2">
                  <span className="flex h-5 w-5 items-center justify-center rounded-full bg-sky-600 text-[10px] text-white font-mono">1</span>
                  <span>Start the Database (PostgreSQL or In-Memory H2)</span>
                </div>
                <p className="text-slate-400">
                  Option A: Quick Docker container command for PostgreSQL:
                </p>
                <div className="rounded-lg bg-slate-950 p-3 font-mono text-emerald-400 text-[11px] border border-slate-800 overflow-x-auto">
                  docker run --name aeroflow-pg -e POSTGRES_DB=aeroflow_db -e POSTGRES_USER=aeroflow_admin -e POSTGRES_PASSWORD=supersecretpassword123 -p 5432:5432 -d postgres:16-alpine
                </div>
                <p className="text-slate-400 text-[11px]">
                  Option B: Spring Boot will automatically fallback to in-memory H2 database if PostgreSQL is not active!
                </p>
              </div>

              {/* Step 2: Spring Boot Backend */}
              <div className="space-y-1.5 border-t border-slate-800 pt-3">
                <div className="font-bold text-slate-200 flex items-center gap-2">
                  <span className="flex h-5 w-5 items-center justify-center rounded-full bg-sky-600 text-[10px] text-white font-mono">2</span>
                  <span>Compile & Launch Spring Boot Backend</span>
                </div>
                <p className="text-slate-400">
                  Navigate into the backend project directory and execute Maven run:
                </p>
                <div className="rounded-lg bg-slate-950 p-3 font-mono text-emerald-400 text-[11px] border border-slate-800 overflow-x-auto space-y-1">
                  <div>cd backend</div>
                  <div>mvn clean package -DskipTests</div>
                  <div>mvn spring-boot:run</div>
                </div>
                <div className="text-slate-400 text-[11px]">
                  Backend will start on <span className="font-mono text-sky-400 font-semibold">http://localhost:8080</span>. Swagger / OpenAPI docs available at <span className="font-mono text-sky-400">http://localhost:8080/swagger-ui.html</span>.
                </div>
              </div>

              {/* Step 3: Run Unit & Concurrency Tests */}
              <div className="space-y-1.5 border-t border-slate-800 pt-3">
                <div className="font-bold text-slate-200 flex items-center gap-2">
                  <span className="flex h-5 w-5 items-center justify-center rounded-full bg-sky-600 text-[10px] text-white font-mono">3</span>
                  <span>Execute JUnit 5 Test Suite</span>
                </div>
                <div className="rounded-lg bg-slate-950 p-3 font-mono text-emerald-400 text-[11px] border border-slate-800 overflow-x-auto">
                  mvn test
                </div>
                <div className="text-slate-400 text-[11px]">
                  Verifies ReentrantLock thread-safety, double-booking prevention, gate allocation conflicts, and polymorphic pricing.
                </div>
              </div>

              {/* Step 4: React Frontend */}
              <div className="space-y-1.5 border-t border-slate-800 pt-3">
                <div className="font-bold text-slate-200 flex items-center gap-2">
                  <span className="flex h-5 w-5 items-center justify-center rounded-full bg-sky-600 text-[10px] text-white font-mono">4</span>
                  <span>Run React Frontend</span>
                </div>
                <div className="rounded-lg bg-slate-950 p-3 font-mono text-emerald-400 text-[11px] border border-slate-800 overflow-x-auto space-y-1">
                  <div>npm install</div>
                  <div>npm run dev</div>
                </div>
                <div className="text-slate-400 text-[11px]">
                  Frontend is reachable at <span className="font-mono text-sky-400 font-semibold">http://localhost:3000</span>.
                </div>
              </div>
            </div>
          </div>

          {/* Cloud Production Deployment Guide */}
          <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-6 space-y-4">
            <h3 className="font-bold text-white text-base flex items-center gap-2">
              <Cloud className="h-4 w-4 text-emerald-400" />
              <span>Production Cloud Deployment (Docker, AWS, GCP, Render)</span>
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div className="rounded-lg bg-slate-950 p-4 border border-slate-800 space-y-2">
                <div className="font-bold text-white flex items-center gap-1.5">
                  <span>Method 1: Docker Compose (All-in-One)</span>
                </div>
                <p className="text-slate-400 text-[11px]">
                  Spin up PostgreSQL, Spring Boot backend, and React frontend in isolated networked containers with a single command:
                </p>
                <div className="rounded bg-slate-900 p-2 font-mono text-emerald-400 text-[11px]">
                  docker compose up --build -d
                </div>
              </div>

              <div className="rounded-lg bg-slate-950 p-4 border border-slate-800 space-y-2">
                <div className="font-bold text-white flex items-center gap-1.5">
                  <span>Method 2: Google Cloud Run & Cloud SQL</span>
                </div>
                <p className="text-slate-400 text-[11px]">
                  Build container with Google Cloud Build and deploy serverless container:
                </p>
                <div className="rounded bg-slate-900 p-2 font-mono text-emerald-400 text-[11px]">
                  gcloud run deploy aeroflow-api --image gcr.io/PROJECT/aeroflow-api
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SECTION 2: Code Explorer */}
      {activeSection === 'code' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left File Tree Sidebar */}
          <div className="lg:col-span-4 rounded-xl border border-slate-800 bg-slate-900/60 p-4 space-y-2">
            <h3 className="font-bold text-white text-xs uppercase tracking-wider text-slate-400 px-2 mb-2">
              Spring Boot Project Files
            </h3>

            <div className="space-y-1">
              {SPRING_BOOT_CODEBASE.map((file) => (
                <button
                  key={file.path}
                  onClick={() => setSelectedFile(file)}
                  className={`w-full text-left rounded-lg px-3 py-2 text-xs transition-all flex items-start justify-between ${
                    selectedFile.path === file.path
                      ? 'bg-sky-600/20 border border-sky-500 text-sky-200 shadow-sm'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                  }`}
                >
                  <div className="truncate">
                    <div className="font-mono font-medium text-white truncate">
                      {file.name}
                    </div>
                    <div className="text-[10px] text-slate-400 truncate mt-0.5">
                      {file.category.toUpperCase()} · {file.language}
                    </div>
                  </div>
                  <FileCode className="h-4 w-4 shrink-0 mt-0.5 text-slate-500" />
                </button>
              ))}
            </div>
          </div>

          {/* Right Code Viewer */}
          <div className="lg:col-span-8 rounded-xl border border-slate-800 bg-slate-950 overflow-hidden shadow-2xl flex flex-col justify-between">
            {/* Top Toolbar */}
            <div className="flex items-center justify-between border-b border-slate-800 bg-slate-900/90 px-4 py-3">
              <div>
                <span className="font-mono text-xs font-bold text-sky-400">
                  {selectedFile.path}
                </span>
                <p className="text-[10px] text-slate-400 mt-0.5">
                  OOP Highlight: {selectedFile.oopConcept}
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleCopyCode}
                  className="flex items-center gap-1 rounded bg-slate-800 px-2.5 py-1 text-xs font-medium text-slate-200 hover:bg-slate-700 transition-colors"
                >
                  {copied ? (
                    <>
                      <Check className="h-3.5 w-3.5 text-emerald-400" />
                      <span className="text-emerald-400">Copied</span>
                    </>
                  ) : (
                    <>
                      <Copy className="h-3.5 w-3.5" />
                      <span>Copy</span>
                    </>
                  )}
                </button>

                <button
                  onClick={handleDownloadFile}
                  title="Download Java File"
                  className="rounded bg-slate-800 p-1 text-slate-300 hover:text-white"
                >
                  <Download className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>

            {/* Code Body */}
            <div className="overflow-x-auto p-4 max-h-[560px] font-mono text-xs text-slate-200 leading-relaxed">
              <pre className="whitespace-pre">{selectedFile.code}</pre>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
