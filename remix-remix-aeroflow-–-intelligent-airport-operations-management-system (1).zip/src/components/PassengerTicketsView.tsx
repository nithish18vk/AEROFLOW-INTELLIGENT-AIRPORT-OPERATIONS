import React, { useState } from 'react';
import { Ticket, Flight } from '../types/aeroflow';
import {
  Ticket as TicketIcon,
  Search,
  Plane,
  QrCode,
  Luggage,
  Calendar,
  CreditCard,
  CheckCircle2,
  AlertCircle,
  ExternalLink,
} from 'lucide-react';

interface PassengerTicketsViewProps {
  tickets: Ticket[];
  flights: Flight[];
  onOpenBoardingPass: (ticket: Ticket) => void;
  onBookMoreFlights: () => void;
}

export const PassengerTicketsView: React.FC<PassengerTicketsViewProps> = ({
  tickets,
  flights,
  onOpenBoardingPass,
  onBookMoreFlights,
}) => {
  const [searchPnr, setSearchPnr] = useState('');

  const filteredTickets = tickets.filter((t) => {
    const q = searchPnr.toLowerCase();
    return (
      t.pnr.toLowerCase().includes(q) ||
      t.passengerName.toLowerCase().includes(q) ||
      t.flightNumber.toLowerCase().includes(q)
    );
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-sky-400">
            <TicketIcon className="h-4 w-4" />
            <span>Passenger Reservations & Boarding Passes</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white mt-1">
            My Booked Flight Tickets
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            View booking references (PNR), assigned cabin seats, baggage allowance, and digital boarding passes.
          </p>
        </div>

        <button
          onClick={onBookMoreFlights}
          className="flex items-center gap-2 rounded-xl bg-sky-600 px-4 py-2.5 text-xs font-semibold text-white hover:bg-sky-500 transition-colors shadow-md w-fit"
        >
          <Plane className="h-4 w-4 -rotate-45" />
          <span>Book Another Flight</span>
        </button>
      </div>

      {/* PNR Search Filter */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-4 shadow-lg flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="relative w-full sm:max-w-md">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400 pointer-events-none" />
          <input
            type="text"
            placeholder="Search by 6-digit PNR (e.g. AF892X), passenger, or flight..."
            value={searchPnr}
            onChange={(e) => setSearchPnr(e.target.value)}
            className="w-full rounded-xl border border-slate-700 bg-slate-950 pl-9 pr-3 py-2 text-xs font-medium text-white placeholder-slate-500 focus:border-sky-500 focus:outline-none"
          />
        </div>

        <div className="text-xs text-slate-400">
          Showing <span className="text-white font-bold">{filteredTickets.length}</span> issued ticket(s)
        </div>
      </div>

      {/* Tickets List */}
      {filteredTickets.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-slate-800 bg-slate-900/40 p-12 text-center space-y-4">
          <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-slate-800 text-slate-500">
            <TicketIcon className="h-7 w-7" />
          </div>
          <div className="space-y-1">
            <h3 className="text-base font-bold text-white">No Tickets Found</h3>
            <p className="text-xs text-slate-400">
              No tickets matched your search criteria. Book a flight seat to generate a ticket.
            </p>
          </div>
          <button
            onClick={onBookMoreFlights}
            className="rounded-xl bg-sky-600 px-4 py-2 text-xs font-semibold text-white hover:bg-sky-500 transition-colors"
          >
            Go to Ticket Booking
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {filteredTickets.map((ticket) => {
            const flight = flights.find((f) => f.id === ticket.flightId) || flights[0];

            return (
              <div
                key={ticket.id}
                className="rounded-2xl border border-slate-800 bg-slate-900/70 p-5 shadow-xl flex flex-col justify-between space-y-4 hover:border-slate-700 transition-colors relative overflow-hidden"
              >
                {/* Top PNR Header */}
                <div className="flex items-start justify-between border-b border-slate-800 pb-3">
                  <div>
                    <span className="text-[10px] text-slate-500 uppercase font-semibold block">
                      Booking Reference (PNR)
                    </span>
                    <span className="text-xl font-mono font-bold text-sky-400 tracking-wider">
                      {ticket.pnr}
                    </span>
                  </div>

                  <span
                    className={`rounded-full px-2.5 py-0.5 text-[10px] font-bold font-mono uppercase ${
                      ticket.status === 'BOARDED'
                        ? 'bg-purple-500/20 text-purple-300 border border-purple-500/40'
                        : ticket.status === 'CHECKED_IN'
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                        : 'bg-sky-500/20 text-sky-300 border border-sky-500/40'
                    }`}
                  >
                    {ticket.status}
                  </span>
                </div>

                {/* Flight & Passenger Info */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-xs text-slate-400">Passenger</div>
                      <div className="text-sm font-bold text-white">{ticket.passengerName}</div>
                    </div>
                    <div className="text-right">
                      <div className="text-xs text-slate-400">Travel Class</div>
                      <div className="text-sm font-bold text-amber-300 font-mono">
                        {ticket.travelClass} CLASS
                      </div>
                    </div>
                  </div>

                  {/* Route Bar */}
                  <div className="rounded-xl border border-slate-800 bg-slate-950 p-3 flex items-center justify-between">
                    <div>
                      <span className="text-xs font-mono font-bold text-white">
                        {flight.originIata} ({flight.originCity})
                      </span>
                      <div className="text-[10px] text-sky-400 font-mono mt-0.5">
                        Dep: {flight.scheduledDeparture}
                      </div>
                    </div>

                    <div className="flex flex-col items-center px-2">
                      <span className="text-[10px] font-mono font-bold text-white">
                        {ticket.flightNumber}
                      </span>
                      <Plane className="h-3.5 w-3.5 text-slate-500 -rotate-45 my-0.5" />
                      <span className="text-[10px] text-slate-400">
                        Gate {flight.gateNumber || 'TBD'}
                      </span>
                    </div>

                    <div className="text-right">
                      <span className="text-xs font-mono font-bold text-white">
                        {flight.destinationIata} ({flight.destinationCity})
                      </span>
                      <div className="text-[10px] text-emerald-400 font-mono mt-0.5">
                        Arr: {flight.scheduledArrival}
                      </div>
                    </div>
                  </div>

                  {/* Seat, Baggage, & Price */}
                  <div className="grid grid-cols-3 gap-2 text-center text-xs">
                    <div className="rounded-lg bg-slate-950/80 p-2 border border-slate-800">
                      <span className="text-[10px] text-slate-500 uppercase block">Seat</span>
                      <span className="text-sm font-mono font-bold text-emerald-400">
                        {ticket.seatNumber}
                      </span>
                    </div>

                    <div className="rounded-lg bg-slate-950/80 p-2 border border-slate-800">
                      <span className="text-[10px] text-slate-500 uppercase block">Baggage</span>
                      <span className="text-sm font-mono font-bold text-white">
                        {ticket.baggageAllowanceKg} kg
                      </span>
                    </div>

                    <div className="rounded-lg bg-slate-950/80 p-2 border border-slate-800">
                      <span className="text-[10px] text-slate-500 uppercase block">Fare Paid</span>
                      <span className="text-sm font-mono font-bold text-white">
                        ${ticket.price}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Action CTA */}
                <div className="border-t border-slate-800 pt-3 flex items-center justify-between">
                  <div className="text-[11px] text-slate-500 font-mono">
                    Issued: {new Date(ticket.bookingTimestamp).toLocaleDateString()}
                  </div>

                  <button
                    onClick={() => onOpenBoardingPass(ticket)}
                    className="flex items-center gap-1.5 rounded-xl bg-slate-800 border border-slate-700 px-3.5 py-1.5 text-xs font-semibold text-sky-300 hover:bg-sky-600 hover:text-white hover:border-sky-500 transition-colors shadow-sm"
                  >
                    <QrCode className="h-3.5 w-3.5" />
                    <span>View Boarding Pass</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
