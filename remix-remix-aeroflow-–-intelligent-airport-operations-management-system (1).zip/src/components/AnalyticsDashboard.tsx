import React from 'react';
import { Flight, Ticket, Gate, Baggage } from '../types/aeroflow';
import {
  TrendingUp,
  Clock,
  DollarSign,
  Users,
  Luggage,
  ShieldCheck,
  Plane,
  Layers,
} from 'lucide-react';

interface AnalyticsDashboardProps {
  flights: Flight[];
  tickets: Ticket[];
  gates: Gate[];
  baggage: Baggage[];
}

export const AnalyticsDashboard: React.FC<AnalyticsDashboardProps> = ({
  flights,
  tickets,
  gates,
  baggage,
}) => {
  // Aggregate Metrics
  const totalFlights = flights.length;
  const delayedFlights = flights.filter((f) => f.status === 'DELAYED').length;
  const otp = totalFlights > 0 ? Math.round(((totalFlights - delayedFlights) / totalFlights) * 100) : 100;

  const totalRevenue = tickets
    .filter((t) => t.status !== 'CANCELLED')
    .reduce((acc, t) => acc + t.price, 0);

  const occupiedGates = gates.filter((g) => g.status === 'OCCUPIED').length;
  const gateUtilization = Math.round((occupiedGates / gates.length) * 100);

  const firstClassRev = tickets
    .filter((t) => t.travelClass === 'FIRST' && t.status !== 'CANCELLED')
    .reduce((acc, t) => acc + t.price, 0);
  const businessRev = tickets
    .filter((t) => t.travelClass === 'BUSINESS' && t.status !== 'CANCELLED')
    .reduce((acc, t) => acc + t.price, 0);
  const economyRev = tickets
    .filter((t) => t.travelClass === 'ECONOMY' && t.status !== 'CANCELLED')
    .reduce((acc, t) => acc + t.price, 0);

  const firstPercent = totalRevenue > 0 ? Math.round((firstClassRev / totalRevenue) * 100) : 0;
  const businessPercent = totalRevenue > 0 ? Math.round((businessRev / totalRevenue) * 100) : 0;
  const economyPercent = totalRevenue > 0 ? Math.round((economyRev / totalRevenue) * 100) : 0;

  const deliveredBags = baggage.filter((b) => b.status === 'CAROUSEL_UNLOADED' || b.status === 'CLAIMED').length;
  const bagSuccessRate = baggage.length > 0 ? Math.round((deliveredBags / baggage.length) * 100) : 100;

  return (
    <div className="space-y-6">
      {/* Analytics Banner */}
      <div className="relative overflow-hidden rounded-xl border border-slate-800 bg-slate-900/60 shadow-lg">
        <div className="relative h-44 sm:h-48 w-full overflow-hidden bg-slate-950">
          <img
            src="/src/assets/images/aeroflow_control_deck_1791179023223.jpg"
            alt="AeroFlow AOCC"
            referrerPolicy="no-referrer"
            className="h-full w-full object-cover opacity-40 mix-blend-luminosity"
            onError={(e) => {
              (e.target as HTMLElement).style.display = 'none';
            }}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/60 to-transparent" />

          <div className="absolute inset-0 flex flex-col justify-end p-6">
            <div className="flex items-center gap-2 text-xs font-semibold text-sky-400">
              <TrendingUp className="h-3.5 w-3.5" />
              <span>Executive Telemetry & Terminal Yield</span>
            </div>
            <h2 className="mt-1 text-2xl font-bold tracking-tight text-white">
              Airport Operations Analytics
            </h2>
            <p className="mt-1 text-xs text-slate-300 max-w-xl">
              Real-time on-time performance (OTP), revenue breakdown by cabin tier, gate turnaround cycle, and baggage handling SLA.
            </p>
          </div>
        </div>
      </div>

      {/* 4 Metric KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-4">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>On-Time Performance</span>
            <Clock className="h-4 w-4 text-emerald-400" />
          </div>
          <div className="mt-2 font-mono text-2xl font-bold text-emerald-400 tabular-nums">
            {otp}%
          </div>
          <div className="mt-1 text-[11px] text-slate-400">
            Target: &gt;85% · IATA Level 1 Standard
          </div>
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-4">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Gross Ticket Revenue</span>
            <DollarSign className="h-4 w-4 text-sky-400" />
          </div>
          <div className="mt-2 font-mono text-2xl font-bold text-white tabular-nums">
            ${totalRevenue.toLocaleString()}
          </div>
          <div className="mt-1 text-[11px] text-slate-400">
            Across {tickets.length} processed bookings
          </div>
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-4">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Apron Gate Occupancy</span>
            <Layers className="h-4 w-4 text-amber-400" />
          </div>
          <div className="mt-2 font-mono text-2xl font-bold text-amber-400 tabular-nums">
            {gateUtilization}%
          </div>
          <div className="mt-1 text-[11px] text-slate-400">
            {occupiedGates} of {gates.length} Gates in Active Service
          </div>
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-4">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Baggage Delivery SLA</span>
            <Luggage className="h-4 w-4 text-indigo-400" />
          </div>
          <div className="mt-2 font-mono text-2xl font-bold text-indigo-400 tabular-nums">
            {bagSuccessRate}%
          </div>
          <div className="mt-1 text-[11px] text-slate-400">
            {baggage.length} Monitored Pieces (0 Lost)
          </div>
        </div>
      </div>

      {/* Revenue Distribution & Turnaround Times */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left: Revenue Distribution by Travel Class */}
        <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-5 space-y-4">
          <h3 className="text-sm font-bold text-white">
            Yield by Cabin Travel Class
          </h3>
          <p className="text-xs text-slate-400">
            Dynamic pricing calculation based on cabin tier and frequent flyer loyalty program.
          </p>

          <div className="space-y-3 pt-2">
            <div>
              <div className="flex justify-between text-xs text-slate-300 font-medium mb-1">
                <span className="flex items-center gap-1.5 text-amber-400">
                  <span className="h-2.5 w-2.5 rounded-full bg-amber-400 inline-block" />
                  First Class Suites
                </span>
                <span className="font-mono tabular-nums text-white">
                  ${firstClassRev.toLocaleString()} ({firstPercent}%)
                </span>
              </div>
              <div className="h-2 w-full rounded-full bg-slate-800 overflow-hidden">
                <div className="h-full bg-amber-400" style={{ width: `${firstPercent}%` }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs text-slate-300 font-medium mb-1">
                <span className="flex items-center gap-1.5 text-sky-400">
                  <span className="h-2.5 w-2.5 rounded-full bg-sky-400 inline-block" />
                  Business Class Pods
                </span>
                <span className="font-mono tabular-nums text-white">
                  ${businessRev.toLocaleString()} ({businessPercent}%)
                </span>
              </div>
              <div className="h-2 w-full rounded-full bg-slate-800 overflow-hidden">
                <div className="h-full bg-sky-400" style={{ width: `${businessPercent}%` }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs text-slate-300 font-medium mb-1">
                <span className="flex items-center gap-1.5 text-slate-300">
                  <span className="h-2.5 w-2.5 rounded-full bg-slate-400 inline-block" />
                  Main Cabin Economy
                </span>
                <span className="font-mono tabular-nums text-white">
                  ${economyRev.toLocaleString()} ({economyPercent}%)
                </span>
              </div>
              <div className="h-2 w-full rounded-full bg-slate-800 overflow-hidden">
                <div className="h-full bg-slate-500" style={{ width: `${economyPercent}%` }} />
              </div>
            </div>
          </div>
        </div>

        {/* Right: Operational Turnaround Times */}
        <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-5 space-y-4">
          <h3 className="text-sm font-bold text-white">
            Wide-Body Aircraft Turnaround Efficiency
          </h3>
          <p className="text-xs text-slate-400">
            Average gate dwell time from deplaning to pushback clearance.
          </p>

          <div className="grid grid-cols-2 gap-3 pt-2 text-xs">
            <div className="rounded-lg bg-slate-950 p-3 border border-slate-800">
              <div className="text-[10px] text-slate-400 uppercase font-medium">Boeing 787-9</div>
              <div className="font-mono text-xl font-bold text-sky-400 mt-1">
                58 min
              </div>
              <div className="text-[10px] text-slate-400 mt-0.5">SLA Target: 65 min</div>
            </div>

            <div className="rounded-lg bg-slate-950 p-3 border border-slate-800">
              <div className="text-[10px] text-slate-400 uppercase font-medium">Airbus A350-900</div>
              <div className="font-mono text-xl font-bold text-sky-400 mt-1">
                62 min
              </div>
              <div className="text-[10px] text-slate-400 mt-0.5">SLA Target: 70 min</div>
            </div>

            <div className="rounded-lg bg-slate-950 p-3 border border-slate-800">
              <div className="text-[10px] text-slate-400 uppercase font-medium">Boeing 737 MAX</div>
              <div className="font-mono text-xl font-bold text-emerald-400 mt-1">
                34 min
              </div>
              <div className="text-[10px] text-slate-400 mt-0.5">SLA Target: 40 min</div>
            </div>

            <div className="rounded-lg bg-slate-950 p-3 border border-slate-800">
              <div className="text-[10px] text-slate-400 uppercase font-medium">Boeing 747-8F Cargo</div>
              <div className="font-mono text-xl font-bold text-amber-400 mt-1">
                110 min
              </div>
              <div className="text-[10px] text-slate-400 mt-0.5">Palletized Freight Load</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
