import React from 'react';
import {
  Flight,
  Gate,
  PassengerAircraft,
  CargoAircraft,
  Staff,
  Ticket,
  Baggage,
  EmergencyIncident,
  FlightBaggageManifest,
} from '../types/aeroflow';
import {
  ShieldAlert,
  Plane,
  Layers,
  Luggage,
  Users,
  BarChart3,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  TrendingUp,
  Cpu,
  Clock,
  Compass,
} from 'lucide-react';
import { ActiveTab } from './Navbar';

interface ManagementHubViewProps {
  flights: Flight[];
  gates: Gate[];
  passengerFleet: PassengerAircraft[];
  cargoFleet: CargoAircraft[];
  staff: Staff[];
  tickets: Ticket[];
  baggage: Baggage[];
  baggageManifests: FlightBaggageManifest[];
  incidents: EmergencyIncident[];
  onNavigateToTab: (tab: ActiveTab) => void;
}

export const ManagementHubView: React.FC<ManagementHubViewProps> = ({
  flights,
  gates,
  passengerFleet,
  cargoFleet,
  staff,
  tickets,
  baggage,
  baggageManifests,
  incidents,
  onNavigateToTab,
}) => {
  const activeIncidents = incidents.filter((i) => i.status === 'ACTIVE');
  const delayedFlights = flights.filter((f) => f.status === 'DELAYED');
  const occupiedGates = gates.filter((g) => g.status === 'OCCUPIED');
  const staffEligibleRest = staff.filter((s) => s.restHoursCompleted >= 8);
  const totalBagsProcessed = baggageManifests.reduce((acc, m) => acc + m.totalBags, 0);

  const totalSeats = flights.reduce((sum, f) => sum + f.totalSeats, 0);
  const bookedSeats = flights.reduce((sum, f) => sum + f.bookedSeats, 0);
  const totalRevenue = tickets.reduce((sum, t) => sum + t.price, 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-sky-400">
            <Cpu className="h-4 w-4" />
            <span>Airport Operations Control Center (AOCC)</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white mt-1">
            Airport Operations Management Hub
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Executive command overview, terminal capacity metrics, crew rest compliance, and department controls.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="rounded-xl border border-emerald-500/30 bg-emerald-950/40 px-3.5 py-1.5 text-xs font-semibold text-emerald-300 flex items-center gap-1.5">
            <CheckCircle2 className="h-3.5 w-3.5" />
            <span>AeroFlow Systems Nominal</span>
          </span>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="rounded-xl border border-slate-800 bg-slate-900/80 p-3.5">
          <span className="text-[10px] font-semibold text-slate-400 uppercase block">Total Flights</span>
          <span className="text-xl font-bold text-white font-mono">{flights.length}</span>
          <span className="text-[10px] text-sky-400 block mt-0.5">
            {flights.filter((f) => f.status === 'BOARDING' || f.status === 'SCHEDULED').length} Active
          </span>
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-900/80 p-3.5">
          <span className="text-[10px] font-semibold text-slate-400 uppercase block">Delays</span>
          <span className={`text-xl font-bold font-mono ${delayedFlights.length > 0 ? 'text-amber-400' : 'text-emerald-400'}`}>
            {delayedFlights.length}
          </span>
          <span className="text-[10px] text-slate-400 block mt-0.5">
            {Math.round(((flights.length - delayedFlights.length) / flights.length) * 100)}% On-Time
          </span>
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-900/80 p-3.5">
          <span className="text-[10px] font-semibold text-slate-400 uppercase block">Gate Occupancy</span>
          <span className="text-xl font-bold text-sky-400 font-mono">
            {occupiedGates.length} / {gates.length}
          </span>
          <span className="text-[10px] text-slate-400 block mt-0.5">
            {Math.round((occupiedGates.length / gates.length) * 100)}% Utilized
          </span>
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-900/80 p-3.5">
          <span className="text-[10px] font-semibold text-slate-400 uppercase block">Passenger Load</span>
          <span className="text-xl font-bold text-emerald-400 font-mono">
            {bookedSeats} / {totalSeats}
          </span>
          <span className="text-[10px] text-slate-400 block mt-0.5">
            {Math.round((bookedSeats / (totalSeats || 1)) * 100)}% Load Factor
          </span>
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-900/80 p-3.5">
          <span className="text-[10px] font-semibold text-slate-400 uppercase block">Bags Processed</span>
          <span className="text-xl font-bold text-purple-400 font-mono">
            {totalBagsProcessed.toLocaleString()}
          </span>
          <span className="text-[10px] text-slate-400 block mt-0.5">
            {baggageManifests.length} Bulk Manifests
          </span>
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-900/80 p-3.5">
          <span className="text-[10px] font-semibold text-slate-400 uppercase block">Crew Rest SLA</span>
          <span className="text-xl font-bold text-sky-400 font-mono">
            {staffEligibleRest.length} / {staff.length}
          </span>
          <span className="text-[10px] text-emerald-400 block mt-0.5">≥ 8h Rest Rule Met</span>
        </div>
      </div>

      {/* Emergency Alert Banner if any */}
      {activeIncidents.length > 0 && (
        <div className="rounded-2xl border border-rose-500/50 bg-rose-950/40 p-4 sm:p-5 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-rose-600 text-white shrink-0">
              <AlertTriangle className="h-5 w-5 animate-pulse" />
            </div>
            <div>
              <div className="text-sm font-bold text-rose-200">
                Active Airport Emergency Incident: {activeIncidents[0].type.replace('_', ' ')}
              </div>
              <p className="text-xs text-rose-300/80 mt-0.5">
                Flight {activeIncidents[0].flightNumber} · Declared by {activeIncidents[0].declaredByName} ({activeIncidents[0].declaredByRole})
              </p>
            </div>
          </div>

          <button
            onClick={() => onNavigateToTab('emergency')}
            className="rounded-xl bg-rose-600 px-4 py-2 text-xs font-semibold text-white hover:bg-rose-500 transition-colors shrink-0 shadow-md"
          >
            Open Emergency Command
          </button>
        </div>
      )}

      {/* Direct Department Shortcuts */}
      <div className="space-y-3">
        <h2 className="text-sm font-semibold text-slate-300">
          Executive Department Management Shortcuts
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
          <button
            onClick={() => onNavigateToTab('flights')}
            className="group rounded-2xl border border-slate-800 bg-slate-900/60 p-4 text-left hover:border-sky-500/50 hover:bg-slate-900 transition-all flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-sky-950 border border-sky-800/60 text-sky-400">
                  <Plane className="h-4 w-4" />
                </div>
                <ArrowRight className="h-4 w-4 text-slate-500 group-hover:text-sky-400 group-hover:translate-x-0.5 transition-all" />
              </div>
              <div className="text-sm font-bold text-white group-hover:text-sky-300">Flights Module</div>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                Add new flights, report weather & ATC delays, modify flight statuses, and inspect scheduled air traffic.
              </p>
            </div>
            <div className="mt-3 pt-2 border-t border-slate-800 text-[11px] font-mono text-sky-400">
              {flights.length} flights tracked →
            </div>
          </button>

          <button
            onClick={() => onNavigateToTab('crew')}
            className="group rounded-2xl border border-slate-800 bg-slate-900/60 p-4 text-left hover:border-sky-500/50 hover:bg-slate-900 transition-all flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-indigo-950 border border-indigo-800/60 text-indigo-400">
                  <Users className="h-4 w-4" />
                </div>
                <ArrowRight className="h-4 w-4 text-slate-500 group-hover:text-sky-400 group-hover:translate-x-0.5 transition-all" />
              </div>
              <div className="text-sm font-bold text-white group-hover:text-indigo-300">Crew & Rest Rules</div>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                Mandatory 8h minimum rest compliance, FDP daily duty caps, pilot pairing, and medical cert validation.
              </p>
            </div>
            <div className="mt-3 pt-2 border-t border-slate-800 text-[11px] font-mono text-indigo-400">
              {staff.length} staff rostered →
            </div>
          </button>

          <button
            onClick={() => onNavigateToTab('gates')}
            className="group rounded-2xl border border-slate-800 bg-slate-900/60 p-4 text-left hover:border-sky-500/50 hover:bg-slate-900 transition-all flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-emerald-950 border border-emerald-800/60 text-emerald-400">
                  <Layers className="h-4 w-4" />
                </div>
                <ArrowRight className="h-4 w-4 text-slate-500 group-hover:text-sky-400 group-hover:translate-x-0.5 transition-all" />
              </div>
              <div className="text-sm font-bold text-white group-hover:text-emerald-300">Gates & Terminals</div>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                T-48h gate assignment window, supervisor confirmation approvals, jetbridge wingspan checks, and apron moves.
              </p>
            </div>
            <div className="mt-3 pt-2 border-t border-slate-800 text-[11px] font-mono text-emerald-400">
              {gates.length} gates across T1-T3 →
            </div>
          </button>

          <button
            onClick={() => onNavigateToTab('baggage')}
            className="group rounded-2xl border border-slate-800 bg-slate-900/60 p-4 text-left hover:border-sky-500/50 hover:bg-slate-900 transition-all flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-amber-950 border border-amber-800/60 text-amber-400">
                  <Luggage className="h-4 w-4" />
                </div>
                <ArrowRight className="h-4 w-4 text-slate-500 group-hover:text-sky-400 group-hover:translate-x-0.5 transition-all" />
              </div>
              <div className="text-sm font-bold text-white group-hover:text-amber-300">Baggage Operations</div>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                Bulk flight manifests (100–500+ bags), ULD container balancing, conveyor carousel unloading, and RFID tracking.
              </p>
            </div>
            <div className="mt-3 pt-2 border-t border-slate-800 text-[11px] font-mono text-amber-400">
              {baggageManifests.length} manifests active →
            </div>
          </button>

          <button
            onClick={() => onNavigateToTab('emergency')}
            className="group rounded-2xl border border-slate-800 bg-slate-900/60 p-4 text-left hover:border-rose-500/50 hover:bg-slate-900 transition-all flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-rose-950 border border-rose-800/60 text-rose-400">
                  <ShieldAlert className="h-4 w-4" />
                </div>
                <ArrowRight className="h-4 w-4 text-slate-500 group-hover:text-rose-400 group-hover:translate-x-0.5 transition-all" />
              </div>
              <div className="text-sm font-bold text-white group-hover:text-rose-300">Emergency Command</div>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                ICAO declared incident responses, crash-fire-rescue unit dispatch, runway holds, and live operation fixes.
              </p>
            </div>
            <div className="mt-3 pt-2 border-t border-slate-800 text-[11px] font-mono text-rose-400">
              {incidents.length} logged incidents →
            </div>
          </button>

          <button
            onClick={() => onNavigateToTab('analytics')}
            className="group rounded-2xl border border-slate-800 bg-slate-900/60 p-4 text-left hover:border-cyan-500/50 hover:bg-slate-900 transition-all flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-cyan-950 border border-cyan-800/60 text-cyan-400">
                  <BarChart3 className="h-4 w-4" />
                </div>
                <ArrowRight className="h-4 w-4 text-slate-500 group-hover:text-cyan-400 group-hover:translate-x-0.5 transition-all" />
              </div>
              <div className="text-sm font-bold text-white group-hover:text-cyan-300">AOCC Analytics</div>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                On-time performance telemetry, load factor yield curves, baggage SLA tracking, and runway turnaround times.
              </p>
            </div>
            <div className="mt-3 pt-2 border-t border-slate-800 text-[11px] font-mono text-cyan-400">
              Revenue: ${totalRevenue.toLocaleString()} →
            </div>
          </button>
        </div>
      </div>
    </div>
  );
};
