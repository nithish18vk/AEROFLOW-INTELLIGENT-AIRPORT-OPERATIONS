import React, { useState } from 'react';
import { Staff, DutyStatus, Flight } from '../types/aeroflow';
import {
  Users,
  Clock,
  ShieldCheck,
  AlertCircle,
  FileBadge,
  CheckCircle2,
  PlusCircle,
} from 'lucide-react';

interface CrewManagerProps {
  staffList: Staff[];
  flights: Flight[];
  onToggleDutyStatus: (staffId: string, nextStatus: DutyStatus) => void;
  onLogCrewRestHours: (staffId: string, additionalHours: number) => void;
  onAssignFlight: (staffId: string, flightId: string) => void;
}

export const MINIMUM_REST_HOURS = 8.0;

export const CrewManager: React.FC<CrewManagerProps> = ({
  staffList,
  flights,
  onToggleDutyStatus,
  onLogCrewRestHours,
  onAssignFlight,
}) => {
  const [roleFilter, setRoleFilter] = useState<'ALL' | Staff['role']>('ALL');
  const [ruleViolationMessage, setRuleViolationMessage] = useState<string | null>(null);
  const [ruleSuccessMessage, setRuleSuccessMessage] = useState<string | null>(null);

  const filteredStaff = staffList.filter(
    (s) => roleFilter === 'ALL' || s.role === roleFilter
  );

  const onDutyCount = staffList.filter((s) => s.dutyStatus === 'ON_DUTY').length;
  const eligibleCount = staffList.filter(
    (s) =>
      s.restHoursCompleted >= MINIMUM_REST_HOURS &&
      s.currentShiftHours < s.maxDailyDutyHours &&
      s.medicalCertValid
  ).length;
  const belowRestCount = staffList.filter(
    (s) => s.restHoursCompleted < MINIMUM_REST_HOURS
  ).length;

  const checkEligibility = (staff: Staff): { eligible: boolean; reason?: string } => {
    if (staff.restHoursCompleted < MINIMUM_REST_HOURS) {
      const deficit = (MINIMUM_REST_HOURS - staff.restHoursCompleted).toFixed(1);
      return {
        eligible: false,
        reason: `CrewEligibilityException (8-Hour Rest Rule): ${staff.fullName} (${staff.role.replace(
          '_',
          ' '
        )}) has only ${staff.restHoursCompleted}h of rest. Pilots and crew must have at least 8.0 hours of rest before duty (${deficit}h more rest required).`,
      };
    }
    if (staff.currentShiftHours >= staff.maxDailyDutyHours) {
      return {
        eligible: false,
        reason: `CrewEligibilityException (Max FDP): ${staff.fullName} has reached maximum daily duty limit (${staff.currentShiftHours}h / ${staff.maxDailyDutyHours}h).`,
      };
    }
    if (!staff.medicalCertValid) {
      return {
        eligible: false,
        reason: `CrewEligibilityException: ${staff.fullName} does not hold an active Class 1 Medical Certificate.`,
      };
    }
    return { eligible: true };
  };

  const handleDutyStateChange = (staff: Staff, targetStatus: DutyStatus) => {
    setRuleViolationMessage(null);
    setRuleSuccessMessage(null);

    if (targetStatus === 'ON_DUTY') {
      const check = checkEligibility(staff);
      if (!check.eligible) {
        setRuleViolationMessage(check.reason || 'Ineligible for duty.');
        return;
      }
      setRuleSuccessMessage(
        `${staff.fullName} verified eligible (${staff.restHoursCompleted}h rest ≥ 8.0h minimum) and placed ON DUTY.`
      );
    }

    onToggleDutyStatus(staff.id, targetStatus);
  };

  const handleFlightPairingChange = (staff: Staff, flightId: string) => {
    setRuleViolationMessage(null);
    setRuleSuccessMessage(null);

    if (!flightId) {
      onAssignFlight(staff.id, '');
      return;
    }

    const check = checkEligibility(staff);
    if (!check.eligible) {
      setRuleViolationMessage(check.reason || 'Crew member ineligible for flight pairing.');
      return;
    }

    const targetFlight = flights.find((f) => f.id === flightId);
    if (targetFlight) {
      onAssignFlight(staff.id, flightId);
      if (staff.dutyStatus !== 'ON_DUTY') {
        onToggleDutyStatus(staff.id, 'ON_DUTY');
      }
      setRuleSuccessMessage(
        `Assigned ${staff.fullName} (${staff.restHoursCompleted}h rest verified) to Flight ${targetFlight.flightNumber}.`
      );
    }
  };

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 rounded-xl border border-slate-800 bg-slate-900/60 p-6">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-sky-400">
            <Users className="h-3.5 w-3.5" />
            <span>Flight Crew Rostering & Mandatory Rest Compliance</span>
          </div>
          <h2 className="mt-1 text-2xl font-bold tracking-tight text-white">
            Crew Eligibility & 8-Hour Rest Enforcement
          </h2>
          <p className="mt-1 text-xs text-slate-300 max-w-2xl">
            Enforces FAA Part 117 / ICAO flight duty rules: pilots and crew must complete at least 8.0 hours of uninterrupted rest before duty or flight assignment.
          </p>
        </div>

        <div className="flex items-center gap-4 bg-slate-950 p-3 rounded-lg border border-slate-800">
          <div className="text-center px-2">
            <div className="text-[10px] text-slate-400 uppercase font-medium">On Duty</div>
            <div className="font-mono text-lg font-bold text-emerald-400 tabular-nums">
              {onDutyCount}
            </div>
          </div>
          <div className="h-8 w-px bg-slate-800" />
          <div className="text-center px-2">
            <div className="text-[10px] text-slate-400 uppercase font-medium">Eligible (≥8h Rest)</div>
            <div className="font-mono text-lg font-bold text-sky-400 tabular-nums">
              {eligibleCount}
            </div>
          </div>
          <div className="h-8 w-px bg-slate-800" />
          <div className="text-center px-2">
            <div className="text-[10px] text-slate-400 uppercase font-medium">Rest Deficit (&lt;8h)</div>
            <div className="font-mono text-lg font-bold text-amber-400 tabular-nums">
              {belowRestCount}
            </div>
          </div>
        </div>
      </div>

      {/* Crew Eligibility Rules Specification Box */}
      <div className="rounded-xl border border-slate-800 bg-slate-900/40 p-4 grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
        <div className="flex items-start gap-2.5">
          <ShieldCheck className="h-4 w-4 text-emerald-400 shrink-0 mt-0.5" />
          <div>
            <div className="font-bold text-white">Rule 1: Mandatory 8-Hour Pilot Rest</div>
            <p className="text-slate-400 mt-0.5">
              Pilots, First Officers, and Cabin Crew must log <span className="text-slate-200 font-mono">≥ 8.0 hours</span> of rest before entering <span className="font-mono text-slate-200">ON_DUTY</span> state or pairing with any flight.
            </p>
          </div>
        </div>
        <div className="flex items-start gap-2.5">
          <Clock className="h-4 w-4 text-sky-400 shrink-0 mt-0.5" />
          <div>
            <div className="font-bold text-white">Rule 2: Max Flight Duty Period (FDP)</div>
            <p className="text-slate-400 mt-0.5">
              Cockpit crew active shift duration cannot exceed <span className="text-slate-200 font-mono">10.0 hours</span> continuous flight duty within a 24-hour window.
            </p>
          </div>
        </div>
        <div className="flex items-start gap-2.5">
          <FileBadge className="h-4 w-4 text-amber-400 shrink-0 mt-0.5" />
          <div>
            <div className="font-bold text-white">Rule 3: ATP License & Aircraft Rating</div>
            <p className="text-slate-400 mt-0.5">
              Crew must hold a valid ATP/CPL license, active medical certificate, and airframe qualification for the assigned aircraft.
            </p>
          </div>
        </div>
      </div>

      {/* Feedback Banner for Rule Enforcement */}
      {ruleViolationMessage && (
        <div className="flex items-start justify-between gap-3 rounded-xl border border-rose-500/50 bg-rose-950/80 p-4 text-xs text-rose-200">
          <div className="flex items-start gap-2.5">
            <AlertCircle className="h-4 w-4 text-rose-400 shrink-0 mt-0.5" />
            <div>
              <div className="font-bold text-white">Crew Eligibility Rule Violation Blocked Action</div>
              <div className="mt-0.5">{ruleViolationMessage}</div>
            </div>
          </div>
          <button
            onClick={() => setRuleViolationMessage(null)}
            className="text-rose-300 hover:text-white font-semibold"
          >
            Dismiss
          </button>
        </div>
      )}

      {ruleSuccessMessage && (
        <div className="flex items-center justify-between gap-3 rounded-xl border border-emerald-500/40 bg-emerald-950/60 p-3.5 text-xs text-emerald-200">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
            <span>{ruleSuccessMessage}</span>
          </div>
          <button
            onClick={() => setRuleSuccessMessage(null)}
            className="text-emerald-300 hover:text-white font-semibold"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Role Filter Tabs */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-800 pb-3">
        {[
          { id: 'ALL', label: 'All Personnel' },
          { id: 'PILOT', label: 'Captains / Pilots' },
          { id: 'FIRST_OFFICER', label: 'First Officers' },
          { id: 'LEAD_ATTENDANT', label: 'Purser / Lead Attendant' },
          { id: 'GROUND_ENGINEER', label: 'Ground Avionics Engineers' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setRoleFilter(tab.id as any)}
            className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition-all whitespace-nowrap ${
              roleFilter === tab.id
                ? 'bg-sky-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Staff Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredStaff.map((staff) => {
          const assignedFlight = flights.find((f) => f.id === staff.assignedFlightId);
          const hasMinRest = staff.restHoursCompleted >= MINIMUM_REST_HOURS;
          const restPercent = Math.min(
            100,
            Math.round((staff.restHoursCompleted / MINIMUM_REST_HOURS) * 100)
          );

          return (
            <div
              key={staff.id}
              className={`rounded-xl border p-5 shadow-sm flex flex-col justify-between ${
                !hasMinRest
                  ? 'border-amber-500/40 bg-slate-900/80'
                  : 'border-slate-800 bg-slate-900/60'
              }`}
            >
              <div>
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="font-mono text-xs font-semibold text-sky-400">
                      {staff.employeeId} · {staff.licenseNumber}
                    </div>
                    <div className="font-bold text-white text-base mt-0.5">
                      {staff.fullName}
                    </div>
                    <div className="text-xs text-slate-400">
                      {staff.role.replace('_', ' ')} · {staff.nationality}
                    </div>
                  </div>

                  <span
                    className={`font-mono text-xs font-bold uppercase ${
                      staff.dutyStatus === 'ON_DUTY'
                        ? 'text-emerald-400'
                        : staff.dutyStatus === 'REST'
                        ? 'text-amber-400'
                        : 'text-slate-400'
                    }`}
                  >
                    {staff.dutyStatus.replace('_', ' ')}
                  </span>
                </div>

                {/* Mandatory 8-Hour Rest Meter */}
                <div className="mt-4 rounded-lg bg-slate-950 p-3 border border-slate-800/90 space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-400 font-medium">Pre-Duty Rest Completed:</span>
                    <span
                      className={`font-mono font-bold tabular-nums ${
                        hasMinRest ? 'text-emerald-400' : 'text-amber-400'
                      }`}
                    >
                      {staff.restHoursCompleted.toFixed(1)}h / 8.0h min
                    </span>
                  </div>

                  <div className="h-2 w-full rounded-full bg-slate-800 overflow-hidden">
                    <div
                      className={`h-full transition-all ${
                        hasMinRest ? 'bg-emerald-500' : 'bg-amber-500'
                      }`}
                      style={{ width: `${restPercent}%` }}
                    />
                  </div>

                  <div className="flex items-center justify-between text-[11px]">
                    {hasMinRest ? (
                      <span className="text-emerald-400 font-medium flex items-center gap-1">
                        <CheckCircle2 className="h-3.5 w-3.5" />
                        <span>Eligible for Duty (≥8h Rest Met)</span>
                      </span>
                    ) : (
                      <span className="text-amber-400 font-medium flex items-center gap-1">
                        <AlertCircle className="h-3.5 w-3.5" />
                        <span>
                          Ineligible: Needs {(MINIMUM_REST_HOURS - staff.restHoursCompleted).toFixed(1)}h more rest
                        </span>
                      </span>
                    )}

                    <button
                      onClick={() => {
                        onLogCrewRestHours(staff.id, 4.0);
                        setRuleViolationMessage(null);
                        setRuleSuccessMessage(
                          `Logged +4.0h rest for ${staff.fullName} (Total: ${(
                            staff.restHoursCompleted + 4.0
                          ).toFixed(1)}h).`
                        );
                      }}
                      className="text-sky-400 hover:text-sky-300 font-semibold flex items-center gap-1"
                    >
                      <PlusCircle className="h-3 w-3" />
                      <span>+4h Rest</span>
                    </button>
                  </div>
                </div>

                {/* Shift Hours & Qualifications */}
                <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
                  <div className="rounded-lg bg-slate-950/80 p-2.5 border border-slate-800/80">
                    <div className="text-[10px] text-slate-400 uppercase">Active Shift / Max FDP</div>
                    <div className="font-mono text-xs font-bold text-slate-200 mt-0.5 tabular-nums">
                      {staff.currentShiftHours}h / {staff.maxDailyDutyHours}h max
                    </div>
                  </div>

                  <div className="rounded-lg bg-slate-950/80 p-2.5 border border-slate-800/80">
                    <div className="text-[10px] text-slate-400 uppercase">Total Flight Hours</div>
                    <div className="font-mono text-xs font-bold text-slate-200 mt-0.5 tabular-nums">
                      {staff.flightHours > 0
                        ? `${staff.flightHours.toLocaleString()} hrs`
                        : 'Ground Ops'}
                    </div>
                  </div>
                </div>

                {/* Flight Pairing Selector (Enforces 8h Rest Rule) */}
                <div className="mt-3 rounded-lg bg-slate-950/80 p-3 border border-slate-800/80 text-xs">
                  <label
                    htmlFor={`flight-pair-${staff.id}`}
                    className="text-[10px] text-slate-400 uppercase block mb-1"
                  >
                    Flight Pairing Assignment:
                  </label>
                  <select
                    id={`flight-pair-${staff.id}`}
                    value={staff.assignedFlightId || ''}
                    onChange={(e) => handleFlightPairingChange(staff, e.target.value)}
                    className="w-full rounded border border-slate-700 bg-slate-900 px-2.5 py-1.5 text-xs text-white focus:border-sky-500 focus:outline-none"
                  >
                    <option value="">Standby (Unassigned)</option>
                    {flights.map((f) => (
                      <option key={f.id} value={f.id}>
                        {f.flightNumber} ({f.originIata} → {f.destinationIata}) · {f.aircraftModel}
                      </option>
                    ))}
                  </select>
                  {assignedFlight && (
                    <div className="mt-1.5 text-[11px] text-sky-400 font-mono">
                      Active Pairing: {assignedFlight.flightNumber} (Dep: {assignedFlight.scheduledDeparture})
                    </div>
                  )}
                </div>
              </div>

              {/* Duty Toggle Action Buttons */}
              <div className="mt-4 pt-3 border-t border-slate-800/80 grid grid-cols-2 gap-2">
                <button
                  onClick={() => handleDutyStateChange(staff, 'ON_DUTY')}
                  className={`rounded py-1.5 text-xs font-semibold transition-colors ${
                    staff.dutyStatus === 'ON_DUTY'
                      ? 'bg-emerald-600/20 text-emerald-300 border border-emerald-500/40'
                      : 'bg-sky-600 text-white hover:bg-sky-500'
                  }`}
                >
                  Set On Duty
                </button>
                <button
                  onClick={() => handleDutyStateChange(staff, 'REST')}
                  className={`rounded py-1.5 text-xs font-semibold transition-colors ${
                    staff.dutyStatus === 'REST'
                      ? 'bg-amber-600/20 text-amber-300 border border-amber-500/40'
                      : 'bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white'
                  }`}
                >
                  Send to Rest
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
