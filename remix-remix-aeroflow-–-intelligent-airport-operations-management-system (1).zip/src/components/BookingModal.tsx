import React, { useState, useMemo, useEffect } from 'react';
import {
  Flight,
  Passenger,
  PassengerAircraft,
  SeatClass,
  Ticket,
  PaymentMethod,
} from '../types/aeroflow';
import {
  X,
  CreditCard,
  ShieldCheck,
  Award,
  Sparkles,
  Lock,
  Plane,
  Ban,
} from 'lucide-react';

interface BookingModalProps {
  flight: Flight;
  allFlights: Flight[];
  passengerFleet: PassengerAircraft[];
  passengers: Passenger[];
  existingTickets: Ticket[];
  onClose: () => void;
  onSelectFlight: (flight: Flight) => void;
  onConfirmBooking: (
    flight: Flight,
    passenger: Passenger,
    seatNumber: string,
    seatClass: SeatClass,
    finalPrice: number,
    paymentMethod: PaymentMethod
  ) => void;
}

interface AircraftCabinLayout {
  modelName: string;
  fuselageType: 'WIDE_BODY_TWIN_AISLE' | 'NARROW_BODY_SINGLE_AISLE';
  seatConfigLabel: string;
  capacities: {
    first: number;
    business: number;
    economy: number;
    total: number;
  };
  firstClassCols: number;
  firstClassSeats: string[];
  businessCols: number;
  businessConfigLabel: string;
  businessSeats: string[];
  economyCols: number;
  economyConfigLabel: string;
  economySeats: string[];
}

const getCabinLayoutForAircraft = (
  flight: Flight,
  fleet: PassengerAircraft[]
): AircraftCabinLayout => {
  const matchedAc = fleet.find(
    (ac) => ac.id === flight.aircraftId || ac.model === flight.aircraftModel
  );
  const model = matchedAc?.model || flight.aircraftModel;

  // 1. Boeing 737 MAX 9 (Narrow-body 3-3, 178 seats, NO First Class)
  if (model.includes('737')) {
    return {
      modelName: 'Boeing 737 MAX 9',
      fuselageType: 'NARROW_BODY_SINGLE_AISLE',
      seatConfigLabel: 'Single-Aisle Narrow-Body (2-2 Business / 3-3 Economy)',
      capacities: matchedAc?.seatCapacity || {
        first: 0,
        business: 16,
        economy: 162,
        total: 178,
      },
      firstClassCols: 0,
      firstClassSeats: [],
      businessCols: 4,
      businessConfigLabel: 'Business Class Recliners (2-2 Single-Aisle · 16 Seats)',
      businessSeats: [
        '01A', '01C', '01D', '01F',
        '02A', '02C', '02D', '02F',
        '03A', '03C', '03D', '03F',
        '04A', '04C', '04D', '04F',
      ],
      economyCols: 6,
      economyConfigLabel: 'Main Cabin Economy (3-3 Single-Aisle · 162 Seats)',
      economySeats: [
        '10A', '10B', '10C', '10D', '10E', '10F',
        '11A', '11B', '11C', '11D', '11E', '11F',
        '12A', '12B', '12C', '12D', '12E', '12F',
        '14A', '14B', '14C', '14D', '14E', '14F',
        '15A', '15B', '15C', '15D', '15E', '15F',
      ],
    };
  }

  // 2. Airbus A350-900 (Ultra-Long-Range Wide-body, 310 seats: 12 First, 36 Business, 262 Economy)
  if (model.includes('A350') || model.includes('350')) {
    return {
      modelName: 'Airbus A350-900',
      fuselageType: 'WIDE_BODY_TWIN_AISLE',
      seatConfigLabel: 'Twin-Aisle Wide-Body (1-2-1 Suites / 1-2-1 Pods / 3-3-3 Economy)',
      capacities: matchedAc?.seatCapacity || {
        first: 12,
        business: 36,
        economy: 262,
        total: 310,
      },
      firstClassCols: 4,
      firstClassSeats: [
        '01A', '01D', '01G', '01K',
        '02A', '02D', '02G', '02K',
        '03A', '03D', '03G', '03K',
      ],
      businessCols: 4,
      businessConfigLabel: 'Business Herringbone Suites (1-2-1 Twin-Aisle · 36 Seats)',
      businessSeats: [
        '10A', '10D', '10G', '10K',
        '11A', '11D', '11G', '11K',
        '12A', '12D', '12G', '12K',
        '14A', '14D', '14G', '14K',
      ],
      economyCols: 9,
      economyConfigLabel: 'Main Cabin Wide-Body Economy (3-3-3 Twin-Aisle · 262 Seats)',
      economySeats: [
        '20A', '20B', '20C', '20D', '20E', '20G', '20H', '20J', '20K',
        '21A', '21B', '21C', '21D', '21E', '21G', '21H', '21J', '21K',
        '22A', '22B', '22C', '22D', '22E', '22G', '22H', '22J', '22K',
        '23A', '23B', '23C', '23D', '23E', '23G', '23H', '23J', '23K',
      ],
    };
  }

  // 3. Default: Boeing 787-9 Dreamliner (Wide-body, 290 seats: 8 First, 28 Business, 254 Economy)
  return {
    modelName: 'Boeing 787-9 Dreamliner',
    fuselageType: 'WIDE_BODY_TWIN_AISLE',
    seatConfigLabel: 'Twin-Aisle Wide-Body (1-2-1 First / 2-2-2 Business / 3-3-3 Economy)',
    capacities: matchedAc?.seatCapacity || {
      first: 8,
      business: 28,
      economy: 254,
      total: 290,
    },
    firstClassCols: 4,
    firstClassSeats: [
      '01A', '01D', '01G', '01K',
      '02A', '02D', '02G', '02K',
    ],
    businessCols: 6,
    businessConfigLabel: 'Business Class Lie-Flat Pods (2-2-2 Twin-Aisle · 28 Seats)',
    businessSeats: [
      '10A', '10C', '10D', '10G', '10H', '10K',
      '11A', '11C', '11D', '11G', '11H', '11K',
      '12A', '12C', '12D', '12G', '12H', '12K',
    ],
    economyCols: 9,
    economyConfigLabel: 'Main Cabin Economy (3-3-3 Twin-Aisle · 254 Seats)',
    economySeats: [
      '20A', '20B', '20C', '20D', '20E', '20F', '20G', '20H', '20K',
      '21A', '21B', '21C', '21D', '21E', '21F', '21G', '21H', '21K',
      '22A', '22B', '22C', '22D', '22E', '22F', '22G', '22H', '22K',
    ],
  };
};

export const BookingModal: React.FC<BookingModalProps> = ({
  flight,
  allFlights,
  passengerFleet,
  passengers,
  existingTickets,
  onClose,
  onSelectFlight,
  onConfirmBooking,
}) => {
  const bookableFlights = useMemo(
    () =>
      allFlights.filter(
        (f) =>
          f.aircraftCategory === 'PASSENGER' &&
          f.status !== 'LANDED' &&
          f.status !== 'DEPARTED' &&
          f.status !== 'CANCELLED'
      ),
    [allFlights]
  );

  const cabinLayout = useMemo(
    () => getCabinLayoutForAircraft(flight, passengerFleet),
    [flight, passengerFleet]
  );

  const [selectedPassengerId, setSelectedPassengerId] = useState<string>(
    passengers[0]?.id || ''
  );
  const [selectedSeat, setSelectedSeat] = useState<string>(
    cabinLayout.businessSeats[0] || '01A'
  );
  const [selectedSeatClass, setSelectedSeatClass] = useState<SeatClass>('BUSINESS');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('CREDIT_CARD');
  const [isLocking, setIsLocking] = useState(false);

  // Reset selected seat when switching aircraft / flight so seat exists in the new layout
  useEffect(() => {
    if (cabinLayout.businessSeats.length > 0) {
      setSelectedSeat(cabinLayout.businessSeats[0]);
      setSelectedSeatClass('BUSINESS');
    } else if (cabinLayout.economySeats.length > 0) {
      setSelectedSeat(cabinLayout.economySeats[0]);
      setSelectedSeatClass('ECONOMY');
    }
  }, [flight.id, cabinLayout]);

  const selectedPassenger =
    passengers.find((p) => p.id === selectedPassengerId) || passengers[0];

  const occupiedSeats = useMemo(
    () =>
      new Set(
        existingTickets
          .filter((t) => t.flightId === flight.id && t.status !== 'CANCELLED')
          .map((t) => t.seatNumber)
      ),
    [existingTickets, flight.id]
  );

  const calculatePrice = () => {
    let multiplier = 1.0;
    if (selectedSeatClass === 'FIRST') multiplier = 3.6;
    if (selectedSeatClass === 'BUSINESS') multiplier = 2.1;

    let subtotal = flight.basePrice * multiplier;

    if (selectedPassenger?.frequentFlyerTier === 'PLATINUM') subtotal *= 0.82;
    else if (selectedPassenger?.frequentFlyerTier === 'GOLD') subtotal *= 0.88;
    else if (selectedPassenger?.frequentFlyerTier === 'SILVER') subtotal *= 0.94;

    return Math.round(subtotal);
  };

  const finalPrice = calculatePrice();

  const handleSeatClick = (seat: string, seatClass: SeatClass) => {
    if (occupiedSeats.has(seat)) return;
    setSelectedSeat(seat);
    setSelectedSeatClass(seatClass);
  };

  const handleProceedBooking = () => {
    if (!selectedSeat || flight.status === 'LANDED') return;

    setIsLocking(true);
    setTimeout(() => {
      setIsLocking(false);
      onConfirmBooking(
        flight,
        selectedPassenger,
        selectedSeat,
        selectedSeatClass,
        finalPrice,
        paymentMethod
      );
    }, 350);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="relative w-full max-w-5xl rounded-2xl border border-slate-800 bg-slate-900 shadow-2xl overflow-hidden my-6">
        {/* Modal Header with Bookable Flight / Aircraft Switcher */}
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 bg-slate-950/90 px-6 py-4">
          <div className="flex items-center gap-3">
            <div className="rounded-lg bg-sky-500/20 p-2 text-sky-400 border border-sky-500/30">
              <Plane className="h-5 w-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-mono text-sm font-bold text-sky-400">
                  {flight.flightNumber}
                </span>
                <span className="text-xs text-slate-400">·</span>
                <span className="text-sm font-semibold text-white">
                  {flight.originCity} ({flight.originIata}) → {flight.destinationCity} ({flight.destinationIata})
                </span>
              </div>
              <p className="text-xs text-slate-400">
                {cabinLayout.modelName} · {cabinLayout.seatConfigLabel}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div>
              <label htmlFor="modal-flight-switch" className="sr-only">
                Switch Bookable Flight / Aircraft
              </label>
              <select
                id="modal-flight-switch"
                value={flight.id}
                onChange={(e) => {
                  const next = bookableFlights.find((f) => f.id === e.target.value);
                  if (next) onSelectFlight(next);
                }}
                className="rounded-lg border border-slate-700 bg-slate-900 px-3 py-1.5 text-xs font-medium text-white focus:border-sky-500 focus:outline-none"
              >
                {bookableFlights.map((f) => (
                  <option key={f.id} value={f.id}>
                    {f.flightNumber}: {f.aircraftModel} ({f.totalSeats} seats)
                  </option>
                ))}
              </select>
            </div>

            <button
              onClick={onClose}
              aria-label="Close Booking Modal"
              className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white transition-colors"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Guard if a landed flight was ever passed */}
        {flight.status === 'LANDED' ? (
          <div className="p-12 text-center space-y-4">
            <Ban className="mx-auto h-10 w-10 text-rose-400" />
            <div className="text-lg font-bold text-white">
              Seat Booking Closed for Landed Aircraft ({flight.flightNumber})
            </div>
            <p className="text-xs text-slate-400 max-w-md mx-auto">
              This aircraft has already landed at {flight.destinationCity}. Seat reservations are restricted to scheduled, delayed, or active boarding flights.
            </p>
            <button
              onClick={onClose}
              className="rounded-lg bg-slate-800 px-4 py-2 text-xs font-semibold text-white hover:bg-slate-700"
            >
              Close Window
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 p-6">
            {/* Left Column: Aircraft-Specific Cabin Seat Map */}
            <div className="lg:col-span-7 space-y-4">
              {/* Aircraft Capacity Breakdown Bar */}
              <div className="rounded-xl border border-slate-800 bg-slate-950 p-3.5 flex flex-wrap items-center justify-between gap-3 text-xs">
                <div>
                  <span className="text-slate-400">Aircraft Model: </span>
                  <span className="font-bold text-white">{cabinLayout.modelName}</span>
                </div>
                <div className="flex items-center gap-3 font-mono tabular-nums text-[11px]">
                  <span className="text-amber-400">
                    First: {cabinLayout.capacities.first}
                  </span>
                  <span aria-hidden="true" className="text-slate-600">·</span>
                  <span className="text-sky-400">
                    Business: {cabinLayout.capacities.business}
                  </span>
                  <span aria-hidden="true" className="text-slate-600">·</span>
                  <span className="text-emerald-400">
                    Economy: {cabinLayout.capacities.economy}
                  </span>
                  <span aria-hidden="true" className="text-slate-600">·</span>
                  <span className="text-white font-bold">
                    Total: {cabinLayout.capacities.total} Seats
                  </span>
                </div>
              </div>

              {/* Fuselage Mockup */}
              <div className="rounded-xl border border-slate-800 bg-slate-950/70 p-4 relative space-y-4">
                <div className="text-center text-[10px] font-mono tracking-widest text-slate-400 uppercase">
                  ▲ Flight Deck · {cabinLayout.modelName} ({flight.aircraftTail}) ▲
                </div>

                {/* First Class Section (Only if aircraft has First Class > 0) */}
                {cabinLayout.capacities.first > 0 ? (
                  <div>
                    <div className="text-[11px] font-semibold text-amber-400 mb-1.5">
                      First Class Suites (1-2-1 Twin-Aisle · {cabinLayout.capacities.first} Total Suites)
                    </div>
                    <div className="grid grid-cols-4 gap-2">
                      {cabinLayout.firstClassSeats.map((seat) => {
                        const isTaken = occupiedSeats.has(seat);
                        const isSelected = selectedSeat === seat;
                        return (
                          <button
                            key={seat}
                            disabled={isTaken}
                            onClick={() => handleSeatClick(seat, 'FIRST')}
                            className={`rounded-lg py-2 text-xs font-mono font-bold transition-all border ${
                              isSelected
                                ? 'bg-amber-500 text-slate-950 border-amber-300 ring-2 ring-amber-400/50'
                                : isTaken
                                ? 'bg-slate-900 border-slate-800 text-slate-500 cursor-not-allowed line-through'
                                : 'bg-amber-950/40 text-amber-200 border-amber-600/40 hover:bg-amber-900/60 hover:border-amber-400'
                            }`}
                          >
                            {seat}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                ) : (
                  <div className="rounded-lg border border-slate-800/80 bg-slate-900/50 p-2.5 text-center text-xs text-slate-400">
                    No First Class Cabin on Narrow-Body {cabinLayout.modelName} (2-Class Configuration: 16 Business / 162 Economy)
                  </div>
                )}

                {/* Business Class Section */}
                <div>
                  <div className="text-[11px] font-semibold text-sky-400 mb-1.5">
                    {cabinLayout.businessConfigLabel}
                  </div>
                  <div
                    className={`grid gap-2 ${
                      cabinLayout.businessCols === 4 ? 'grid-cols-4' : 'grid-cols-6'
                    }`}
                  >
                    {cabinLayout.businessSeats.map((seat) => {
                      const isTaken = occupiedSeats.has(seat);
                      const isSelected = selectedSeat === seat;
                      return (
                        <button
                          key={seat}
                          disabled={isTaken}
                          onClick={() => handleSeatClick(seat, 'BUSINESS')}
                          className={`rounded py-2 text-xs font-mono font-bold transition-all border ${
                            isSelected
                              ? 'bg-sky-500 text-slate-950 border-sky-300 ring-2 ring-sky-400/50'
                              : isTaken
                              ? 'bg-slate-900 border-slate-800 text-slate-500 cursor-not-allowed line-through'
                              : 'bg-sky-950/40 text-sky-200 border-sky-600/40 hover:bg-sky-900/60 hover:border-sky-400'
                          }`}
                        >
                          {seat}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Economy Section */}
                <div>
                  <div className="text-[11px] font-semibold text-slate-300 mb-1.5">
                    {cabinLayout.economyConfigLabel}
                  </div>
                  <div
                    className={`grid gap-1.5 ${
                      cabinLayout.economyCols === 9 ? 'grid-cols-9' : 'grid-cols-6'
                    }`}
                  >
                    {cabinLayout.economySeats.map((seat) => {
                      const isTaken = occupiedSeats.has(seat);
                      const isSelected = selectedSeat === seat;
                      return (
                        <button
                          key={seat}
                          disabled={isTaken}
                          onClick={() => handleSeatClick(seat, 'ECONOMY')}
                          className={`rounded py-1.5 text-[11px] font-mono font-medium transition-all border ${
                            isSelected
                              ? 'bg-emerald-500 text-slate-950 border-emerald-300 ring-2 ring-emerald-400/50 font-bold'
                              : isTaken
                              ? 'bg-slate-900 border-slate-800 text-slate-500 cursor-not-allowed line-through'
                              : 'bg-slate-800/80 text-slate-200 border-slate-700 hover:bg-slate-700 hover:border-slate-500'
                          }`}
                        >
                          {seat}
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="text-center text-[10px] font-mono tracking-widest text-slate-400 uppercase">
                  ▼ Aft Galley · Pressurized Bulkhead ▼
                </div>
              </div>
            </div>

            {/* Right Column: Passenger details, Fare calculation & Payment */}
            <div className="lg:col-span-5 flex flex-col justify-between space-y-4">
              <div className="space-y-4">
                <div>
                  <label
                    htmlFor="booking-passenger-select"
                    className="text-xs font-semibold text-slate-300"
                  >
                    Select Passenger Profile:
                  </label>
                  <select
                    id="booking-passenger-select"
                    value={selectedPassengerId}
                    onChange={(e) => setSelectedPassengerId(e.target.value)}
                    className="mt-1 w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-xs text-white focus:border-sky-500 focus:outline-none"
                  >
                    {passengers.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.fullName} ({p.frequentFlyerTier} Tier · {p.passportNumber})
                      </option>
                    ))}
                  </select>

                  {selectedPassenger && (
                    <div className="mt-2 flex items-center justify-between rounded-lg bg-slate-950/60 p-2.5 border border-slate-800 text-xs">
                      <div className="flex items-center gap-2">
                        <Award className="h-4 w-4 text-sky-400" />
                        <div>
                          <div className="font-semibold text-slate-200">
                            {selectedPassenger.frequentFlyerTier} Loyalty Status
                          </div>
                          <div className="text-[11px] text-slate-400 font-mono tabular-nums">
                            {selectedPassenger.accumulatedMiles.toLocaleString()} Miles Available
                          </div>
                        </div>
                      </div>
                      {selectedPassenger.fastTrack && (
                        <span className="text-[11px] font-semibold text-sky-400">
                          Priority FastTrack
                        </span>
                      )}
                    </div>
                  )}
                </div>

                {/* Selected Seat & Aircraft Summary */}
                <div className="rounded-xl border border-slate-800 bg-slate-950 p-4 space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-slate-400">Selected Seat:</span>
                    <span className="font-mono text-base font-bold text-sky-400">
                      {selectedSeat} ({selectedSeatClass})
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-xs text-slate-400">
                    <span>Aircraft Layout:</span>
                    <span className="font-mono text-slate-200">
                      {cabinLayout.modelName} ({cabinLayout.capacities.total} cap)
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-xs text-slate-400">
                    <span>Checked Baggage Allowance:</span>
                    <span className="font-mono text-slate-200 font-semibold">
                      {selectedSeatClass === 'FIRST'
                        ? '64 kg (2x 32kg)'
                        : selectedSeatClass === 'BUSINESS'
                        ? '46 kg (2x 23kg)'
                        : '23 kg (1x 23kg)'}
                    </span>
                  </div>
                </div>

                {/* Payment Method Selector */}
                <div>
                  <label className="text-xs font-semibold text-slate-300">
                    Payment Gateway (Polymorphic Handler):
                  </label>
                  <div className="mt-1 grid grid-cols-3 gap-2">
                    {[
                      { id: 'CREDIT_CARD', label: 'Credit Card', icon: CreditCard },
                      { id: 'CORPORATE_BILLING', label: 'Corporate Acc', icon: ShieldCheck },
                      { id: 'AIRLINE_MILES', label: 'Miles Points', icon: Award },
                    ].map((m) => {
                      const Icon = m.icon;
                      return (
                        <button
                          key={m.id}
                          type="button"
                          onClick={() => setPaymentMethod(m.id as PaymentMethod)}
                          className={`flex flex-col items-center justify-center p-2 rounded-lg border text-center transition-all ${
                            paymentMethod === m.id
                              ? 'bg-sky-600/20 border-sky-500 text-sky-300'
                              : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                          }`}
                        >
                          <Icon className="h-4 w-4 mb-1" />
                          <span className="text-[10px] font-medium leading-tight whitespace-nowrap">
                            {m.label}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Price Breakdown */}
                <div className="space-y-1.5 border-t border-slate-800 pt-3 text-xs">
                  <div className="flex justify-between text-slate-400">
                    <span>Base Airfare:</span>
                    <span className="font-mono tabular-nums">${flight.basePrice}</span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>Cabin Class Multiplier:</span>
                    <span className="font-mono tabular-nums">
                      {selectedSeatClass === 'FIRST'
                        ? 'x 3.6'
                        : selectedSeatClass === 'BUSINESS'
                        ? 'x 2.1'
                        : 'x 1.0'}
                    </span>
                  </div>
                  {selectedPassenger?.frequentFlyerTier !== 'BRONZE' && (
                    <div className="flex justify-between text-emerald-400">
                      <span>{selectedPassenger.frequentFlyerTier} Loyalty Discount:</span>
                      <span className="font-mono tabular-nums">
                        {selectedPassenger.frequentFlyerTier === 'PLATINUM'
                          ? '-18%'
                          : selectedPassenger.frequentFlyerTier === 'GOLD'
                          ? '-12%'
                          : '-6%'}
                      </span>
                    </div>
                  )}
                  <div className="flex justify-between items-baseline pt-2 border-t border-slate-800 font-bold text-white text-base">
                    <span>Total Amount:</span>
                    <span className="font-mono tabular-nums text-xl text-sky-400">
                      ${finalPrice}
                    </span>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="mt-4 pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="rounded-lg px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  disabled={isLocking}
                  onClick={handleProceedBooking}
                  className="flex items-center gap-2 rounded-lg bg-sky-600 px-5 py-2.5 text-xs font-bold text-white shadow-lg shadow-sky-900/50 hover:bg-sky-500 active:bg-sky-700 transition-all disabled:opacity-60 whitespace-nowrap"
                >
                  {isLocking ? (
                    <>
                      <Lock className="h-4 w-4 animate-spin" />
                      <span>Acquiring Seat Lock...</span>
                    </>
                  ) : (
                    <>
                      <ShieldCheck className="h-4 w-4" />
                      <span>Confirm & Issue Ticket (${finalPrice})</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
