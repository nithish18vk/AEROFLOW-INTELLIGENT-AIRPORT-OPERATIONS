import React, { useState } from 'react';
import { PassengerAircraft, CargoAircraft } from '../types/aeroflow';
import {
  Plane,
  Package,
  Fuel,
  Gauge,
  Wifi,
  Tv,
  AlertTriangle,
  ShieldCheck,
  CheckCircle2,
  Wrench,
  Compass,
} from 'lucide-react';

interface FleetManagerProps {
  passengerFleet: PassengerAircraft[];
  cargoFleet: CargoAircraft[];
  onToggleMaintenance: (aircraftId: string, category: 'PASSENGER' | 'CARGO') => void;
  onRefuelAircraft: (aircraftId: string, category: 'PASSENGER' | 'CARGO') => void;
}

export const FleetManager: React.FC<FleetManagerProps> = ({
  passengerFleet,
  cargoFleet,
  onToggleMaintenance,
  onRefuelAircraft,
}) => {
  const [activeTab, setActiveTab] = useState<'ALL' | 'PASSENGER' | 'CARGO'>('ALL');

  return (
    <div className="space-y-6">
      {/* Fleet Hero Banner */}
      <div className="relative overflow-hidden rounded-xl border border-slate-800 bg-slate-900/60 shadow-lg">
        <div className="relative h-44 sm:h-48 w-full overflow-hidden bg-slate-950">
          <img
            src="/src/assets/images/aeroflow_aircraft_fleet_1791179012505.jpg"
            alt="AeroFlow Fleet"
            referrerPolicy="no-referrer"
            className="h-full w-full object-cover opacity-40 mix-blend-luminosity"
            onError={(e) => {
              (e.target as HTMLElement).style.display = 'none';
            }}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/60 to-transparent" />

          <div className="absolute inset-0 flex flex-col justify-end p-6">
            <div className="flex items-center gap-2 text-xs font-semibold text-sky-400">
              <Plane className="h-3.5 w-3.5" />
              <span>Avionics & Fleet Airworthiness</span>
              <span aria-hidden="true">·</span>
              <span>Java OOP Class Hierarchy: Aircraft → PassengerAircraft / CargoAircraft</span>
            </div>
            <h2 className="mt-1 text-2xl font-bold tracking-tight text-white">
              Aircraft Fleet Management
            </h2>
            <p className="mt-1 text-xs text-slate-300 max-w-xl">
              Track fuel consumption physics, scheduled checks, payload weight limits, and cabin amenities.
            </p>
          </div>
        </div>
      </div>

      {/* Segmented Filter */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
        <div className="flex items-center gap-2">
          {[
            { id: 'ALL', label: 'All Aircraft' },
            { id: 'PASSENGER', label: 'Commercial Passenger Fleet' },
            { id: 'CARGO', label: 'Freighter Cargo Fleet' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition-all ${
                activeTab === tab.id
                  ? 'bg-sky-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="text-xs text-slate-400 font-mono">
          Total Fleet: {passengerFleet.length + cargoFleet.length} Aircraft
        </div>
      </div>

      {/* Aircraft Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {/* Passenger Aircraft */}
        {(activeTab === 'ALL' || activeTab === 'PASSENGER') &&
          passengerFleet.map((plane) => (
            <div
              key={plane.id}
              className="rounded-xl border border-slate-800 bg-slate-900/60 p-5 shadow-sm flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="rounded-lg bg-sky-950 p-2 text-sky-400 border border-sky-800/60">
                      <Plane className="h-5 w-5" />
                    </div>
                    <div>
                      <div className="font-mono text-base font-bold text-white">
                        {plane.tailNumber}
                      </div>
                      <div className="text-xs text-slate-400 font-medium">
                        {plane.model}
                      </div>
                    </div>
                  </div>

                  <span
                    className={`rounded px-2 py-0.5 font-mono text-[10px] font-bold border uppercase ${
                      plane.status === 'IN_SERVICE'
                        ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                        : 'bg-amber-500/10 text-amber-400 border-amber-500/30'
                    }`}
                  >
                    {plane.status.replace('_', ' ')}
                  </span>
                </div>

                {/* Specs Grid */}
                <div className="mt-4 grid grid-cols-2 gap-2 text-xs">
                  <div className="rounded-lg bg-slate-950/80 p-2.5 border border-slate-800/80">
                    <div className="text-[10px] text-slate-400 uppercase">Passenger Capacity</div>
                    <div className="font-mono text-sm font-bold text-white mt-0.5">
                      {plane.seatCapacity.total} Seats
                    </div>
                    <div className="text-[10px] text-slate-400">
                      F: {plane.seatCapacity.first} | J: {plane.seatCapacity.business} | Y: {plane.seatCapacity.economy}
                    </div>
                  </div>

                  <div className="rounded-lg bg-slate-950/80 p-2.5 border border-slate-800/80">
                    <div className="text-[10px] text-slate-400 uppercase">Flight Range</div>
                    <div className="font-mono text-sm font-bold text-white mt-0.5">
                      {plane.rangeKm.toLocaleString()} km
                    </div>
                    <div className="text-[10px] text-slate-400">
                      Config: {plane.seatConfiguration}
                    </div>
                  </div>
                </div>

                {/* Fuel Meter */}
                <div className="mt-3 rounded-lg bg-slate-950/80 p-3 border border-slate-800/80">
                  <div className="flex items-center justify-between text-xs mb-1.5">
                    <span className="flex items-center gap-1 text-slate-400">
                      <Fuel className="h-3.5 w-3.5 text-amber-400" />
                      <span>Jet-A1 Fuel Tank:</span>
                    </span>
                    <span className="font-mono font-bold text-slate-200">
                      {plane.currentFuelPercent}% ({Math.round((plane.fuelCapacityLiters * plane.currentFuelPercent) / 100).toLocaleString()} L)
                    </span>
                  </div>
                  <div className="h-2 w-full rounded-full bg-slate-800 overflow-hidden">
                    <div
                      className={`h-full ${
                        plane.currentFuelPercent < 30
                          ? 'bg-rose-500'
                          : plane.currentFuelPercent < 70
                          ? 'bg-amber-400'
                          : 'bg-emerald-400'
                      }`}
                      style={{ width: `${plane.currentFuelPercent}%` }}
                    />
                  </div>
                </div>

                {/* Amenities */}
                <div className="mt-3 flex items-center gap-3 text-xs text-slate-400">
                  <span className="flex items-center gap-1">
                    <Wifi className="h-3.5 w-3.5 text-sky-400" />
                    <span>Satellite Wi-Fi</span>
                  </span>
                  <span className="flex items-center gap-1">
                    <Tv className="h-3.5 w-3.5 text-sky-400" />
                    <span>AVOD IFE</span>
                  </span>
                </div>
              </div>

              {/* Actions */}
              <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between gap-2">
                <button
                  onClick={() => onRefuelAircraft(plane.id, 'PASSENGER')}
                  className="flex-1 rounded bg-slate-800 py-1.5 text-xs font-semibold text-slate-200 hover:bg-slate-700 transition-colors"
                >
                  Refuel Tank (100%)
                </button>
                <button
                  onClick={() => onToggleMaintenance(plane.id, 'PASSENGER')}
                  className="rounded border border-slate-700 bg-slate-900 px-3 py-1.5 text-xs font-medium text-slate-300 hover:text-white"
                >
                  {plane.status === 'IN_SERVICE' ? 'Schedule Check' : 'Clear for Flight'}
                </button>
              </div>
            </div>
          ))}

        {/* Cargo Aircraft */}
        {(activeTab === 'ALL' || activeTab === 'CARGO') &&
          cargoFleet.map((plane) => (
            <div
              key={plane.id}
              className="rounded-xl border border-slate-800 bg-slate-900/60 p-5 shadow-sm flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="rounded-lg bg-indigo-950 p-2 text-indigo-400 border border-indigo-800/60">
                      <Package className="h-5 w-5" />
                    </div>
                    <div>
                      <div className="font-mono text-base font-bold text-white">
                        {plane.tailNumber}
                      </div>
                      <div className="text-xs text-slate-400 font-medium">
                        {plane.model}
                      </div>
                    </div>
                  </div>

                  <span
                    className={`rounded px-2 py-0.5 font-mono text-[10px] font-bold border uppercase ${
                      plane.status === 'IN_SERVICE'
                        ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                        : 'bg-amber-500/10 text-amber-400 border-amber-500/30'
                    }`}
                  >
                    {plane.status.replace('_', ' ')}
                  </span>
                </div>

                {/* Cargo Specs */}
                <div className="mt-4 grid grid-cols-2 gap-2 text-xs">
                  <div className="rounded-lg bg-slate-950/80 p-2.5 border border-slate-800/80">
                    <div className="text-[10px] text-slate-400 uppercase">Max Payload</div>
                    <div className="font-mono text-sm font-bold text-indigo-400 mt-0.5">
                      {plane.maxPayloadTons} Metric Tons
                    </div>
                    <div className="text-[10px] text-slate-400">
                      Vol: {plane.cargoVolumeCubicMeters} m³
                    </div>
                  </div>

                  <div className="rounded-lg bg-slate-950/80 p-2.5 border border-slate-800/80">
                    <div className="text-[10px] text-slate-400 uppercase">HazMat Certified</div>
                    <div className="font-mono text-sm font-bold text-white mt-0.5">
                      {plane.hazardousMaterialCertified ? 'ICAO Approved' : 'Standard Freight'}
                    </div>
                    <div className="text-[10px] text-slate-400">
                      Refrigerated Bays: {plane.temperatureControlledBays}
                    </div>
                  </div>
                </div>

                {/* Fuel Meter */}
                <div className="mt-3 rounded-lg bg-slate-950/80 p-3 border border-slate-800/80">
                  <div className="flex items-center justify-between text-xs mb-1.5">
                    <span className="flex items-center gap-1 text-slate-400">
                      <Fuel className="h-3.5 w-3.5 text-amber-400" />
                      <span>Jet-A1 Fuel Tank:</span>
                    </span>
                    <span className="font-mono font-bold text-slate-200">
                      {plane.currentFuelPercent}% ({Math.round((plane.fuelCapacityLiters * plane.currentFuelPercent) / 100).toLocaleString()} L)
                    </span>
                  </div>
                  <div className="h-2 w-full rounded-full bg-slate-800 overflow-hidden">
                    <div
                      className={`h-full ${
                        plane.currentFuelPercent < 30
                          ? 'bg-rose-500'
                          : plane.currentFuelPercent < 70
                          ? 'bg-amber-400'
                          : 'bg-emerald-400'
                      }`}
                      style={{ width: `${plane.currentFuelPercent}%` }}
                    />
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between gap-2">
                <button
                  onClick={() => onRefuelAircraft(plane.id, 'CARGO')}
                  className="flex-1 rounded bg-slate-800 py-1.5 text-xs font-semibold text-slate-200 hover:bg-slate-700 transition-colors"
                >
                  Refuel Tank (100%)
                </button>
                <button
                  onClick={() => onToggleMaintenance(plane.id, 'CARGO')}
                  className="rounded border border-slate-700 bg-slate-900 px-3 py-1.5 text-xs font-medium text-slate-300 hover:text-white"
                >
                  {plane.status === 'IN_SERVICE' ? 'Schedule Check' : 'Clear for Flight'}
                </button>
              </div>
            </div>
          ))}
      </div>
    </div>
  );
};
