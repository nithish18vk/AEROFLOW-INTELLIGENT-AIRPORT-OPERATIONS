import React, { useState } from 'react';
import { Flight, Staff, Gate } from '../types/aeroflow';
import {
  Compass,
  Plane,
  Users,
  Clock,
  ShieldCheck,
  AlertTriangle,
  CheckCircle2,
  Calendar,
  Fuel,
  MapPin,
  FileText,
} from 'lucide-react';

interface PilotAssignedFlightsViewProps {
  flights: Flight[];
  staff: Staff[];
  gates: Gate[];
  onTriggerEmergency?: (flight: Flight) => void;
}

export const PilotAssignedFlightsView: React.FC<PilotAssignedFlightsViewProps> = ({
  flights,
  staff,
  gates,
  onTriggerEmergency,
}) => {
  // Active Crew Member Selector (default to Capt. Marcus Vance)
  const pilotsAndCrew = staff.filter(
    (s) => s.role === 'PILOT' || s.role === 'FIRST_OFFICER' || s.role === 'LEAD_ATTENDANT'
  );
  const [selectedStaffId, setSelectedStaffId] = useState<string>(
    pilotsAndCrew[0]?.id || ''
  );

  const activeStaff = staff.find((s) => s.id === selectedStaffId) || pilotsAndCrew[0];

  // Flights assigned to this crew member or active passenger flights
  const assignedFlights = flights.filter(
    (f) =>
      f.assignedCrewIds.includes(activeStaff?.id || '') ||
      (activeStaff?.assignedFlightId && f.id === activeStaff.assignedFlightId)
  );

  // Fallback to all flights with assigned crew if none specifically for this staff
  const displayFlights =
    assignedFlights.length > 0
      ? assignedFlights
      : flights.filter((f) => f.aircraftCategory === 'PASSENGER').slice(0, 3);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-sky-400">
            <Compass className="h-4 w-4" />
            <span>Flight Deck & Crew Operations Hub</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white mt-1">
            Assigned Flights Roster
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Pre-flight briefing, aircraft airworthiness dispatch, runway slot clearance, and assigned crew pairings.
          </p>
        </div>

        {/* Crew Selector */}
        <div className="flex items-center gap-2 bg-slate-900 border border-slate-800 rounded-xl px-3 py-2">
          <Users className="h-4 w-4 text-sky-400" />
          <div className="text-xs">
            <span className="text-slate-400 block text-[10px]">Logged-in Crew Member:</span>
            <select
              value={selectedStaffId}
              onChange={(e) => setSelectedStaffId(e.target.value)}
              className="bg-transparent font-semibold text-white focus:outline-none cursor-pointer"
            >
              {pilotsAndCrew.map((p) => (
                <option key={p.id} value={p.id} className="bg-slate-900 text-white">
                  {p.fullName} ({p.role.replace('_', ' ')}) · {p.licenseNumber}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Staff Rest & Readiness Status Banner */}
      {activeStaff && (
        <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-4 sm:p-5 shadow-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div
              className={`flex h-12 w-12 items-center justify-center rounded-xl border ${
                activeStaff.restHoursCompleted >= 8
                  ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
                  : 'bg-amber-500/10 border-amber-500/30 text-amber-400'
              }`}
            >
              <ShieldCheck className="h-6 w-6" />
            </div>
            <div>
              <div className="text-sm font-bold text-white flex items-center gap-2">
                <span>{activeStaff.fullName}</span>
                <span className="text-xs font-mono font-medium text-sky-400">
                  [{activeStaff.role}]
                </span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                  {activeStaff.licenseNumber}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Rest Completed:{' '}
                <strong
                  className={
                    activeStaff.restHoursCompleted >= 8 ? 'text-emerald-400' : 'text-amber-400'
                  }
                >
                  {activeStaff.restHoursCompleted} hrs
                </strong>{' '}
                (Mandatory: ≥ 8 hrs) · Current Shift: {activeStaff.currentShiftHours}h / {activeStaff.maxDailyDutyHours}h max
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span
              className={`rounded-full px-3 py-1 text-xs font-bold font-mono ${
                activeStaff.dutyStatus === 'ON_DUTY'
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                  : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
              }`}
            >
              {activeStaff.dutyStatus.replace('_', ' ')}
            </span>
          </div>
        </div>
      )}

      {/* Assigned Flights List */}
      <div className="space-y-4">
        <h2 className="text-sm font-semibold text-slate-300">
          Flight Pairings & Cockpit Briefings ({displayFlights.length})
        </h2>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {displayFlights.map((flight) => {
            const gate = gates.find((g) => g.id === flight.gateId);
            const flightCrew = staff.filter((s) => flight.assignedCrewIds.includes(s.id));

            return (
              <div
                key={flight.id}
                className="rounded-2xl border border-slate-800 bg-slate-900/60 p-5 shadow-xl flex flex-col justify-between space-y-4"
              >
                <div>
                  <div className="flex items-start justify-between border-b border-slate-800 pb-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-lg font-bold font-mono text-white">
                          {flight.flightNumber}
                        </span>
                        <span className="text-xs font-medium text-slate-400">
                          {flight.airline}
                        </span>
                      </div>
                      <div className="text-xs text-slate-400 mt-0.5">
                        {flight.aircraftModel} · Tail: {flight.aircraftTail}
                      </div>
                    </div>

                    <span
                      className={`rounded-full px-2.5 py-0.5 text-[10px] font-bold font-mono uppercase ${
                        flight.status === 'BOARDING'
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                          : flight.status === 'DELAYED'
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                          : 'bg-sky-500/20 text-sky-300 border border-sky-500/40'
                      }`}
                    >
                      {flight.status}
                    </span>
                  </div>

                  {/* Route & Times */}
                  <div className="flex items-center justify-between py-4">
                    <div>
                      <div className="text-xl font-bold text-white font-mono">{flight.originIata}</div>
                      <div className="text-xs text-slate-400">{flight.originCity}</div>
                      <div className="text-xs font-mono text-sky-400 mt-1">
                        Dep: {flight.scheduledDeparture}
                      </div>
                    </div>

                    <div className="flex flex-col items-center">
                      <Plane className="h-5 w-5 text-sky-400 -rotate-45" />
                      <span className="text-[10px] font-mono text-slate-400 mt-1">
                        Gate {flight.gateNumber || 'A1'}
                      </span>
                    </div>

                    <div className="text-right">
                      <div className="text-xl font-bold text-white font-mono">{flight.destinationIata}</div>
                      <div className="text-xs text-slate-400">{flight.destinationCity}</div>
                      <div className="text-xs font-mono text-emerald-400 mt-1">
                        Arr: {flight.scheduledArrival}
                      </div>
                    </div>
                  </div>

                  {/* Cockpit Specs */}
                  <div className="grid grid-cols-3 gap-2 text-center text-xs border-t border-slate-800/80 pt-3">
                    <div className="rounded-lg bg-slate-950 p-2 border border-slate-800">
                      <span className="text-[10px] text-slate-500 uppercase block">Terminal & Gate</span>
                      <span className="font-semibold text-white">
                        {flight.terminal ? flight.terminal.replace('_', ' ') : 'T1'} ({flight.gateNumber || 'A1'})
                      </span>
                    </div>

                    <div className="rounded-lg bg-slate-950 p-2 border border-slate-800">
                      <span className="text-[10px] text-slate-500 uppercase block">Passenger Load</span>
                      <span className="font-semibold text-white">
                        {flight.bookedSeats} / {flight.totalSeats} Pax
                      </span>
                    </div>

                    <div className="rounded-lg bg-slate-950 p-2 border border-slate-800">
                      <span className="text-[10px] text-slate-500 uppercase block">Pre-Flight Rest</span>
                      <span className="font-semibold text-emerald-400">
                        Cleared ICAO
                      </span>
                    </div>
                  </div>

                  {/* Assigned Crew Members */}
                  <div className="mt-3 rounded-lg border border-slate-800/80 bg-slate-950/60 p-2.5 space-y-1">
                    <div className="text-[10px] uppercase font-semibold text-slate-400">
                      Assigned Flight Crew ({flightCrew.length || 2} Officers)
                    </div>
                    <div className="text-xs text-slate-300">
                      {flightCrew.length > 0 ? (
                        flightCrew.map((c) => `${c.fullName} (${c.role})`).join(' · ')
                      ) : (
                        <span>Capt. Marcus Vance (PILOT) · FO Elena Rostov (FIRST_OFFICER)</span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Pre-Flight Actions */}
                <div className="border-t border-slate-800 pt-3 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-1.5 text-emerald-400">
                    <CheckCircle2 className="h-4 w-4" />
                    <span>Flight Plan Dispatched & Signed</span>
                  </div>

                  {onTriggerEmergency && (
                    <button
                      onClick={() => onTriggerEmergency(flight)}
                      className="text-xs text-rose-400 hover:text-rose-300 font-semibold underline"
                    >
                      Report In-Flight Alert
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
