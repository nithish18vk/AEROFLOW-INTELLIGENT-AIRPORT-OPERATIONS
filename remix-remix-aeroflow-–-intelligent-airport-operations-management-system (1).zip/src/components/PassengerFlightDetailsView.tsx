import React, { useState, useMemo } from 'react';
import { Flight, Gate, PassengerAircraft } from '../types/aeroflow';
import {
  Plane,
  Search,
  Filter,
  Clock,
  MapPin,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  Luggage,
  Sparkles,
  Lock,
} from 'lucide-react';

interface PassengerFlightDetailsViewProps {
  flights: Flight[];
  gates: Gate[];
  passengerFleet: PassengerAircraft[];
  onBookFlight: (flight: Flight) => void;
}

export const PassengerFlightDetailsView: React.FC<PassengerFlightDetailsViewProps> = ({
  flights,
  gates,
  passengerFleet,
  onBookFlight,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [directionFilter, setDirectionFilter] = useState<'ALL' | 'DEPARTURES' | 'ARRIVALS'>('ALL');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');

  const passengerFlights = useMemo(
    () => flights.filter((f) => f.aircraftCategory === 'PASSENGER'),
    [flights]
  );

  const filteredFlights = useMemo(() => {
    return passengerFlights.filter((flight) => {
      const q = searchQuery.toLowerCase();
      const matchesSearch =
        flight.flightNumber.toLowerCase().includes(q) ||
        flight.originCity.toLowerCase().includes(q) ||
        flight.destinationCity.toLowerCase().includes(q) ||
        flight.originIata.toLowerCase().includes(q) ||
        flight.destinationIata.toLowerCase().includes(q) ||
        flight.aircraftModel.toLowerCase().includes(q);

      const isDep = flight.originIata === 'JFK';
      const isArr = flight.destinationIata === 'JFK';

      const matchesDirection =
        directionFilter === 'ALL' ||
        (directionFilter === 'DEPARTURES' && isDep) ||
        (directionFilter === 'ARRIVALS' && isArr);

      const matchesStatus =
        statusFilter === 'ALL' || flight.status === statusFilter;

      return matchesSearch && matchesDirection && matchesStatus;
    });
  }, [passengerFlights, searchQuery, directionFilter, statusFilter]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-sky-400">
            <Plane className="h-4 w-4 -rotate-45" />
            <span>Passenger Flight Information Display (FIDS)</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white mt-1">
            Flight Details & Timetable
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Real-time flight timetable, gate assignments, departure slots, and direct seat booking access.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="rounded-xl border border-slate-800 bg-slate-900/80 px-4 py-2 text-xs font-mono text-slate-300">
            Live JFK Telemetry · {passengerFlights.length} Scheduled Flights
          </span>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-4 sm:p-5 shadow-lg space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3 items-center">
          <div className="md:col-span-5 relative">
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400 pointer-events-none" />
            <input
              type="text"
              placeholder="Search flight number, city, or destination..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full rounded-xl border border-slate-700 bg-slate-950 pl-9 pr-3 py-2 text-xs font-medium text-white placeholder-slate-500 focus:border-sky-500 focus:outline-none"
            />
          </div>

          <div className="md:col-span-4 flex items-center gap-1.5 bg-slate-950 p-1 rounded-xl border border-slate-800">
            {(['ALL', 'DEPARTURES', 'ARRIVALS'] as const).map((dir) => (
              <button
                key={dir}
                onClick={() => setDirectionFilter(dir)}
                className={`flex-1 py-1.5 text-xs font-medium rounded-lg transition-colors capitalize ${
                  directionFilter === dir
                    ? 'bg-sky-600 text-white'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {dir.toLowerCase()}
              </button>
            ))}
          </div>

          <div className="md:col-span-3">
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-xs font-medium text-white focus:border-sky-500 focus:outline-none"
            >
              <option value="ALL">All Flight Statuses</option>
              <option value="SCHEDULED">Scheduled</option>
              <option value="BOARDING">Boarding</option>
              <option value="DELAYED">Delayed</option>
              <option value="IN_FLIGHT">In Flight</option>
              <option value="LANDED">Landed</option>
            </select>
          </div>
        </div>
      </div>

      {/* Flight Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredFlights.map((flight) => {
          const isLanded = flight.status === 'LANDED';
          const isDeparted = flight.status === 'DEPARTED';
          const isCancelled = flight.status === 'CANCELLED';
          const isBookable = !isLanded && !isDeparted && !isCancelled;
          const seatsAvailable = flight.totalSeats - flight.bookedSeats;

          return (
            <div
              key={flight.id}
              className="rounded-2xl border border-slate-800 bg-slate-900/60 p-5 shadow-lg flex flex-col justify-between space-y-4 hover:border-slate-700 transition-colors"
            >
              <div>
                <div className="flex items-start justify-between gap-2 border-b border-slate-800/80 pb-3">
                  <div>
                    <div className="text-base font-bold text-white font-mono flex items-center gap-2">
                      <span>{flight.flightNumber}</span>
                      <span className="text-xs font-medium text-slate-400 font-sans">
                        · {flight.airline}
                      </span>
                    </div>
                    <div className="text-xs text-slate-400 mt-0.5">
                      {flight.aircraftModel} ({flight.aircraftTail})
                    </div>
                  </div>

                  <span
                    className={`rounded-full px-2.5 py-0.5 text-[10px] font-bold font-mono uppercase ${
                      flight.status === 'BOARDING'
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 animate-pulse'
                        : flight.status === 'DELAYED'
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                        : flight.status === 'LANDED'
                        ? 'bg-slate-800 text-slate-300 border border-slate-700'
                        : 'bg-sky-500/20 text-sky-300 border border-sky-500/40'
                    }`}
                  >
                    {flight.status}
                  </span>
                </div>

                {/* Route Overview */}
                <div className="flex items-center justify-between py-3">
                  <div>
                    <div className="text-lg font-bold text-white font-mono">{flight.originIata}</div>
                    <div className="text-xs text-slate-400">{flight.originCity}</div>
                    <div className="text-xs font-mono text-sky-400 mt-1">
                      Dep: {flight.scheduledDeparture}
                    </div>
                  </div>

                  <div className="flex flex-col items-center">
                    <Plane className="h-4 w-4 text-slate-500 -rotate-45" />
                    <span className="text-[10px] text-slate-500 mt-1">Direct Flight</span>
                  </div>

                  <div className="text-right">
                    <div className="text-lg font-bold text-white font-mono">{flight.destinationIata}</div>
                    <div className="text-xs text-slate-400">{flight.destinationCity}</div>
                    <div className="text-xs font-mono text-emerald-400 mt-1">
                      Arr: {flight.scheduledArrival}
                    </div>
                  </div>
                </div>

                {/* Gate & Terminal Details */}
                <div className="grid grid-cols-2 gap-2 text-xs border-t border-slate-800/80 pt-3">
                  <div className="rounded-lg bg-slate-950 p-2 border border-slate-800">
                    <span className="text-[10px] text-slate-500 uppercase block">Terminal & Gate</span>
                    <span className="font-semibold text-white">
                      {flight.terminal ? flight.terminal.replace('_', ' ') : 'T1'} · Gate {flight.gateNumber || 'Pending'}
                    </span>
                  </div>

                  <div className="rounded-lg bg-slate-950 p-2 border border-slate-800">
                    <span className="text-[10px] text-slate-500 uppercase block">Available Seats</span>
                    <span className="font-semibold text-white">
                      {seatsAvailable} / {flight.totalSeats} seats
                    </span>
                  </div>
                </div>
              </div>

              {/* Booking CTA */}
              <div className="border-t border-slate-800/80 pt-3 flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-slate-500 block">Fares From</span>
                  <span className="text-sm font-bold text-white font-mono">
                    ${flight.basePrice}
                  </span>
                </div>

                {isBookable ? (
                  <button
                    onClick={() => onBookFlight(flight)}
                    className="flex items-center gap-1.5 rounded-xl bg-sky-600 px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-sky-500 transition-colors shadow-sm"
                  >
                    <Sparkles className="h-3.5 w-3.5" />
                    <span>Book Seats</span>
                    <ArrowRight className="h-3 w-3" />
                  </button>
                ) : (
                  <span className="flex items-center gap-1 text-xs text-slate-500 font-medium">
                    <Lock className="h-3 w-3" />
                    <span>Booking Closed</span>
                  </span>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
