import React, { useState } from 'react';
import {
  Code2,
  Cpu,
  Lock,
  Unlock,
  Play,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  RotateCcw,
  Layers,
  ArrowRight,
  Database,
  Terminal,
} from 'lucide-react';

interface TestCase {
  id: string;
  name: string;
  testClass: string;
  status: 'IDLE' | 'RUNNING' | 'PASSED' | 'FAILED';
  durationMs: number;
  assertionLog: string;
}

export const OopArchitectureLab: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'concepts' | 'concurrency' | 'junit'>('concurrency');

  // Concurrency Simulation State
  const [useLock, setUseLock] = useState(true);
  const [isSimulating, setIsSimulating] = useState(false);
  const [threadALog, setThreadALog] = useState<string[]>([]);
  const [threadBLog, setThreadBLog] = useState<string[]>([]);
  const [concurrencyResult, setConcurrencyResult] = useState<{
    status: 'SUCCESS' | 'RACE_CONDITION' | 'IDLE';
    message: string;
  }>({ status: 'IDLE', message: '' });

  // JUnit 5 Test Runner State
  const [isRunningAllTests, setIsRunningAllTests] = useState(false);
  const [testCases, setTestCases] = useState<TestCase[]>([
    {
      id: 't1',
      name: 'testSuccessfulSeatBooking()',
      testClass: 'BookingServiceTest.java',
      status: 'IDLE',
      durationMs: 14,
      assertionLog: 'assertEquals("12A", ticket.getSeatNumber()) - PASSED',
    },
    {
      id: 't2',
      name: 'testDoubleBookingPreventionWithLock()',
      testClass: 'ConcurrentBookingServiceTest.java',
      status: 'IDLE',
      durationMs: 28,
      assertionLog: 'assertThrows(SeatUnavailableException.class) - PASSED: Thread-B caught lock acquisition rejection',
    },
    {
      id: 't3',
      name: 'testGateAllocationConflictException()',
      testClass: 'GateAllocationServiceTest.java',
      status: 'IDLE',
      durationMs: 19,
      assertionLog: 'assertThrows(GateUnavailableException.class) - PASSED: Gate A1 occupied by flight AF-402',
    },
    {
      id: 't4',
      name: 'testPolymorphicPaymentProcessing()',
      testClass: 'PaymentPolymorphismTest.java',
      status: 'IDLE',
      durationMs: 22,
      assertionLog: 'assertTrue(payment instanceof CreditCardPayment && payment.validate()) - PASSED',
    },
    {
      id: 't5',
      name: 'testOverweightBaggageException()',
      testClass: 'BaggageServiceTest.java',
      status: 'IDLE',
      durationMs: 11,
      assertionLog: 'assertThrows(OverweightBaggageException.class) - PASSED: Bag weight 34.2kg > 32kg threshold',
    },
    {
      id: 't6',
      name: 'testPriorityBoardingQueueOrder()',
      testClass: 'BoardingQueueTest.java',
      status: 'IDLE',
      durationMs: 16,
      assertionLog: 'assertEquals("Dr. Evelyn Reed (Platinum)", priorityQueue.poll().getName()) - PASSED',
    },
  ]);

  // Run Concurrency Race Condition Simulation
  const runConcurrencySimulation = () => {
    setIsSimulating(true);
    setThreadALog([]);
    setThreadBLog([]);
    setConcurrencyResult({ status: 'IDLE', message: '' });

    if (useLock) {
      // Thread-Safe Execution with ReentrantLock
      setTimeout(() => {
        setThreadALog((prev) => [...prev, 'T+0ms: Thread-1 (Mobile App) requests lock on Flight AF-402...']);
        setThreadBLog((prev) => [...prev, 'T+2ms: Thread-2 (Kiosk) requests lock on Flight AF-402...']);
      }, 200);

      setTimeout(() => {
        setThreadALog((prev) => [...prev, 'T+40ms: [LOCK ACQUIRED] Thread-1 checks seat 12A: AVAILABLE']);
        setThreadBLog((prev) => [...prev, 'T+45ms: [WAITING] Thread-2 blocked waiting on ReentrantLock']);
      }, 600);

      setTimeout(() => {
        setThreadALog((prev) => [
          ...prev,
          'T+120ms: Thread-1 saves Ticket PNR=AF892X for Seat 12A.',
          'T+130ms: [LOCK RELEASED] Thread-1 finishes transaction.',
        ]);
      }, 1000);

      setTimeout(() => {
        setThreadBLog((prev) => [
          ...prev,
          'T+135ms: [LOCK ACQUIRED] Thread-2 checks seat 12A: OCCUPIED!',
          'T+145ms: [EXCEPTION] Throws SeatUnavailableException("Seat 12A already booked")',
          'T+150ms: [LOCK RELEASED] Thread-2 terminates safely without corruption.',
        ]);
        setConcurrencyResult({
          status: 'SUCCESS',
          message: 'Thread Safety Verified! ReentrantLock prevented simultaneous booking of Seat 12A. System state intact.',
        });
        setIsSimulating(false);
      }, 1500);
    } else {
      // Unsynchronized Race Condition
      setTimeout(() => {
        setThreadALog((prev) => [...prev, 'T+0ms: Thread-1 (Mobile App) checks seat 12A: AVAILABLE']);
        setThreadBLog((prev) => [...prev, 'T+1ms: Thread-2 (Kiosk) checks seat 12A: AVAILABLE (Dirty Read!)']);
      }, 200);

      setTimeout(() => {
        setThreadALog((prev) => [...prev, 'T+50ms: Thread-1 writes reservation for Seat 12A (Passenger: Alice)']);
        setThreadBLog((prev) => [...prev, 'T+52ms: Thread-2 writes reservation for Seat 12A (Passenger: Bob)']);
      }, 700);

      setTimeout(() => {
        setThreadALog((prev) => [...prev, 'T+100ms: Thread-1 issues Ticket AF-101-A']);
        setThreadBLog((prev) => [...prev, 'T+102ms: Thread-2 issues Ticket AF-101-B for SAME SEAT 12A!']);
        setConcurrencyResult({
          status: 'RACE_CONDITION',
          message: 'CRITICAL RACE CONDITION OCCURRED! Both threads double-booked Seat 12A due to lack of synchronization!',
        });
        setIsSimulating(false);
      }, 1300);
    }
  };

  // Run Virtual JUnit 5 Suite
  const runAllJUnitTests = () => {
    setIsRunningAllTests(true);

    testCases.forEach((_, idx) => {
      setTimeout(() => {
        setTestCases((prev) => {
          const next = [...prev];
          next[idx] = { ...next[idx], status: 'RUNNING' };
          return next;
        });

        setTimeout(() => {
          setTestCases((prev) => {
            const next = [...prev];
            next[idx] = { ...next[idx], status: 'PASSED' };
            return next;
          });

          if (idx === testCases.length - 1) {
            setIsRunningAllTests(false);
          }
        }, 300);
      }, idx * 350);
    });
  };

  const oopConceptsList = [
    {
      concept: 'Classes & Objects',
      usage: 'Flight, Passenger, Aircraft, Gate, Ticket, Baggage',
      codeSnippet: 'Flight flight = new Flight("AF-402", "JFK", "LHR", 290, 620.0);',
    },
    {
      concept: 'Encapsulation',
      usage: 'Private fields, getters/setters, invariant checks in Baggage & Flight',
      codeSnippet: 'private double weightKg; public void setWeight(double w) { if(w > 32) throw new OverweightBaggageException(); }',
    },
    {
      concept: 'Inheritance',
      usage: 'Person → Passenger / Staff; Aircraft → PassengerAircraft / CargoAircraft',
      codeSnippet: 'public class PassengerAircraft extends Aircraft { private int firstClassSeats; ... }',
    },
    {
      concept: 'Polymorphism',
      usage: 'Dynamic pricing by class & frequent flyer tier; fuel burn computation',
      codeSnippet: 'double fuelBurn = aircraft.calculateFuelBurnRatePerKm(); // Polymorphic dispatch',
    },
    {
      concept: 'Abstract Classes',
      usage: 'abstract class Person, abstract class Aircraft, abstract class Payment',
      codeSnippet: 'public abstract class Payment { public abstract boolean processPayment(); }',
    },
    {
      concept: 'Interfaces',
      usage: 'Bookable, Payable, Trackable',
      codeSnippet: 'public interface Trackable { String getTrackingBarcode(); String getCurrentLocation(); }',
    },
    {
      concept: 'Multithreading & Synchronization',
      usage: 'ReentrantLock per Flight preventing concurrent double-booking of seats',
      codeSnippet: 'ReentrantLock lock = flightLocks.computeIfAbsent(id, k -> new ReentrantLock(true)); lock.lock(); try { ... } finally { lock.unlock(); }',
    },
    {
      concept: 'Custom Exceptions',
      usage: 'FlightFullException, SeatUnavailableException, GateUnavailableException, OverweightBaggageException',
      codeSnippet: 'throw new GateUnavailableException("Gate A1 currently occupied by flight AF-402");',
    },
    {
      concept: 'Java Collections',
      usage: 'ArrayList (flights), HashSet (unique IDs), PriorityQueue (boarding), ConcurrentHashMap (flight lock map)',
      codeSnippet: 'PriorityQueue<Passenger> boardingQueue = new PriorityQueue<>(Comparator.comparing(Passenger::getTierPriority));',
    },
    {
      concept: 'Streams & Lambdas',
      usage: 'Filtering flights by delay, sorting departures, calculating revenue yield',
      codeSnippet: 'flights.stream().filter(f -> f.getStatus() == DELAYED).mapToInt(Flight::getDelayMinutes).sum();',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 rounded-xl border border-slate-800 bg-slate-900/60 p-6">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-sky-400">
            <Cpu className="h-3.5 w-3.5" />
            <span>Interactive Java 21 OOP & Multithreading Laboratory</span>
          </div>
          <h2 className="mt-1 text-2xl font-bold tracking-tight text-white">
            OOP Architecture & Concurrency Engine
          </h2>
          <p className="mt-1 text-xs text-slate-300">
            Explore live thread-safety synchronization, object-oriented design patterns, and run the virtual JUnit 5 test suite.
          </p>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800">
          <button
            onClick={() => setActiveTab('concurrency')}
            className={`rounded px-3 py-1.5 text-xs font-semibold transition-all ${
              activeTab === 'concurrency'
                ? 'bg-sky-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Concurrency & Locks
          </button>
          <button
            onClick={() => setActiveTab('junit')}
            className={`rounded px-3 py-1.5 text-xs font-semibold transition-all ${
              activeTab === 'junit'
                ? 'bg-sky-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            JUnit 5 Test Console
          </button>
          <button
            onClick={() => setActiveTab('concepts')}
            className={`rounded px-3 py-1.5 text-xs font-semibold transition-all ${
              activeTab === 'concepts'
                ? 'bg-sky-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            OOP Concept Matrix
          </button>
        </div>
      </div>

      {/* Tab 1: Live Multithreading & Race Condition Simulator */}
      {activeTab === 'concurrency' && (
        <div className="space-y-6">
          {/* Concurrency Control Bar */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 rounded-xl border border-slate-800 bg-slate-900/80 p-5">
            <div>
              <h3 className="font-bold text-white text-sm flex items-center gap-2">
                <Lock className="h-4 w-4 text-sky-400" />
                <span>Simultaneous Seat Reservation Simulator (Seat 12A on Flight AF-402)</span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Simulates 2 independent threads (Mobile User vs Kiosk) executing simultaneous booking requests at T+0ms.
              </p>
            </div>

            <div className="flex items-center gap-3">
              {/* Toggle Synchronization */}
              <div className="flex items-center gap-2 bg-slate-950 p-1.5 rounded-lg border border-slate-800 text-xs">
                <button
                  onClick={() => setUseLock(true)}
                  className={`flex items-center gap-1.5 px-3 py-1 rounded font-semibold transition-all ${
                    useLock
                      ? 'bg-emerald-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <Lock className="h-3.5 w-3.5" />
                  <span>ReentrantLock (Safe)</span>
                </button>
                <button
                  onClick={() => setUseLock(false)}
                  className={`flex items-center gap-1.5 px-3 py-1 rounded font-semibold transition-all ${
                    !useLock
                      ? 'bg-rose-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <Unlock className="h-3.5 w-3.5" />
                  <span>No Lock (Race Condition)</span>
                </button>
              </div>

              <button
                disabled={isSimulating}
                onClick={runConcurrencySimulation}
                className="flex items-center gap-1.5 rounded-lg bg-sky-600 px-4 py-2 text-xs font-bold text-white shadow-sm hover:bg-sky-500 disabled:opacity-50 transition-colors"
              >
                <Play className="h-4 w-4" />
                <span>Launch Threads</span>
              </button>
            </div>
          </div>

          {/* Outcome Status Alert */}
          {concurrencyResult.status !== 'IDLE' && (
            <div
              className={`rounded-xl border p-4 text-xs font-medium flex items-center gap-3 ${
                concurrencyResult.status === 'SUCCESS'
                  ? 'bg-emerald-950/60 border-emerald-500/50 text-emerald-200'
                  : 'bg-rose-950/80 border-rose-500/70 text-rose-200 animate-pulse'
              }`}
            >
              {concurrencyResult.status === 'SUCCESS' ? (
                <CheckCircle2 className="h-5 w-5 text-emerald-400 shrink-0" />
              ) : (
                <AlertTriangle className="h-5 w-5 text-rose-400 shrink-0" />
              )}
              <span>{concurrencyResult.message}</span>
            </div>
          )}

          {/* 2 Threads Side-by-Side Execution Logs */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Thread 1: Mobile App */}
            <div className="rounded-xl border border-slate-800 bg-slate-950 p-5 space-y-3 font-mono text-xs">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="text-sky-400 font-bold flex items-center gap-2">
                  <span className="h-2 w-2 rounded-full bg-sky-400 animate-ping" />
                  Thread-1 (iOS Mobile App - Passenger Reed)
                </span>
                <span className="text-slate-400 text-[10px]">Priority: NORM_PRIORITY (5)</span>
              </div>

              <div className="min-h-[160px] space-y-1.5 text-slate-300">
                {threadALog.length === 0 ? (
                  <span className="text-slate-400 italic">Thread waiting to spawn... Click 'Launch Threads'</span>
                ) : (
                  threadALog.map((log, idx) => (
                    <div key={idx} className="leading-relaxed">
                      {log}
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* Thread 2: Airport Kiosk */}
            <div className="rounded-xl border border-slate-800 bg-slate-950 p-5 space-y-3 font-mono text-xs">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="text-amber-400 font-bold flex items-center gap-2">
                  <span className="h-2 w-2 rounded-full bg-amber-400 animate-ping" />
                  Thread-2 (Terminal Kiosk 4 - Passenger Kenji)
                </span>
                <span className="text-slate-400 text-[10px]">Priority: NORM_PRIORITY (5)</span>
              </div>

              <div className="min-h-[160px] space-y-1.5 text-slate-300">
                {threadBLog.length === 0 ? (
                  <span className="text-slate-400 italic">Thread waiting to spawn... Click 'Launch Threads'</span>
                ) : (
                  threadBLog.map((log, idx) => (
                    <div
                      key={idx}
                      className={`leading-relaxed ${
                        log.includes('EXCEPTION')
                          ? 'text-amber-400 font-bold'
                          : log.includes('SAME SEAT')
                          ? 'text-rose-400 font-bold'
                          : ''
                      }`}
                    >
                      {log}
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: JUnit 5 Virtual Test Console */}
      {activeTab === 'junit' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 rounded-xl border border-slate-800 bg-slate-900/80 p-5">
            <div>
              <h3 className="font-bold text-white text-sm flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                <span>JUnit 5 Virtual Test Engine (@Test, @DisplayName, Assertions)</span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Executes unit and integration test assertions across Spring Boot service layers and domain invariants.
              </p>
            </div>

            <button
              disabled={isRunningAllTests}
              onClick={runAllJUnitTests}
              className="flex items-center gap-1.5 rounded-lg bg-emerald-600 px-4 py-2 text-xs font-bold text-white shadow-sm hover:bg-emerald-500 disabled:opacity-50 transition-colors"
            >
              <Play className="h-4 w-4" />
              <span>Run All Test Suites (mvn test)</span>
            </button>
          </div>

          {/* Test Case Cards */}
          <div className="space-y-2.5">
            {testCases.map((tc) => (
              <div
                key={tc.id}
                className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 rounded-lg border border-slate-800 bg-slate-950 p-4 transition-all"
              >
                <div className="flex items-center gap-3">
                  {tc.status === 'PASSED' ? (
                    <CheckCircle2 className="h-5 w-5 text-emerald-400 shrink-0" />
                  ) : tc.status === 'RUNNING' ? (
                    <div className="h-4 w-4 rounded-full border-2 border-sky-400 border-t-transparent animate-spin shrink-0" />
                  ) : (
                    <div className="h-5 w-5 rounded-full border border-slate-700 bg-slate-900 shrink-0" />
                  )}

                  <div>
                    <div className="font-mono text-xs font-bold text-white">
                      {tc.name}
                    </div>
                    <div className="text-[11px] text-slate-400 font-mono">
                      Class: {tc.testClass}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-4 text-xs font-mono">
                  <span className="text-slate-400 text-[11px]">
                    {tc.assertionLog}
                  </span>
                  <span className="rounded bg-slate-800 px-2 py-0.5 text-[10px] text-slate-300">
                    {tc.durationMs}ms
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 3: OOP Concepts Matrix */}
      {activeTab === 'concepts' && (
        <div className="rounded-xl border border-slate-800 bg-slate-900/50 overflow-hidden shadow-md">
          <div className="p-5 border-b border-slate-800 bg-slate-950/70">
            <h3 className="font-bold text-white text-base">
              AeroFlow Java OOP Implementation Guide
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              Exact mapping of object-oriented principles, design patterns, and JVM collections used in the platform.
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-800 bg-slate-950/90 text-slate-400 font-semibold">
                  <th className="py-3 px-4 w-1/4">OOP Concept</th>
                  <th className="py-3 px-4 w-1/3">Airport System Application</th>
                  <th className="py-3 px-4">Java Code Demonstration</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-sans">
                {oopConceptsList.map((item, idx) => (
                  <tr key={idx} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-3.5 px-4 font-bold text-sky-400">
                      {item.concept}
                    </td>
                    <td className="py-3.5 px-4 text-slate-200">
                      {item.usage}
                    </td>
                    <td className="py-3.5 px-4">
                      <code className="font-mono text-[11px] text-emerald-400 bg-slate-950 px-2 py-1 rounded border border-slate-800 block truncate max-w-lg">
                        {item.codeSnippet}
                      </code>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
