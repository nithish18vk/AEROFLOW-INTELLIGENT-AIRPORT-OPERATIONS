import React, { useState } from 'react';
import {
  EmergencyIncident,
  EmergencyType,
  EmergencyDeclarerRole,
  Flight,
} from '../types/aeroflow';
import { EMERGENCY_TYPE_RULES } from '../data/mockAirportData';
import {
  AlertTriangle,
  ShieldAlert,
  Flame,
  HeartPulse,
  CheckCircle2,
  Radio,
  Truck,
  Wrench,
  LogOut,
  ArrowLeft,
  UserCheck,
  Plus,
} from 'lucide-react';

interface EmergencyCenterProps {
  incidents: EmergencyIncident[];
  flights: Flight[];
  onResolveIncident: (incidentId: string) => void;
  onApplyOperationFix: (incidentId: string, fixId: string) => void;
  onApplyAllOperationFixes: (incidentId: string) => void;
  onAddCustomOperationFix: (
    incidentId: string,
    label: string,
    subsystem: string
  ) => void;
  onDeclareEmergency: (
    flightId: string,
    type: EmergencyType,
    declaredByRole: EmergencyDeclarerRole,
    declaredByName: string,
    severity: EmergencyIncident['severity']
  ) => void;
  onExitEmergencyView?: () => void;
  onExitSystem?: () => void;
}

const DECLARER_ROLE_LABELS: Record<EmergencyDeclarerRole, string> = {
  CAPTAIN_PILOT: 'Captain / Pilot (ATP)',
  FIRST_OFFICER: 'First Officer (Flight Deck)',
  ATC_CONTROLLER: 'ATC Tower Controller',
  LEAD_ATTENDANT: 'Chief Purser / Lead Attendant',
  GROUND_ENGINEER: 'Ground Avionics Engineer',
  RAMP_SUPERVISOR: 'Apron / Ramp Supervisor',
  AIRPORT_SECURITY: 'Airport Security Command',
};

export const EmergencyCenter: React.FC<EmergencyCenterProps> = ({
  incidents,
  flights,
  onResolveIncident,
  onApplyOperationFix,
  onApplyAllOperationFixes,
  onAddCustomOperationFix,
  onDeclareEmergency,
  onExitEmergencyView,
  onExitSystem,
}) => {
  const [isDeclareModalOpen, setIsDeclareModalOpen] = useState(false);
  const [selectedFlightId, setSelectedFlightId] = useState(flights[0]?.id || '');
  const [emergencyType, setEmergencyType] = useState<EmergencyType>('ENGINE_FAILURE');
  const [declarerRole, setDeclarerRole] = useState<EmergencyDeclarerRole>('CAPTAIN_PILOT');
  const [declarerName, setDeclarerName] = useState('Capt. Marcus Vance');
  const [severity, setSeverity] = useState<EmergencyIncident['severity']>('CRITICAL');
  const [authError, setAuthError] = useState<string | null>(null);

  // Custom fix input state per incident
  const [customFixText, setCustomFixText] = useState<Record<string, string>>({});

  const selectedRule =
    EMERGENCY_TYPE_RULES.find((r) => r.type === emergencyType) ||
    EMERGENCY_TYPE_RULES[0];

  const isRoleAuthorized = selectedRule.authorizedRoles.includes(declarerRole);

  const handleDeclareSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFlightId) return;

    if (!isRoleAuthorized) {
      setAuthError(
        `UnauthorizedDeclarerException: ${DECLARER_ROLE_LABELS[declarerRole]} is not authorized to declare ${selectedRule.label}. Authorized roles: ${selectedRule.authorizedRolesSummary}.`
      );
      return;
    }

    onDeclareEmergency(
      selectedFlightId,
      emergencyType,
      declarerRole,
      declarerName,
      severity
    );
    setAuthError(null);
    setIsDeclareModalOpen(false);
  };

  return (
    <div className="space-y-6">
      {/* Alert Header with Declare, Operation Fix Status & Exit Controls */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 rounded-xl border border-rose-500/40 bg-rose-950/30 p-6">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-rose-400">
            <ShieldAlert className="h-4 w-4 animate-bounce" />
            <span>Air Traffic Control Priority Clearance · Live Operation Fixes & Emergency Exit</span>
          </div>
          <h2 className="mt-1 text-2xl font-bold tracking-tight text-white">
            Emergency Command & Remediation Center
          </h2>
          <p className="mt-1 text-xs text-rose-200 max-w-2xl">
            Enforces role-based emergency declaration rules, interactive subsystem operation fixes during active emergencies, and immediate exit access for all personnel.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={() => {
              setAuthError(null);
              setIsDeclareModalOpen(true);
            }}
            className="flex items-center gap-1.5 rounded-lg bg-rose-600 px-4 py-2 text-xs font-bold text-white shadow-lg shadow-rose-950/60 hover:bg-rose-500 transition-colors whitespace-nowrap"
          >
            <AlertTriangle className="h-4 w-4" />
            <span>Declare Emergency</span>
          </button>

          {onExitEmergencyView && (
            <button
              onClick={onExitEmergencyView}
              className="flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-900 px-3.5 py-2 text-xs font-semibold text-slate-200 hover:bg-slate-800 hover:text-white transition-colors whitespace-nowrap"
            >
              <ArrowLeft className="h-3.5 w-3.5" />
              <span>Exit to Flight Ops</span>
            </button>
          )}

          {onExitSystem && (
            <button
              onClick={onExitSystem}
              className="flex items-center gap-1.5 rounded-lg border border-rose-400/40 bg-rose-950/80 px-3.5 py-2 text-xs font-semibold text-rose-200 hover:bg-rose-900 transition-colors whitespace-nowrap"
            >
              <LogOut className="h-3.5 w-3.5" />
              <span>Emergency Exit System</span>
            </button>
          )}
        </div>
      </div>

      {/* Active & Historical Incidents with Interactive Operation Fixes */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-white">
            Active Emergency Incidents & Live Operation Fixes
          </h3>
          <span className="text-xs text-slate-400 font-mono tabular-nums">
            {incidents.filter((i) => i.status === 'ACTIVE').length} Active ·{' '}
            {incidents.filter((i) => i.status === 'RESOLVED').length} Resolved
          </span>
        </div>

        {incidents.length === 0 ? (
          <div className="rounded-xl border border-slate-800 bg-slate-900/40 p-12 text-center text-slate-400">
            <CheckCircle2 className="mx-auto h-8 w-8 text-emerald-400 mb-2" />
            <div className="font-semibold text-slate-200">No Active Emergency Incidents</div>
            <p className="text-xs mt-1">
              All runways and airspace sectors are operating under nominal safety conditions.
            </p>
          </div>
        ) : (
          incidents.map((incident) => {
            const isResolved = incident.status === 'RESOLVED';
            const appliedCount = incident.operationFixes.filter(
              (f) => f.status === 'APPLIED'
            ).length;
            const totalFixes = incident.operationFixes.length;

            return (
              <div
                key={incident.id}
                className={`rounded-xl border p-5 transition-all space-y-4 ${
                  isResolved
                    ? 'border-slate-800 bg-slate-900/40 opacity-75'
                    : 'border-rose-500/60 bg-slate-900/90 shadow-xl shadow-rose-950/30'
                }`}
              >
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="rounded-lg bg-rose-950 p-2.5 text-rose-400 border border-rose-800">
                      {incident.type === 'MEDICAL' ? (
                        <HeartPulse className="h-6 w-6 text-rose-400 animate-pulse" />
                      ) : incident.type === 'BIRD_STRIKE' ? (
                        <AlertTriangle className="h-6 w-6 text-amber-400" />
                      ) : (
                        <Flame className="h-6 w-6 text-rose-500" />
                      )}
                    </div>

                    <div>
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-mono text-base font-bold text-white">
                          Flight {incident.flightNumber}
                        </span>
                        <span className="font-mono text-xs text-slate-400">
                          ({incident.aircraftTail})
                        </span>
                        <span className="text-xs font-bold text-rose-400 uppercase">
                          · {incident.type.replace(/_/g, ' ')} ({incident.severity})
                        </span>
                      </div>
                      <div className="text-xs text-slate-400 mt-0.5 flex flex-wrap items-center gap-2">
                        <span>
                          Declared By:{' '}
                          <strong className="text-slate-200">
                            {DECLARER_ROLE_LABELS[incident.declaredByRole] || incident.declaredByRole}
                          </strong>{' '}
                          ({incident.declaredByName})
                        </span>
                        <span aria-hidden="true">·</span>
                        <span>
                          Reported: <span className="font-mono text-slate-300">{incident.reportedAt}</span>
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-2">
                    {!isResolved && (
                      <>
                        <button
                          onClick={() => onApplyAllOperationFixes(incident.id)}
                          className="flex items-center gap-1.5 rounded-lg bg-sky-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-sky-500 transition-colors whitespace-nowrap"
                        >
                          <Wrench className="h-3.5 w-3.5" />
                          <span>Execute All Operation Fixes ({appliedCount}/{totalFixes})</span>
                        </button>
                        <button
                          onClick={() => onResolveIncident(incident.id)}
                          className="rounded-lg bg-emerald-600 px-3.5 py-1.5 text-xs font-bold text-white hover:bg-emerald-500 transition-colors shadow whitespace-nowrap"
                        >
                          Resolve & Restore Normal Ops
                        </button>
                      </>
                    )}
                    {isResolved && (
                      <span className="flex items-center gap-1 font-mono text-xs font-bold text-emerald-400">
                        <CheckCircle2 className="h-4 w-4" />
                        <span>RESOLVED · OPERATIONS RESTORED</span>
                      </span>
                    )}
                  </div>
                </div>

                {/* Live Operation Fixes Checklist (Interactive during emergency) */}
                <div className="rounded-lg bg-slate-950/90 p-4 border border-slate-800 space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="font-semibold text-xs text-slate-200 flex items-center gap-1.5">
                      <Wrench className="h-4 w-4 text-sky-400" />
                      <span>
                        Emergency Operation Fixes & Subsystem Remediation ({appliedCount} of{' '}
                        {totalFixes} Applied)
                      </span>
                    </div>
                    <span className="text-[11px] text-slate-400">
                      Click any pending fix to execute live remediation
                    </span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-2.5">
                    {incident.operationFixes.map((fix) => {
                      const isDone = fix.status === 'APPLIED';
                      return (
                        <div
                          key={fix.id}
                          className={`rounded-lg border p-3 flex flex-col justify-between gap-2 ${
                            isDone
                              ? 'border-emerald-500/40 bg-emerald-950/20'
                              : 'border-slate-800 bg-slate-900/80'
                          }`}
                        >
                          <div>
                            <div className="flex items-center justify-between text-[10px] font-mono text-slate-400">
                              <span>{fix.subsystem}</span>
                              {isDone ? (
                                <span className="text-emerald-400 font-bold">
                                  FIXED {fix.appliedAt || ''}
                                </span>
                              ) : (
                                <span className="text-amber-400 font-bold">ACTION REQUIRED</span>
                              )}
                            </div>
                            <div className="mt-1 text-xs font-medium text-slate-200">
                              {fix.label}
                            </div>
                          </div>

                          {!isDone && !isResolved ? (
                            <button
                              onClick={() => onApplyOperationFix(incident.id, fix.id)}
                              className="w-full rounded bg-sky-600/90 hover:bg-sky-500 py-1.5 text-[11px] font-semibold text-white transition-colors"
                            >
                              Apply Operation Fix
                            </button>
                          ) : (
                            <div className="flex items-center gap-1 text-[11px] font-semibold text-emerald-400">
                              <CheckCircle2 className="h-3.5 w-3.5" />
                              <span>Subsystem Fix Verified</span>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>

                  {/* Add Custom Operation Fix during Emergency */}
                  {!isResolved && (
                    <div className="pt-2 border-t border-slate-800/80 flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                      <input
                        type="text"
                        aria-label="Custom operation fix instruction"
                        placeholder="Enter additional custom operation fix (e.g. Reroute Gate A4 Jetbridge Power, Deploy Backup Tug)..."
                        value={customFixText[incident.id] || ''}
                        onChange={(e) =>
                          setCustomFixText((prev) => ({
                            ...prev,
                            [incident.id]: e.target.value,
                          }))
                        }
                        className="flex-1 rounded border border-slate-700 bg-slate-900 px-3 py-1.5 text-xs text-white placeholder:text-slate-500 focus:border-sky-500 focus:outline-none"
                      />
                      <button
                        type="button"
                        onClick={() => {
                          const text = (customFixText[incident.id] || '').trim();
                          if (!text) return;
                          onAddCustomOperationFix(incident.id, text, 'Field Ops Override');
                          setCustomFixText((prev) => ({ ...prev, [incident.id]: '' }));
                        }}
                        className="flex items-center justify-center gap-1 rounded bg-slate-800 hover:bg-slate-700 border border-slate-700 px-3 py-1.5 text-xs font-semibold text-sky-300 whitespace-nowrap"
                      >
                        <Plus className="h-3.5 w-3.5" />
                        <span>Add & Apply Fix</span>
                      </button>
                    </div>
                  )}
                </div>

                {/* ATC Vectoring & Dispatched Units */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
                  <div className="rounded-lg bg-slate-950/70 p-3 border border-slate-800">
                    <span className="text-[10px] uppercase text-slate-400 block font-medium">
                      Cleared Emergency Runway:
                    </span>
                    <span className="font-mono text-emerald-400 font-bold">
                      {incident.assignedRunway}
                    </span>
                  </div>
                  <div className="rounded-lg bg-slate-950/70 p-3 border border-slate-800">
                    <span className="text-[10px] uppercase text-slate-400 block font-medium">
                      Priority Isolation Gate:
                    </span>
                    <span className="font-mono text-sky-400 font-bold">
                      {incident.assignedGate}
                    </span>
                  </div>
                  <div className="rounded-lg bg-slate-950/70 p-3 border border-slate-800">
                    <span className="text-[10px] uppercase text-slate-400 block font-medium">
                      Dispatched Rescue Units:
                    </span>
                    <span className="text-slate-300">
                      {incident.emergencyUnitsDispatched.join(' · ')}
                    </span>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Reference Matrix: Emergency Types & Who Can Declare Each Emergency */}
      <div className="rounded-xl border border-slate-800 bg-slate-900/60 overflow-hidden">
        <div className="p-5 border-b border-slate-800 flex flex-wrap items-center justify-between gap-2">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <UserCheck className="h-4 w-4 text-sky-400" />
              <span>ICAO Emergency Types & Authorized Declaring Authority Matrix</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Specifies each recognized airport/in-flight emergency classification, who is authorized to declare it, and standard remediation protocols.
            </p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-950/80 text-slate-400 font-semibold">
                <th className="py-3 px-4">Emergency Type</th>
                <th className="py-3 px-4">Operational Scenario</th>
                <th className="py-3 px-4">Who Can Declare (Authorized Roles)</th>
                <th className="py-3 px-4">Primary Operation Fix</th>
                <th className="py-3 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {EMERGENCY_TYPE_RULES.map((rule) => (
                <tr key={rule.type} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-3 px-4 font-semibold text-white">
                    <div>{rule.label}</div>
                    <div className="font-mono text-[10px] text-rose-400">{rule.type}</div>
                  </td>
                  <td className="py-3 px-4 text-slate-300 max-w-xs">
                    {rule.description}
                  </td>
                  <td className="py-3 px-4 text-sky-300 font-medium">
                    {rule.authorizedRolesSummary}
                  </td>
                  <td className="py-3 px-4 text-slate-400">
                    {rule.defaultFixes[0]?.label}
                  </td>
                  <td className="py-3 px-4 text-right">
                    <button
                      onClick={() => {
                        setEmergencyType(rule.type);
                        setDeclarerRole(rule.authorizedRoles[0]);
                        setAuthError(null);
                        setIsDeclareModalOpen(true);
                      }}
                      className="rounded border border-rose-500/40 bg-rose-950/50 px-2.5 py-1 text-[11px] font-semibold text-rose-200 hover:bg-rose-900/80 transition-colors whitespace-nowrap"
                    >
                      Configure & Declare
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Declare Emergency Modal with Authorized Role Check */}
      {isDeclareModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="w-full max-w-lg rounded-xl border border-rose-500/50 bg-slate-900 p-6 shadow-2xl">
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-rose-400" />
              <span>Declare Flight / Terminal Emergency</span>
            </h3>
            <p className="mt-1 text-xs text-slate-400">
              Validates declaring authority eligibility, dispatches ARFF units, and initializes interactive operation fixes.
            </p>

            {authError && (
              <div className="mt-3 rounded-lg border border-rose-500/50 bg-rose-950/90 p-3 text-xs text-rose-200">
                {authError}
              </div>
            )}

            <form onSubmit={handleDeclareSubmit} className="mt-4 space-y-4">
              <div>
                <label className="text-xs font-medium text-slate-300">Select Flight:</label>
                <select
                  value={selectedFlightId}
                  onChange={(e) => setSelectedFlightId(e.target.value)}
                  className="mt-1 w-full rounded border border-slate-700 bg-slate-950 px-3 py-2 text-xs text-white focus:border-rose-500 focus:outline-none"
                >
                  {flights.map((f) => (
                    <option key={f.id} value={f.id}>
                      {f.flightNumber} ({f.originIata} → {f.destinationIata}) - {f.aircraftModel}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-xs font-medium text-slate-300">Emergency Type:</label>
                <select
                  value={emergencyType}
                  onChange={(e) => {
                    const nextType = e.target.value as EmergencyType;
                    setEmergencyType(nextType);
                    const rule = EMERGENCY_TYPE_RULES.find((r) => r.type === nextType);
                    if (rule && !rule.authorizedRoles.includes(declarerRole)) {
                      setDeclarerRole(rule.authorizedRoles[0]);
                    }
                    setAuthError(null);
                  }}
                  className="mt-1 w-full rounded border border-slate-700 bg-slate-950 px-3 py-2 text-xs text-white focus:border-rose-500 focus:outline-none"
                >
                  {EMERGENCY_TYPE_RULES.map((r) => (
                    <option key={r.type} value={r.type}>
                      {r.label} ({r.type})
                    </option>
                  ))}
                </select>
                <div className="mt-1 text-[11px] text-sky-400">
                  Authorized to Declare: <strong>{selectedRule.authorizedRolesSummary}</strong>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-medium text-slate-300">
                    Declaring Authority Role:
                  </label>
                  <select
                    value={declarerRole}
                    onChange={(e) => {
                      setDeclarerRole(e.target.value as EmergencyDeclarerRole);
                      setAuthError(null);
                    }}
                    className="mt-1 w-full rounded border border-slate-700 bg-slate-950 px-3 py-2 text-xs text-white focus:border-rose-500 focus:outline-none"
                  >
                    {(Object.keys(DECLARER_ROLE_LABELS) as EmergencyDeclarerRole[]).map(
                      (roleKey) => {
                        const allowed = selectedRule.authorizedRoles.includes(roleKey);
                        return (
                          <option key={roleKey} value={roleKey}>
                            {DECLARER_ROLE_LABELS[roleKey]} {allowed ? '✓ (Authorized)' : '✗ (Restricted)'}
                          </option>
                        );
                      }
                    )}
                  </select>
                </div>

                <div>
                  <label className="text-xs font-medium text-slate-300">
                    Reporting Officer Name:
                  </label>
                  <input
                    type="text"
                    required
                    value={declarerName}
                    onChange={(e) => setDeclarerName(e.target.value)}
                    className="mt-1 w-full rounded border border-slate-700 bg-slate-950 px-3 py-2 text-xs text-white focus:border-rose-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-medium text-slate-300">Severity Tier:</label>
                <select
                  value={severity}
                  onChange={(e) => setSeverity(e.target.value as any)}
                  className="mt-1 w-full rounded border border-slate-700 bg-slate-950 px-3 py-2 text-xs text-white focus:border-rose-500 focus:outline-none"
                >
                  <option value="HIGH">High (Priority Approach & Gate Clearance)</option>
                  <option value="CRITICAL">Critical Mayday (Immediate Runway Shutdown & ARFF Foam Standby)</option>
                </select>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsDeclareModalOpen(false)}
                  className="rounded px-3 py-1.5 text-xs text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded bg-rose-600 px-4 py-1.5 text-xs font-bold text-white hover:bg-rose-500 transition-colors shadow"
                >
                  Initiate Emergency Protocol
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
