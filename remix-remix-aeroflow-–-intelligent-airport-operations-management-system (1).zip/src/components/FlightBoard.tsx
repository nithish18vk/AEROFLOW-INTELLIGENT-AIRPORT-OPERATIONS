import React, { useState, useMemo } from 'react';
import {
  Flight,
  FlightStatus,
  Gate,
  PassengerAircraft,
} from '../types/aeroflow';
import {
  Search,
  Plus,
  Clock,
  AlertTriangle,
  ArrowRight,
  CheckCircle2,
  Ban,
} from 'lucide-react';

interface FlightBoardProps {
  flights: Flight[];
  gates: Gate[];
  passengerFleet: PassengerAircraft[];
  onSelectFlightForBooking: (flight: Flight) => void;
  onUpdateFlightStatus: (flightId: string, status: FlightStatus) => void;
  onReportDelay: (
    flightId: string,
    minutes: number,
    reason: 'WEATHER' | 'ATC_HOLD' | 'MAINTENANCE' | 'CREW_REST'
  ) => void;
  onAssignGate: (flightId: string, gateId: string) => void;
  onConfirmGateAssignment: (flightId: string) => void;
  onTriggerEmergency: (flight: Flight) => void;
  onAddNewFlight: (newFlight: Flight) => void;
}

export const FlightBoard: React.FC<FlightBoardProps> = ({
  flights,
  gates,
  passengerFleet,
  onSelectFlightForBooking,
  onUpdateFlightStatus,
  onReportDelay,
  onAssignGate,
  onConfirmGateAssignment,
  onTriggerEmergency,
  onAddNewFlight,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'ALL' | FlightStatus>('ALL');
  const [selectedDirection, setSelectedDirection] = useState<'ALL' | 'DEPARTURES' | 'ARRIVALS'>('ALL');
  const [delayModalFlight, setDelayModalFlight] = useState<Flight | null>(null);
  const [delayMinutesInput, setDelayMinutesInput] = useState(25);
  const [delayReasonInput, setDelayReasonInput] = useState<'WEATHER' | 'ATC_HOLD' | 'MAINTENANCE' | 'CREW_REST'>('ATC_HOLD');
  const [isNewFlightModalOpen, setIsNewFlightModalOpen] = useState(false);

  // New flight form state
  const [newFlightNum, setNewFlightNum] = useState('AF-520');
  const [newOrigin, setNewOrigin] = useState('JFK');
  const [newOriginCity, setNewOriginCity] = useState('New York');
  const [newDest, setNewDest] = useState('CDG');
  const [newDestCity, setNewDestCity] = useState('Paris');
  const [newDepartureTime, setNewDepartureTime] = useState('14:30');
  const [newDaysOut, setNewDaysOut] = useState(2);
  const [newAircraftId, setNewAircraftId] = useState(passengerFleet[0]?.id || 'ac-787-1');
  const [newBasePrice, setNewBasePrice] = useState(580);

  const filteredFlights = useMemo(() => {
    return flights.filter((flight) => {
      const matchesSearch =
        flight.flightNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
        flight.originCity.toLowerCase().includes(searchQuery.toLowerCase()) ||
        flight.destinationCity.toLowerCase().includes(searchQuery.toLowerCase()) ||
        flight.originIata.toLowerCase().includes(searchQuery.toLowerCase()) ||
        flight.destinationIata.toLowerCase().includes(searchQuery.toLowerCase()) ||
        flight.aircraftModel.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesStatus = statusFilter === 'ALL' || flight.status === statusFilter;

      const isDeparture = flight.originIata === 'JFK';
      const isArrival = flight.destinationIata === 'JFK';

      const matchesDirection =
        selectedDirection === 'ALL' ||
        (selectedDirection === 'DEPARTURES' && isDeparture) ||
        (selectedDirection === 'ARRIVALS' && isArrival);

      return matchesSearch && matchesStatus && matchesDirection;
    });
  }, [flights, searchQuery, statusFilter, selectedDirection]);

  const metrics = useMemo(() => {
    const total = flights.length;
    const delayed = flights.filter((f) => f.status === 'DELAYED').length;
    const onTimePercentage = total > 0 ? Math.round(((total - delayed) / total) * 100) : 100;
    const boarding = flights.filter((f) => f.status === 'BOARDING').length;
    const landed = flights.filter((f) => f.status === 'LANDED').length;
    return { total, delayed, onTimePercentage, boarding, landed };
  }, [flights]);

  const handleCreateFlightSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFlightNum || !newDest) return;

    const chosenAircraft =
      passengerFleet.find((a) => a.id === newAircraftId) || passengerFleet[0];

    const created: Flight = {
      id: `fl-${Date.now()}`,
      flightNumber: newFlightNum.toUpperCase(),
      airline: 'AeroFlow Int’l',
      originIata: newOrigin.toUpperCase(),
      originCity: newOriginCity,
      destinationIata: newDest.toUpperCase(),
      destinationCity: newDestCity,
      aircraftId: chosenAircraft.id,
      aircraftTail: chosenAircraft.tailNumber,
      aircraftModel: chosenAircraft.model,
      aircraftCategory: 'PASSENGER',
      scheduledDeparture: newDepartureTime,
      estimatedDeparture: newDepartureTime,
      scheduledArrival: '22:15',
      departureDate: newDaysOut === 2 ? '2026-10-08' : newDaysOut === 0 ? '2026-10-06' : '2026-10-09',
      daysUntilDeparture: Number(newDaysOut),
      gateAssignmentStatus: 'UNASSIGNED',
      status: 'SCHEDULED',
      delayMinutes: 0,
      delayReason: 'NONE',
      basePrice: Number(newBasePrice),
      totalSeats: chosenAircraft.seatCapacity.total,
      bookedSeats: 0,
      assignedCrewIds: [],
    };

    onAddNewFlight(created);
    setIsNewFlightModalOpen(false);
    setNewFlightNum('AF-');
  };

  return (
    <div className="space-y-6">
      {/* Hero Atmosphere Banner */}
      <div className="relative overflow-hidden rounded-xl border border-slate-800 bg-slate-900/60 shadow-lg">
        <div className="relative h-40 sm:h-48 w-full overflow-hidden bg-gradient-to-r from-slate-950 via-slate-900 to-slate-950">
          <img
            src="/src/assets/images/aeroflow_terminal_radar_1791179001623.jpg"
            alt="AeroFlow Terminal Radar"
            referrerPolicy="no-referrer"
            className="h-full w-full object-cover opacity-35 mix-blend-luminosity"
            onError={(e) => {
              (e.target as HTMLElement).style.display = 'none';
            }}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/60 to-transparent" />

          <div className="absolute inset-0 flex flex-col justify-end p-6">
            <div className="flex flex-wrap items-end justify-between gap-4">
              <div>
                <div className="flex items-center gap-2 text-xs font-semibold text-sky-400">
                  <span>JFK Air Operations Command Center</span>
                  <span aria-hidden="true">·</span>
                  <span>Dynamic Aircraft Cabin Mapping</span>
                  <span aria-hidden="true">·</span>
                  <span>T-48h Gate Confirmation</span>
                </div>
                <h1 className="mt-1 text-2xl sm:text-3xl font-bold tracking-tight text-white">
                  Intelligent Flight Operations & Dispatch
                </h1>
                <p className="mt-1 max-w-2xl text-xs sm:text-sm text-slate-300">
                  Real-time schedule telemetry, aircraft-specific cabin seat layouts, 2-day advance gate confirmation, and landed flight lockouts.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsNewFlightModalOpen(true)}
                  className="flex items-center gap-1.5 rounded-lg bg-sky-600 px-3.5 py-2 text-xs font-semibold text-white shadow-sm hover:bg-sky-500 transition-colors whitespace-nowrap"
                >
                  <Plus className="h-4 w-4" />
                  <span>Schedule Flight</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Operational Metrics Bar */}
        <div className="grid grid-cols-2 gap-px bg-slate-800/80 sm:grid-cols-5 text-center">
          <div className="bg-slate-900/90 p-3">
            <div className="text-[11px] font-medium text-slate-400">Monitored Flights</div>
            <div className="mt-0.5 font-mono text-xl font-bold tabular-nums text-white">
              {metrics.total}
            </div>
          </div>
          <div className="bg-slate-900/90 p-3">
            <div className="text-[11px] font-medium text-slate-400">On-Time Performance</div>
            <div className="mt-0.5 font-mono text-xl font-bold tabular-nums text-emerald-400">
              {metrics.onTimePercentage}%
            </div>
          </div>
          <div className="bg-slate-900/90 p-3">
            <div className="text-[11px] font-medium text-slate-400">Active Boarding</div>
            <div className="mt-0.5 font-mono text-xl font-bold tabular-nums text-sky-400">
              {metrics.boarding}
            </div>
          </div>
          <div className="bg-slate-900/90 p-3">
            <div className="text-[11px] font-medium text-slate-400">Landed (Booking Closed)</div>
            <div className="mt-0.5 font-mono text-xl font-bold tabular-nums text-slate-200">
              {metrics.landed}
            </div>
          </div>
          <div className="col-span-2 sm:col-span-1 bg-slate-900/90 p-3">
            <div className="text-[11px] font-medium text-slate-400">Delay Incidents</div>
            <div
              className={`mt-0.5 font-mono text-xl font-bold tabular-nums ${
                metrics.delayed > 0 ? 'text-amber-400' : 'text-slate-400'
              }`}
            >
              {metrics.delayed}
            </div>
          </div>
        </div>
      </div>

      {/* Control Strip: Search & Filtering */}
      <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3 rounded-lg border border-slate-800 bg-slate-900/70 p-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
          <input
            type="text"
            aria-label="Search flights"
            placeholder="Search by flight number (e.g. AF-402, AF-332), city, IATA code, or aircraft..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full rounded-md border border-slate-700 bg-slate-950 pl-9 pr-4 py-1.5 text-xs text-slate-100 placeholder:text-slate-500 focus:border-sky-500 focus:outline-none"
          />
        </div>

        {/* Direction Segmented Control */}
        <div className="flex items-center gap-1 rounded-md bg-slate-950 p-1 border border-slate-800">
          {(['ALL', 'DEPARTURES', 'ARRIVALS'] as const).map((dir) => (
            <button
              key={dir}
              onClick={() => setSelectedDirection(dir)}
              className={`rounded px-2.5 py-1 text-xs font-medium transition-colors whitespace-nowrap ${
                selectedDirection === dir
                  ? 'bg-sky-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {dir === 'ALL' ? 'All Operations' : dir === 'DEPARTURES' ? 'Departures' : 'Arrivals'}
            </button>
          ))}
        </div>

        {/* Status Dropdown Filter */}
        <div className="flex items-center gap-2">
          <label htmlFor="flight-status-filter" className="text-xs text-slate-400">
            Status:
          </label>
          <select
            id="flight-status-filter"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as any)}
            className="rounded-md border border-slate-700 bg-slate-950 px-2.5 py-1.5 text-xs text-slate-200 focus:border-sky-500 focus:outline-none"
          >
            <option value="ALL">All Statuses</option>
            <option value="SCHEDULED">Scheduled</option>
            <option value="BOARDING">Boarding</option>
            <option value="IN_FLIGHT">In Flight</option>
            <option value="LANDED">Landed</option>
            <option value="DELAYED">Delayed</option>
            <option value="CANCELLED">Cancelled</option>
          </select>
        </div>
      </div>

      {/* Flight Schedule Table */}
      <div className="overflow-hidden rounded-xl border border-slate-800 bg-slate-900/60 shadow-md">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-950/80 text-slate-400 font-semibold">
                <th className="py-3 px-4">Flight</th>
                <th className="py-3 px-4">Route</th>
                <th className="py-3 px-4">Aircraft & Layout</th>
                <th className="py-3 px-4">Gate (T-48h Rule)</th>
                <th className="py-3 px-4">Schedule</th>
                <th className="py-3 px-4">Cabin Capacity</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-sans">
              {filteredFlights.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-400">
                    No flights matching your search filter. Try clearing query.
                  </td>
                </tr>
              ) : (
                filteredFlights.map((flight) => {
                  const loadPercent =
                    flight.totalSeats > 0
                      ? Math.round((flight.bookedSeats / flight.totalSeats) * 100)
                      : 0;

                  const aircraftInfo = passengerFleet.find((a) => a.id === flight.aircraftId);
                  const isLandedOrClosed =
                    flight.status === 'LANDED' ||
                    flight.status === 'DEPARTED' ||
                    flight.status === 'CANCELLED';

                  return (
                    <tr
                      key={flight.id}
                      className="group transition-colors hover:bg-slate-800/40"
                    >
                      {/* Flight Number & Airline */}
                      <td className="py-3.5 px-4">
                        <div className="font-mono font-bold text-sky-400 text-sm">
                          {flight.flightNumber}
                        </div>
                        <div className="text-[11px] text-slate-400">
                          {flight.airline}
                        </div>
                      </td>

                      {/* Origin & Destination */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-1.5 font-semibold text-slate-200">
                          <span>{flight.originIata}</span>
                          <ArrowRight className="h-3 w-3 text-slate-500" />
                          <span>{flight.destinationIata}</span>
                        </div>
                        <div className="text-[11px] text-slate-400 truncate max-w-[140px]">
                          {flight.originCity} → {flight.destinationCity}
                        </div>
                      </td>

                      {/* Aircraft & Seat Configuration */}
                      <td className="py-3.5 px-4">
                        <div className="text-slate-200 font-medium truncate max-w-[175px]">
                          {flight.aircraftModel}
                        </div>
                        <div className="font-mono text-[10px] text-slate-400">
                          {flight.aircraftTail}
                          {aircraftInfo
                            ? ` · ${aircraftInfo.seatConfiguration} (${aircraftInfo.seatCapacity.total} seats)`
                            : ' · Cargo Hold'}
                        </div>
                      </td>

                      {/* Gate & 2-Day Confirmation Status */}
                      <td className="py-3.5 px-4">
                        <div className="flex flex-col gap-1">
                          <select
                            aria-label={`Gate for ${flight.flightNumber}`}
                            value={flight.gateId || ''}
                            onChange={(e) => onAssignGate(flight.id, e.target.value)}
                            className="rounded border border-slate-700 bg-slate-950 px-2 py-1 font-mono text-xs font-semibold text-slate-200 focus:border-sky-500 focus:outline-none"
                          >
                            <option value="">Unassigned</option>
                            {gates.map((g) => (
                              <option key={g.id} value={g.id}>
                                Gate {g.gateNumber} ({g.terminal.replace('TERMINAL_', 'T-')})
                              </option>
                            ))}
                          </select>
                          {flight.gateAssignmentStatus === 'PENDING_CONFIRMATION' && (
                            <div className="flex items-center gap-1.5">
                              <span className="text-[10px] text-amber-400 font-medium">
                                T-48h Unconfirmed
                              </span>
                              <button
                                onClick={() => onConfirmGateAssignment(flight.id)}
                                className="text-[10px] font-semibold text-emerald-400 underline hover:text-emerald-300"
                              >
                                Confirm
                              </button>
                            </div>
                          )}
                          {flight.gateAssignmentStatus === 'CONFIRMED' && flight.gateNumber && (
                            <span className="text-[10px] text-emerald-400 flex items-center gap-1">
                              <CheckCircle2 className="h-3 w-3" />
                              Confirmed
                            </span>
                          )}
                        </div>
                      </td>

                      {/* Schedule Time & Delays */}
                      <td className="py-3.5 px-4">
                        <div className="font-mono tabular-nums text-slate-200 font-medium">
                          {flight.scheduledDeparture}
                          {flight.delayMinutes > 0 && (
                            <span className="ml-1.5 text-amber-400 font-semibold text-[11px]">
                              (+{flight.delayMinutes}m)
                            </span>
                          )}
                        </div>
                        <div className="text-[10px] text-slate-400">
                          {flight.daysUntilDeparture === 2
                            ? 'Departs in 2 Days (T-48h)'
                            : `Arr: ${flight.scheduledArrival}`}
                        </div>
                      </td>

                      {/* Seat Occupancy Meter */}
                      <td className="py-3.5 px-4">
                        {flight.aircraftCategory === 'PASSENGER' ? (
                          <div>
                            <div className="flex items-center justify-between text-[11px] text-slate-300 font-mono tabular-nums mb-1">
                              <span>
                                {flight.bookedSeats}/{flight.totalSeats}
                              </span>
                              <span className="text-slate-400">{loadPercent}%</span>
                            </div>
                            <div className="h-1.5 w-24 rounded-full bg-slate-800 overflow-hidden">
                              <div
                                className={`h-full ${
                                  loadPercent > 90
                                    ? 'bg-rose-500'
                                    : loadPercent > 70
                                    ? 'bg-amber-400'
                                    : 'bg-sky-500'
                                }`}
                                style={{ width: `${loadPercent}%` }}
                              />
                            </div>
                          </div>
                        ) : (
                          <span className="text-[11px] text-slate-400 italic">
                            Dedicated Cargo
                          </span>
                        )}
                      </td>

                      {/* Status Text */}
                      <td className="py-3.5 px-4">
                        <span
                          className={`font-mono text-xs font-semibold ${
                            flight.status === 'BOARDING'
                              ? 'text-emerald-400'
                              : flight.status === 'DELAYED'
                              ? 'text-amber-400'
                              : flight.status === 'IN_FLIGHT'
                              ? 'text-indigo-400'
                              : flight.status === 'LANDED'
                              ? 'text-slate-400'
                              : flight.status === 'CANCELLED'
                              ? 'text-rose-400'
                              : 'text-sky-300'
                          }`}
                        >
                          {flight.status}
                        </span>
                      </td>

                      {/* Action Menu: Remove Seat Booking for Landed Aircraft! */}
                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {flight.aircraftCategory === 'PASSENGER' && !isLandedOrClosed ? (
                            <button
                              onClick={() => onSelectFlightForBooking(flight)}
                              className="rounded bg-sky-600 px-2.5 py-1 text-[11px] font-semibold text-white hover:bg-sky-500 transition-colors whitespace-nowrap"
                            >
                              Book Seat
                            </button>
                          ) : flight.aircraftCategory === 'PASSENGER' && flight.status === 'LANDED' ? (
                            <span
                              className="inline-flex items-center gap-1 text-[11px] text-slate-500 font-medium px-2 py-1 whitespace-nowrap"
                              title="Seat booking is disabled for landed aircraft"
                            >
                              <Ban className="h-3 w-3 text-slate-500" />
                              <span>Landed · Booking Closed</span>
                            </span>
                          ) : null}

                          <button
                            onClick={() => {
                              setDelayModalFlight(flight);
                              setDelayMinutesInput(flight.delayMinutes || 30);
                            }}
                            title="Report Delay / Ground Stop"
                            aria-label={`Report Delay for ${flight.flightNumber}`}
                            className="rounded border border-slate-700 bg-slate-800 p-1.5 text-slate-300 hover:text-amber-400 hover:border-amber-500/40 transition-colors"
                          >
                            <Clock className="h-3.5 w-3.5" />
                          </button>

                          <button
                            onClick={() => onTriggerEmergency(flight)}
                            title="Emergency / Priority Divert Protocol"
                            aria-label={`Declare Emergency for ${flight.flightNumber}`}
                            className="rounded border border-slate-700 bg-slate-800 p-1.5 text-slate-300 hover:text-rose-400 hover:border-rose-500/40 transition-colors"
                          >
                            <AlertTriangle className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Delay Management Modal */}
      {delayModalFlight && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          <div className="w-full max-w-md rounded-xl border border-slate-800 bg-slate-900 p-6 shadow-2xl">
            <h3 className="text-lg font-bold text-white">
              Report Flight Delay: {delayModalFlight.flightNumber}
            </h3>
            <p className="mt-1 text-xs text-slate-400">
              Adjust scheduled departure telemetry and propagate notifications to all connected passenger channels.
            </p>

            <div className="mt-4 space-y-3">
              <div>
                <label className="text-xs font-medium text-slate-300">
                  Delay Duration (Minutes):
                </label>
                <input
                  type="number"
                  min="5"
                  max="480"
                  value={delayMinutesInput}
                  onChange={(e) => setDelayMinutesInput(Number(e.target.value))}
                  className="mt-1 w-full rounded border border-slate-700 bg-slate-950 px-3 py-1.5 text-xs text-white focus:border-sky-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="text-xs font-medium text-slate-300">
                  Root Cause Classification:
                </label>
                <select
                  value={delayReasonInput}
                  onChange={(e) => setDelayReasonInput(e.target.value as any)}
                  className="mt-1 w-full rounded border border-slate-700 bg-slate-950 px-3 py-1.5 text-xs text-white focus:border-sky-500 focus:outline-none"
                >
                  <option value="ATC_HOLD">Air Traffic Control Flow Hold (ATC)</option>
                  <option value="WEATHER">Severe Weather / Thunderstorms</option>
                  <option value="MAINTENANCE">Unscheduled Avionics Maintenance</option>
                  <option value="CREW_REST">Mandatory 8-Hour Crew Rest Regulation</option>
                </select>
              </div>
            </div>

            <div className="mt-6 flex justify-end gap-2">
              <button
                onClick={() => setDelayModalFlight(null)}
                className="rounded px-3 py-1.5 text-xs text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  onReportDelay(delayModalFlight.id, delayMinutesInput, delayReasonInput);
                  setDelayModalFlight(null);
                }}
                className="rounded bg-amber-600 px-4 py-1.5 text-xs font-semibold text-white hover:bg-amber-500 transition-colors"
              >
                Broadcast Delay & Update
              </button>
            </div>
          </div>
        </div>
      )}

      {/* New Flight Creation Modal with Aircraft Model Selector */}
      {isNewFlightModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          <div className="w-full max-w-lg rounded-xl border border-slate-800 bg-slate-900 p-6 shadow-2xl">
            <h3 className="text-lg font-bold text-white">
              Schedule New Commercial Flight
            </h3>
            <p className="mt-1 text-xs text-slate-400">
              Select aircraft type to configure dynamic seating capacity and cabin layout.
            </p>

            <form onSubmit={handleCreateFlightSubmit} className="mt-4 space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-medium text-slate-300">Flight Number:</label>
                  <input
                    type="text"
                    required
                    value={newFlightNum}
                    onChange={(e) => setNewFlightNum(e.target.value)}
                    placeholder="AF-520"
                    className="mt-1 w-full rounded border border-slate-700 bg-slate-950 px-3 py-1.5 font-mono text-xs text-white focus:border-sky-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-xs font-medium text-slate-300">Base Fare ($):</label>
                  <input
                    type="number"
                    required
                    value={newBasePrice}
                    onChange={(e) => setNewBasePrice(Number(e.target.value))}
                    className="mt-1 w-full rounded border border-slate-700 bg-slate-950 px-3 py-1.5 text-xs text-white focus:border-sky-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-medium text-slate-300">Origin (IATA / City):</label>
                  <div className="mt-1 flex gap-1">
                    <input
                      type="text"
                      maxLength={3}
                      value={newOrigin}
                      onChange={(e) => setNewOrigin(e.target.value.toUpperCase())}
                      className="w-16 rounded border border-slate-700 bg-slate-950 px-2 py-1.5 font-mono text-xs text-white text-center"
                    />
                    <input
                      type="text"
                      value={newOriginCity}
                      onChange={(e) => setNewOriginCity(e.target.value)}
                      className="flex-1 rounded border border-slate-700 bg-slate-950 px-2 py-1.5 text-xs text-white"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-xs font-medium text-slate-300">Destination (IATA / City):</label>
                  <div className="mt-1 flex gap-1">
                    <input
                      type="text"
                      maxLength={3}
                      value={newDest}
                      onChange={(e) => setNewDest(e.target.value.toUpperCase())}
                      className="w-16 rounded border border-slate-700 bg-slate-950 px-2 py-1.5 font-mono text-xs text-white text-center"
                    />
                    <input
                      type="text"
                      value={newDestCity}
                      onChange={(e) => setNewDestCity(e.target.value)}
                      className="flex-1 rounded border border-slate-700 bg-slate-950 px-2 py-1.5 text-xs text-white"
                    />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-medium text-slate-300">Departure Time:</label>
                  <input
                    type="time"
                    value={newDepartureTime}
                    onChange={(e) => setNewDepartureTime(e.target.value)}
                    className="mt-1 w-full rounded border border-slate-700 bg-slate-950 px-3 py-1.5 font-mono text-xs text-white"
                  />
                </div>
                <div>
                  <label className="text-xs font-medium text-slate-300">Advance Window:</label>
                  <select
                    value={newDaysOut}
                    onChange={(e) => setNewDaysOut(Number(e.target.value))}
                    className="mt-1 w-full rounded border border-slate-700 bg-slate-950 px-3 py-1.5 text-xs text-white"
                  >
                    <option value={0}>Today (Day of Departure)</option>
                    <option value={2}>2 Days Prior (T-48h Gate Window)</option>
                    <option value={4}>4 Days Prior (Pre-Allocation)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-xs font-medium text-slate-300">
                  Assigned Aircraft (Determines Cabin Capacity & Seat Layout):
                </label>
                <select
                  value={newAircraftId}
                  onChange={(e) => setNewAircraftId(e.target.value)}
                  className="mt-1 w-full rounded border border-slate-700 bg-slate-950 px-3 py-2 text-xs text-white focus:border-sky-500 focus:outline-none"
                >
                  {passengerFleet.map((ac) => (
                    <option key={ac.id} value={ac.id}>
                      {ac.model} ({ac.tailNumber}) — {ac.seatCapacity.total} Total Seats [{ac.seatConfiguration} Layout · First: {ac.seatCapacity.first}, Bus: {ac.seatCapacity.business}, Econ: {ac.seatCapacity.economy}]
                    </option>
                  ))}
                </select>
              </div>

              <div className="mt-6 flex justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsNewFlightModalOpen(false)}
                  className="rounded px-3 py-1.5 text-xs text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded bg-sky-600 px-4 py-1.5 text-xs font-semibold text-white hover:bg-sky-500 transition-colors"
                >
                  Create Flight Schedule
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
