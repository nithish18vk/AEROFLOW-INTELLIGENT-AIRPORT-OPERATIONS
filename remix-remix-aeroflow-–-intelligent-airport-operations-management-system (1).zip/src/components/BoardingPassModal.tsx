import React from 'react';
import { Ticket, Flight } from '../types/aeroflow';
import { X, Plane, QrCode, Printer, CheckCircle, ArrowRight } from 'lucide-react';

interface BoardingPassModalProps {
  ticket: Ticket;
  flight: Flight;
  onClose: () => void;
  onMarkBoarded?: (ticketId: string) => void;
}

export const BoardingPassModal: React.FC<BoardingPassModalProps> = ({
  ticket,
  flight,
  onClose,
  onMarkBoarded,
}) => {
  const getBoardingGroup = () => {
    if (ticket.travelClass === 'FIRST') return 'Group 1 (Priority)';
    if (ticket.travelClass === 'BUSINESS') return 'Group 2 (FastTrack)';
    return 'Group 3 (General)';
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="relative w-full max-w-2xl rounded-2xl border border-slate-700 bg-slate-900 shadow-2xl overflow-hidden my-6">
        {/* Modal Top Actions */}
        <div className="flex items-center justify-between border-b border-slate-800 bg-slate-950 px-6 py-3">
          <div className="flex items-center gap-2 text-xs font-semibold text-sky-400">
            <CheckCircle className="h-4 w-4" />
            <span>Official Electronic Boarding Document</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 rounded bg-slate-800 px-3 py-1 text-xs font-medium text-slate-200 hover:bg-slate-700 transition-colors"
            >
              <Printer className="h-3.5 w-3.5" />
              <span>Print Pass</span>
            </button>
            <button
              onClick={onClose}
              className="rounded p-1 text-slate-400 hover:text-white"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Boarding Pass Shell */}
        <div className="p-6">
          <div className="rounded-xl border border-slate-700 bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 overflow-hidden shadow-xl">
            {/* Header airline banner */}
            <div className="flex items-center justify-between bg-sky-700 px-6 py-3 text-white">
              <div className="flex items-center gap-2">
                <Plane className="h-5 w-5 -rotate-45" />
                <span className="font-bold tracking-wider text-sm">AEROFLOW AIRWAYS</span>
              </div>
              <div className="font-mono text-xs font-bold tracking-widest uppercase bg-sky-900/60 px-2.5 py-1 rounded">
                BOARDING PASS · {ticket.travelClass}
              </div>
            </div>

            {/* Flight Route Banner */}
            <div className="flex items-center justify-between border-b border-dashed border-slate-700 px-6 py-5">
              <div>
                <div className="font-mono text-3xl font-extrabold text-white">
                  {flight.originIata}
                </div>
                <div className="text-xs text-slate-400">{flight.originCity}</div>
              </div>

              <div className="flex flex-col items-center">
                <span className="font-mono text-xs text-sky-400 font-semibold mb-1">
                  Flight {flight.flightNumber}
                </span>
                <div className="flex items-center gap-2 text-slate-500">
                  <div className="h-0.5 w-12 bg-slate-700" />
                  <Plane className="h-4 w-4 text-sky-400" />
                  <div className="h-0.5 w-12 bg-slate-700" />
                </div>
                <span className="text-[10px] text-slate-400 mt-1">Non-Stop Boeing 787</span>
              </div>

              <div className="text-right">
                <div className="font-mono text-3xl font-extrabold text-white">
                  {flight.destinationIata}
                </div>
                <div className="text-xs text-slate-400">{flight.destinationCity}</div>
              </div>
            </div>

            {/* Passenger & Flight Details Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-6 text-xs border-b border-dashed border-slate-700 bg-slate-950/40">
              <div>
                <div className="text-[10px] font-medium uppercase text-slate-400">Passenger</div>
                <div className="mt-0.5 font-bold text-white text-sm truncate">
                  {ticket.passengerName}
                </div>
              </div>

              <div>
                <div className="text-[10px] font-medium uppercase text-slate-400">Seat</div>
                <div className="mt-0.5 font-mono text-lg font-bold text-amber-400">
                  {ticket.seatNumber}
                </div>
              </div>

              <div>
                <div className="text-[10px] font-medium uppercase text-slate-400">Gate / Terminal</div>
                <div className="mt-0.5 font-mono text-sm font-bold text-white">
                  {flight.gateNumber ? `Gate ${flight.gateNumber}` : 'Pending'}
                </div>
              </div>

              <div>
                <div className="text-[10px] font-medium uppercase text-slate-400">Boarding Time</div>
                <div className="mt-0.5 font-mono text-sm font-bold text-emerald-400">
                  {flight.scheduledDeparture}
                </div>
              </div>

              <div>
                <div className="text-[10px] font-medium uppercase text-slate-400">PNR Reference</div>
                <div className="mt-0.5 font-mono text-xs font-bold text-sky-400 tracking-wider">
                  {ticket.pnr}
                </div>
              </div>

              <div>
                <div className="text-[10px] font-medium uppercase text-slate-400">Boarding Group</div>
                <div className="mt-0.5 font-semibold text-slate-200">
                  {getBoardingGroup()}
                </div>
              </div>

              <div>
                <div className="text-[10px] font-medium uppercase text-slate-400">Cabin Baggage</div>
                <div className="mt-0.5 text-slate-300">
                  {ticket.baggageAllowanceKg} kg Allowed
                </div>
              </div>

              <div>
                <div className="text-[10px] font-medium uppercase text-slate-400">Status</div>
                <div className="mt-0.5 font-mono text-xs font-bold text-emerald-400 uppercase">
                  {ticket.status}
                </div>
              </div>
            </div>

            {/* Bottom Barcode & QR Code Section */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-6 bg-slate-950/80">
              <div className="flex items-center gap-4">
                <div className="rounded-lg bg-white p-2 text-slate-950 shadow-inner">
                  {/* High fidelity SVG Mock QR Code */}
                  <svg className="h-16 w-16" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M2 2h8v8H2V2zm2 2v4h4V4H4zm10-2h8v8h-8V2zm2 2v4h4V4h-4zM2 14h8v8H2v-8zm2 2v4h4v-4H4zm14 0h4v2h-4v-2zm-4 0h2v2h-2v-2zm2 4h4v2h-4v-2zm-2-2h2v2h-2v-2zm4-4h2v2h-2v-2zm-4 2h2v2h-2v-2zm6 2h2v4h-2v-4zM6 6h2v2H6V6zm12 0h2v2h-2V6zM6 18h2v2H6v-2z" />
                  </svg>
                </div>
                <div>
                  <div className="font-mono text-xs text-slate-300 tracking-wider">
                    SCAN AT GATE FOR FASTTRACK ENTRY
                  </div>
                  <div className="mt-1 text-[10px] text-slate-400">
                    TSA PreCheck / IATA FastTrack Verified Digital Ticket
                  </div>
                </div>
              </div>

              {onMarkBoarded && ticket.status !== 'BOARDED' && (
                <button
                  onClick={() => onMarkBoarded(ticket.id)}
                  className="w-full sm:w-auto rounded-lg bg-emerald-600 px-4 py-2 text-xs font-bold text-white hover:bg-emerald-500 shadow-md transition-colors"
                >
                  Simulate Gate Boarding Scan
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
